import paramiko, multiprocessing, os, sys, csv, time
from colorama import Fore, Back, Style
from colorama import init
from colorama import deinit
import ctypes
os.system('mode con cols=95 lines=40')
LF_FACESIZE = 32
STD_OUTPUT_HANDLE = -11

class COORD(ctypes.Structure):
    _fields_ = [
     (
      'X', ctypes.c_short), ('Y', ctypes.c_short)]


class CONSOLE_FONT_INFOEX(ctypes.Structure):
    _fields_ = [
     (
      'cbSize', ctypes.c_ulong),
     (
      'nFont', ctypes.c_ulong),
     (
      'dwFontSize', COORD),
     (
      'FontFamily', ctypes.c_uint),
     (
      'FontWeight', ctypes.c_uint),
     (
      'FaceName', ctypes.c_wchar * LF_FACESIZE)]


font = CONSOLE_FONT_INFOEX()
font.cbSize = ctypes.sizeof(CONSOLE_FONT_INFOEX)
font.nFont = 11
font.FontFamily = 54
font.FontWeight = 400
font.FaceName = 'Lucida Console'
handle = ctypes.windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
ctypes.windll.kernel32.SetCurrentConsoleFontEx(handle, ctypes.c_long(False), ctypes.pointer(font))

class Telnet(object):

    def __init__(self, host, user, pw):
        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh.connect(host, username=user, password=pw)
        self.chnl = self.ssh.invoke_shell()

    def write(self, cmd):
        self.chnl.send(cmd)

    def read_until(self, catch_string, timeout=6000):
        start = time.time()
        x = ''
        while True:
            if time.time() - start > timeout:
                break
            elif self.chnl.recv_ready():
                x = x + self.chnl.recv(9999)
            elif x.endswith(catch_string):
                break
            else:
                time.sleep(0.001)

        return x

    def expect(self, prompts, timeout=6000):
        start = time.time()
        x = ''
        while True:
            if time.time() - start > timeout:
                return (-1, None, x)
            if self.chnl.recv_ready():
                x = x + self.chnl.recv(9999)
            else:
                time.sleep(0.001)
            for i, match in enumerate(prompts):
                if x.endswith(match):
                    return (i, match, x)

        return

    def close(self):
        self.ssh.close()


def telnet_enb(inp):
    lsm_name, host, user, pw, cmd = (
     inp[0], inp[1], inp[2], inp[3], inp[4])
    f = open(os.path.join('logs', lsm_name + '.log'), 'wb')
    wr = csv.writer(f)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    print('Connecting ' + lsm_name.strip())
    try:
        ssh.connect(host, username=user, password=pw)
    except Exception as e:
        init()
        print(Fore.RED, 'Exception occured', e, lsm_name, host, user, pw)
        wr.writerow([lsm_name, host, "Couldn't Connect", e])
        f.close()
        print(Style.RESET_ALL)
        deinit()
        return
    else:
        try:
            if 'sudo ' in cmd:
                chan = ssh.get_transport().open_session()
                chan.get_pty()
                chan.exec_command(cmd)
                res = chan.recv(9999).split('\n')
                for i in res:
                    f.write(lsm_name + ',' + i + '\n')

            else:
                stdin, stdout, stderr = ssh.exec_command(cmd)
                try:
                    exit_status = stdout.channel.recv_exit_status()
                except Exception as e:
                    init()
                    print(Fore.RED, ' ERROR ', lsm_name, e,)
                    print(Style.RESET_ALL)
                    deinit()
                    f.write(lsm_name + ',' + e + '\n')
                    return

            if exit_status == 0:
                for i in stdout.readlines():
                    f.write(lsm_name + ',' + host + ',' + i + '\n')

                for k in stderr.readlines():
                    f.write(lsm_name + ',' + host + ',' + k + '\n')

            else:
                for i in stdout.readlines():
                    f.write(lsm_name + ',' + host + ',' + i + '\n')

            for j in stderr.readlines():
                f.write(lsm_name + ',' + host + ',' + j + '\n')

        except Exception as e:
            init()
            print(Fore.RED, ' ERROR ', lsm_name, e,)
            print(Style.RESET_ALL)
            deinit()
            f.write(lsm_name + ',' + host + ',' + e + '\n')

    f.close()
    ssh.close()


if __name__ == '__main__':
    inp = [ [x[0], x[1], x[2], x[3]] for x in csv.reader(open('Input.csv', 'rb')) ]
    cmd = input('cmd: ')
    pool = multiprocessing.Pool(50)
    args = []
    for voma_server in inp:
        args.append((voma_server[0], voma_server[1], voma_server[2], voma_server[3], cmd))

    res = pool.map(telnet_enb, args)
    pool.close()
    pool.join()
    init()
    input(Fore.GREEN + 'DONE, ENTER TO EXIT ')
