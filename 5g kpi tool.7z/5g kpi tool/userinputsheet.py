from numpy import NaN
import xlsxwriter
import os
from getsheetDates import getDates
import pandas as pd
import threading
from rawsheet import raww_map
from bandCalculation import band_calculation
from finalsheet import final_kpi
from formulasheet import formula_kpi
from datetime import datetime


# kpis, bands, toband
def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        s = s[1:]
    if s[-1:] == '"':
        s = s[0:-1]
    return s

def isInt(x):
    try:
        int(x)
        return True
    except ValueError:
        return False

def toLowerCase(s):
    return s.strip().lower()

def getKPIs(data):
    for i in range(8):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data

def getDate(d):
    d_list=d.split('-')
    if len(d_list)>1:
        dd = datetime.strptime(to_string(d),"%d-%b-%y")
        sdate=dd.strftime("%d %b %y")
        return sdate
    else:
        dd = datetime.strptime(to_string(d),"%d %b %y")
        sdate = dd.strftime("%d %b %y")
        return sdate




def getPos(s):
    prePos = {
        'pre' : 0,
        'pre1': 1,
        'pre2': 2,
        'pre3': 3,
        'pre4': 4,
        'pre5': 5
    }

    postPos = {
        'post' : 0,
        'post1' : 1,
        'post2' : 2,
        'post3':  3,
        'post4':  4,
        'post5':  5
    }

    if s[1] == 'r':
        return prePos[s]
    else: 
        return postPos[s]


def all_kpi():
    all_kpis = getkpis()
    non_kpi = non_kpis_formula()
    for kpi in non_kpi:
        all_kpis.append(kpi)

    return all_kpis

def non_kpis_formula():
    kpi_list=[]
    non_kpis_formula=formula_kpi()
    for kpis in non_kpis_formula:
        kpi_list.append(kpis)
    return kpi_list

def finalkpi():
    finall_kpi=[]
    kpilist=final_kpi()
    for kpi in kpilist:
        finall_kpi.append(kpi)
    return finall_kpi



def make_raw():
    l=set()
    path=os.getcwd()
    folder=path+"\\"+"5g kpi tool\\input"
    last_short_name = None
    files=os.listdir(folder)
    for filee in files:
        if filee=="raw_input.csv":
            continue
    file = open(folder + "\\" + filee,'r')
    data = file.read().split('\n')
    data.pop()
    for d in data[1:]:
        datalist = d.split(',')
        if len(datalist)>3 and len(datalist[3]) != 0:
            last_short_name = to_string(datalist[3])
            l.add(last_short_name)

    sitelist=list(l)
    
    return sitelist




def getkpis():
    path=os.getcwd()
    folder=path+"\\"+"5g kpi tool\\input"
    files=os.listdir(folder)
    file = open(folder + "\\" + files[0],'r')
    data = file.read().split('\n')
    kpis = getKPIs(data[0].split(','))

    return kpis


def write_to_filee():
    sitevalue= make_raw()
    t=getDates()
    g=finalkpi()
    remark_kpi=raww_map()
    band_kpi=band_calculation()
    path=os.getcwd()
    folder=path+"\\"+"5g kpi tool\\input"
    f = open(folder + "\\" +'raw_input.csv', 'w')
    heading=['SiteName','Category','Date','Remarks',"KPI","Value","BandCalculation"]
    
    f.write('sep=,')
    f.write('\n')
    for item in heading:
        f.write(item +',')
    f.write('\n')

    for i in range(max(len(g),len(t), len(sitevalue),len(remark_kpi),len(band_kpi))):
        if i<len(sitevalue):
            f.write(sitevalue[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        f.write('')
        f.write(',')


        if i < len(t):
            f.write(t[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')
        
        f.write('')
        f.write(',')

        if i < len(g):
            f.write(g[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        if i<len(remark_kpi):
            f.write(remark_kpi[g[i]])
            f.write(',')
        else:
            f.write('')
            f.write(',')
        
        if i<len(band_kpi):
            f.write(band_kpi[g[i]])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        f.write('\n')




# replaceComma()
#write_to_filee()


# short name to band
def write_map():
    path=os.getcwd()
    folder=path+"\\"+"5g kpi tool\\input"
    file=open(folder + "\\" + 'raw_input.csv',"r")
    raw_data=file.read().split('\n')
    for d in raw_data[1:]:
        data_list = d.split(',') 
    # making pre, post list
    pre = [[],[],[],[],[],[]]
    post = [[],[],[],[],[],[]]
    dateToRemark = {}
    
    valuelist=[]
    bandvaluelist=[]
    m={}
    
    

    for d in raw_data[1:]:
        data_list = d.split(',')
        if len(data_list)>2 and len(data_list[2])!=0:
            date=to_string(getDate(data_list[2]))

        if len(data_list) <2:
            break

        if len(data_list)>3 and len(data_list[3]) != 0:
            remark = to_string(data_list[3])
            dateToRemark[date] = toLowerCase(remark)
            #print(remark)
            if remark[1] == 'r':
                pre[getPos(toLowerCase(remark))].append(to_string(data_list[2]))
            else:
                post[getPos(toLowerCase(remark))].append(to_string(data_list[2]))

        if len(data_list)>1 and len(data_list[1]) != 0:
            category = to_string(data_list[1])
           

            if category not in m:
                m[category] = []
            m[category].append(to_string(data_list[0]))
                
       

        if len(data_list)>5 and len(data_list[5])!=0:
            value=to_string(data_list[5])
            if value[1]=='v':
                valuelist.append(to_string(data_list[4]))

        if len(data_list)>6 and len(data_list[6])!=0:
            bandvalue=to_string(data_list[6])
            if bandvalue[1]=='v':
                bandvaluelist.append(to_string(data_list[4]))

       


    
    
    

        
    return [m, pre, post,valuelist,bandvaluelist,dateToRemark]
            
        
# write_to_filee()
# result = write_map()
# for item in result:
#    print(item)





        