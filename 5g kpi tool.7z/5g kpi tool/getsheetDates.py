import os
import pandas as pd
from datetime import datetime
from functools import cmp_to_key
import time

year = {
    "Jan" : 0,
    "Feb" : 1,
    "Mar" : 2,
    "Apr" : 3,
    "May" : 4,
    "Jun" : 5, 
    "Jul" : 6,
    "Aug" : 7,
    "Sep" : 8,
    "Oct" : 9,
    "Nov" : 10, 
    "Dec" : 11
}



def compare(d1, d2):
    d1_list = d1.split()
    d2_list = d2.split()

    if int(d1_list[2]) < int(d2_list[2]):
        return -1
    elif int(d1_list[2]) == int(d2_list[2]):
        if year[d1_list[1]] < year[d2_list[1]]:
            return -1
        elif year[d1_list[1]] == year[d2_list[1]]:
            if int(d1_list[0]) < int(d2_list[0]):
                return -1
            elif int(d1_list[0]) == int(d2_list[0]):
                return 0
            else:
                return 1
        else:
            return 1
    else:
        return 1
    

def comparator(item1,item2):
    d1_list = item1.split()
    d2_list = item2.split()
    if int(d1_list[2]) < int(d2_list[2]):
        return -1
    elif int(d1_list[2]) > int(d2_list[2]):
        return 1
    return 0

def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        s = s[1:]
    if s[-1:] == '"':
        s = s[0:-1]
    return s


def reformat(d):
    d_list = d.split('-')
    date = None
    if len(d_list) > 1:
        date = datetime.strptime(to_string(d), '%d-%b-%y')
    else:
        date = datetime.strptime(to_string(d), '%d %b %y')
    return  date.strftime("%d %b %y")



def getDates(): 
    path=os.getcwd()
    folder=path+"\\"+"5g kpi tool\\input"
    files = os.listdir(folder)
    demo=set()
    for file in files:
        if file == 'raw_input.csv':
            continue
        _input = folder + '\\' + file
        f=open(_input)
        data=f.read().split('\n')
        for d in data[1:]:
            data_list = d.split(',')
            if len(data_list) > 2  and len(data_list[2]) != 0:
                date= to_string(data_list[2])
                line_list = date.split('-')
                if len(line_list) > 1:
                    new_line = ' '.join(tuple(date.split('-')))
                    demo.add(reformat(new_line))
                
                if len(line_list) <= 1:
                    demo.add(reformat(date))
    
    dates = list(demo)
    dates.sort(key=cmp_to_key(compare))
    return dates








   




     


    
    
 
        
