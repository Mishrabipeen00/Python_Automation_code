import os
from tkinter import *
import tkinter as tk
from tkinter import ttk
import tkinter.messagebox
from tkinter import Tk, filedialog, Button, StringVar, OptionMenu
from tkcalendar import Calendar, DateEntry
from userinputsheet import write_to_filee
from dailywiseinterfacee import dailyinterface

root = Tk()    
root.geometry("800x500")
root.configure(bg='black')



def on_dailywise_button_click():
    write_to_filee()
    dailyinterface()
    
        
#Title for tool
title = Label(root, text = "5G KPI Tool Dashboard",font=('Calisto MT',15),background='black',foreground='Red').place(x = 300, y = 6) 

#Input Button

#output Button
output_folder = Button(root, command=on_dailywise_button_click, text="Dailywise_Graph_Summary")
output_folder.pack(ipadx=5, ipady=5,pady=5)
output_folder.place(x=300, y=60)


root.mainloop()




