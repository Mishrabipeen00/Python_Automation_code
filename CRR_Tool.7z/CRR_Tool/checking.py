import os
import pandas as pd
from datetime import datetime
from functools import cmp_to_key

year = {
    "Jan" : 0,
    "Feb" : 1,
    "Mar" : 2,
    "Apr" : 3,
    "May" : 4,
    "Jun" : 5, 
    "Jul" : 6,
    "Aug" : 7,
    "Sep" : 8,
    "Oct" : 9,
    "Nov" : 10, 
    "Dec" : 11
}

def compare(d1, d2):
    d1_list = d1.split()
    d2_list = d2.split()

    

    if int(d1_list[2]) < int(d2_list[2]):
        return -1
    elif int(d1_list[2]) == int(d2_list[2]):
        if year[d1_list[1]] < year[d2_list[1]]:
            return -1
        elif year[d1_list[1]] == year[d2_list[1]]:
            if int(d1_list[0]) < int(d2_list[0]):
                return -1
            elif int(d1_list[0]) == int(d2_list[0]):
                return 0
            else:
                return 1
        else:
            return 1
    else:
        return 1
    

def comparator(item1,item2):
    d1_list = item1.split()
    d2_list = item2.split()
    if int(d1_list[2]) < int(d2_list[2]):
        return -1
    elif int(d1_list[2]) > int(d2_list[2]):
        return 1
    return 0

def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s


def reformat(d):
    d_list = d.split('-')
    date = None
    if len(d_list) > 1:
        date = datetime.strptime(to_string(d), '%d-%b-%y')
    else:
        date = datetime.strptime(to_string(d), '%d %b %y')
    return  date.strftime("%d %b %y")




def getDates(): 
    path=os.getcwd()
    folder=path+"\\"+"CRR_Tool\\input"
    files = os.listdir(folder)
    d=set()
    for file in files:
        if file == 'raw_input.csv':
            continue
        _input = folder + '\\' + file
        df = pd.read_csv(_input,dtype={col: str for col in pd.read_csv(_input, nrows=1).columns})
        var=df.iloc[:,1]
        for line in var:
            line_list = line.split('-')
            if len(line_list) > 1:
                new_line = ' '.join(tuple(line.split('-')))
                #print(new_line)
                d.add(reformat(new_line))
                
            line_list = line.split()
            if len(line_list) > 1:
                d.add(reformat(line))
    dates = list(d)
    dates.sort(key=cmp_to_key(compare))

    return dates










    
    
        
        
        
