import os
from socket import timeout
from tkinter import *
import tkinter as tk
from tkinter import ttk
from checking import getDates
from cat_summary import Summary
from cat_raw import write_map
from cat_raw import write_to_file
from cat_data_graph import catGraph
import tkinter.messagebox
from tkinter import Tk, filedialog, Button, StringVar, OptionMenu
from tkcalendar import Calendar, DateEntry
import xlsxwriter
from datetime import datetime
import time
 

# Get output name from file
def getOutputName(s):
    s_list = s.split('.')
    return s_list[0]+"Output"

#Create folder name
def getFolderName(ll):
    print(ll)
    items = ll.split('\\')
    s = ''
    for item in items:
        s += item + '\\'
    print(s)
    return s[:-2]


root = Tk()   
root.geometry("800x500")
root.configure(bg='black')
open_output_file = ''
open_input_file = ''
date_list = None
short_name=None

#Creating input filedialog askdirectory

def selectInputFolder():
    global open_input_file
    global date_list
    global short_name
    file_name = filedialog.askdirectory()
    ll = file_name.split('/')
    s = ''
    for l in ll:
        s += l + "\\\\"
    open_input_file = s[:-2]

    write_to_file(open_input_file)
    
#Creating output filedialog askdirectory
    
def selectOutputFolder():
    global open_output_file
    file_name = filedialog.askdirectory()
    ll = file_name.split('/')
    s = ''
    for l in ll:
        s += l + "\\\\"
    open_output_file = s[:-2]

        
    

def getDate(d):
    if d == "":
        return d

    dd = datetime.strptime(d,"%m/%d/%y")
    sdate = dd.strftime("%d %b %y")
    return sdate


#Function for Display message 
def onclick():
    tkinter.messagebox.showinfo("output location","Don't forget to Select output location")
    
#Title for tool
title = Label(root, text = "CRR Tool Dashboard",font=('Calisto MT',15),background='black',foreground='Red').place(x = 300, y = 6) 

#Input Button
input_folder = Button(root, command=lambda:[selectInputFolder(),onclick()], text="Input File location")
input_folder.pack(ipadx=5, ipady=5,pady=5)
input_folder.place(x=5, y=40)

#output Button
output_folder = Button(root, command=selectOutputFolder, text="Output File location")
output_folder.pack(ipadx=5, ipady=5,pady=5)
output_folder.place(x=120, y=40)

lbl = ttk.Label(root, text = "Enter the Header for Graph and Summary Table:",background='black',foreground='White').place(x = 250,y = 40)

name = tk.Entry(root, width=13)
name.pack(pady=20)
name.place(x=520,y=40) 

def _submit(open_input_file,open_output_file):
    files = os.listdir(open_input_file)
    _output = open_output_file + '\\' + getOutputName(files[0]) + ".xlsx"
    
    workbook = xlsxwriter.Workbook(_output,{'strings_to_numbers':True})

    mapping, preList, postList,short_to_band= write_map(open_input_file)
    graph = catGraph(mapping,open_input_file,short_to_band)

    graph.generate(workbook,name.get())
    summary = Summary(workbook,preList,postList,mapping,short_to_band) #pass open_output_file
    summary.call_category(open_input_file,name.get()) #pass open_input_file as fourth parameter
    print("output has been generated!!!")
    workbook.close()

#Function for clearing widgets
def clear_widgets():
    name.delete(0,END)
    
    

#Function for clearing widgets
def clear_text():
    name.delete(0,END)
    
    
    
b = Button(root,command=lambda: _submit(open_input_file,open_output_file),text = "Generate Report",bg='red',  fg = 'blue')    
b.pack(ipadx=5, ipady=5,pady=5)
b.place(x=200, y=90)

clear = Button(root,command=clear_text,text = "Clear Widget",bg='red',  fg = 'blue')    
clear.pack(ipadx=5, ipady=5,pady=5)
clear.place(x=320, y=90)


d = Button(root,command=clear_widgets,text = "Clear",bg='red',  fg = 'blue')    
d.pack(ipadx=5, ipady=5,pady=5)
d.place(x=420, y=90)

root.mainloop()