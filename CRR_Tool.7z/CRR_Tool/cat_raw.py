import xlsxwriter
import os
from checking import getDates
import pandas as pd

# kpis, bands, toband
def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        s = s[1:]
    if s[-1:] == '"':
        s = s[0:-1]
    return s

def isInt(x):
    try:
        int(x)
        return True
    except ValueError:
        return False

def toLowerCase(s):
    return s.strip().lower()


def getPos(s):
    prePos = {
        'pre' : 0,
        'pre1': 1,
        'pre2': 2,
        'pre3': 3,
        'pre4': 4,
        'pre5': 5
    }

    postPos = {
        'post' : 0,
        'post1' : 1,
        'post2' : 2,
        'post3':  3,
        'post4':  4,
        'post5':  5
    }

    if s[1] == 'r':
        return prePos[s]
    else: 
        return postPos[s]
    


def make_raw(_input):
    l=[]
    
    t=set()
    last_short_name = None
    files=os.listdir(_input)
    file = open(_input + "\\" + files[0],'r')
    data = file.read().split('\n')
    data.pop()
    for d in data:
        data_list = d.split(',')
        if len(data_list[0]) != 0:
            last_short_name = to_string(data_list[0])
            l.append(last_short_name)
   

    l.pop(0)             
    return l

def write_to_file(_input):
    l = make_raw(_input)
    t=getDates(_input)
    f = open(_input + "\\" +'raw_input.csv', 'w')
    heading=['Short name','Category','Band','Date','Remarks']
    
    f.write('sep=,')
    f.write('\n')
    for item in heading:
        f.write(item +',')
    f.write('\n')

    for i in range(max(len(t), len(l))):
        if i<len(l):
            f.write(l[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        f.write('')
        f.write(',')
        f.write('')
        f.write(',')

        if i < len(t):
            f.write(t[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        f.write('\n')

# short name to band
def write_map(_input):
    m={}
    short_to_band = {}
    file=open(_input + "\\" + 'raw_input.csv',"r")
    raw_data=file.read().split('\n')
    for d in raw_data[1:]:
        data_list = d.split(',') 
        if len(data_list[0]) == 0:
            break
        if len(data_list[1]) != 0:
            category = to_string(data_list[1])
            short_to_band[to_string(data_list[0])] = to_string(data_list[2])
          
            if category not in m:
                m[category] = []
            m[category].append(to_string(data_list[0]))


    # making pre, post list
    pre = [[],[],[],[],[],[]]
    post = [[],[],[],[],[],[]]

    for d in raw_data[1:]:
        data_list = d.split(',')
        if len(data_list) < 3:
            break

        if len(data_list[4]) != 0:
            remark = to_string(data_list[4])
            if remark[1] == 'r':
                pre[getPos(toLowerCase(remark))].append(to_string(data_list[3]))
            else:
                post[getPos(toLowerCase(remark))].append(to_string(data_list[3]))
        
    return [m, pre, post, short_to_band]
            
        
#write_to_file()
#result = write_map("C:\\Users\\DELL\\Documents\\folder")
#for item in result:
   # print(item)