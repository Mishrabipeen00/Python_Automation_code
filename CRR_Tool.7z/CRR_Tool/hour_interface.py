import os
from tkinter import *
import tkinter as tk
from tkinter import ttk
from gettime import getDates
from hourwise  import write_map
from hour_summary import Summary
from hourwise import write_to_file
from hour_data_graph import catGraph
import tkinter.messagebox
from tkinter import Tk, filedialog, Button, StringVar, OptionMenu
import xlsxwriter
from datetime import datetime
import time
 

# Get output name from file
def getOutputName(s):
    s_list = s.split('.')
    return s_list[0]+"Output"

root = Tk()    
root.geometry("800x500")
root.configure(bg='black')
open_output_file = ''
open_input_file = ''
date_list = None
short_name=None



    
#Title for tool
title = Label(root, text = "CRR Tool Dashboard",font=('Calisto MT',15),background='black',foreground='Red').place(x = 300, y = 6) 



lbl = ttk.Label(root, text = "Enter the Header for Graph and Summary Table:",background='black',foreground='White').place(x = 150,y = 40)

name = tk.Entry(root, width=13)
name.pack(pady=20)
name.place(x=420,y=40) 

def _submit():
    path=os.getcwd()
    folder=path+"\\"+"CRR_Tool\\input"
    files = os.listdir(folder)
    for filename in files:
        if filename == 'raw_input.csv':
            continue
        out=os.getcwd()
        outfolder=out+"\\"+"CRR_Tool\\output"
        _output = outfolder + '\\' + getOutputName(filename[0:]) + ".xlsx"
    
    workbook = xlsxwriter.Workbook(_output,{'strings_to_numbers':True})
    m, pre, post, dateToRemark, remarkNameList,short_to_band,valuelist,bandvaluelist=write_map()
    graph = catGraph(m,dateToRemark, remarkNameList)

    graph.generate(workbook,name.get())
    summary = Summary(workbook,pre,post,m,short_to_band,dateToRemark,valuelist,bandvaluelist) #pass open_output_file
    summary.call_category(name.get()) #pass open_input_file as fourth parameter
    print("output has been generated!!!")
    workbook.close()

#Function for clearing widgets
def clear_widgets():
    name.delete(0,END)
    
    
    

#Function for clearing widgets
def clear_text():
    name.delete(0,END)
    
    
    
    
b = Button(root,command=lambda: _submit(),text = "Generate Report",bg='red',  fg = 'blue')    
b.pack(ipadx=5, ipady=5,pady=5)
b.place(x=200, y=90)

clear = Button(root,command=clear_text,text = "Clear Widget",bg='red',  fg = 'blue')    
clear.pack(ipadx=5, ipady=5,pady=5)
clear.place(x=320, y=90)


d = Button(root,command=clear_widgets,text = "Clear",bg='red',  fg = 'blue')    
d.pack(ipadx=5, ipady=5,pady=5)
d.place(x=420, y=90)

root.mainloop()