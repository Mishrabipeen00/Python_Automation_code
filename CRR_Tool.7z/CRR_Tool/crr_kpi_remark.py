from openpyxl import Workbook, load_workbook
import os
path=os.getcwd()
folder=path+"\\"+"CRR_Tool\\crr_input.xlsx"

wb = load_workbook(folder)
ws1= wb["overall_calculation"]


def overall():
    overallmap={}
    for row in range(2, ws1.max_row + 1):
        key = ws1.cell(row, 1).value
        value = ws1.cell(row, 2).value
        overallmap[key] = value
    
    return overallmap

   

