import os
from socket import timeout
from tkinter import *
import tkinter as tk
from tkinter import ttk
from gettime import getDates
from cell_hourwise  import write_map
from cell_hourly_summary import Summary
from cell_hourwise import write_to_file
from cell_hourlywise_data_graph import catGraph
import tkinter.messagebox
from tkinter import Tk, filedialog, Button, StringVar, OptionMenu
from tkcalendar import Calendar, DateEntry
import xlsxwriter
from datetime import datetime
import time
 

# Get output name from file
def getOutputName(s):
    s_list = s.split('.')
    return s_list[0]+"Output"

#Create folder name
def getFolderName(ll):
    print(ll)
    items = ll.split('\\')
    s = ''
    for item in items:
        s += item + '\\'
    print(s)
    return s[:-2]




#Creating input filedialog askdirectory

def selectInputFolder():
    global open_input_file
    global date_list
    global short_name
    file_name = filedialog.askdirectory()
    ll = file_name.split('/')
    s = ''
    for l in ll:
        s += l + "\\\\"
    open_input_file = s[:-2]
    write_to_file(open_input_file)
    
#Creating output filedialog askdirectory
    
def selectOutputFolder():
    global open_output_file
    file_name = filedialog.askdirectory()
    ll = file_name.split('/')
    s = ''
    for l in ll:
        s += l + "\\\\"
    open_output_file = s[:-2]

        
    

# def getDate(d):
#     if d == "":
#         return d

#     dd = datetime.strptime(d,"%m/%d/%y")
#     sdate = dd.strftime("%d %b %y")
#     return sdate


#Function for Display message 
def onclick():
    tkinter.messagebox.showinfo("output location","Don't forget to Select output location")

def _submit(open_input_file,open_output_file,name):
    files = os.listdir(open_input_file)
    for filename in files:
        if filename == 'raw_input.csv':
            continue
        _output = open_output_file + '\\' + getOutputName(filename[0:]) + ".xlsx"
        break
    
    workbook = xlsxwriter.Workbook(_output,{'strings_to_numbers':True})
    shortnameToBand, pre, post, dateToRemark, remarkNameList, short_to_band,categoryToShortname,bandvaluelist=write_map(open_input_file)
    graph = catGraph(shortnameToBand,open_input_file,dateToRemark, remarkNameList,categoryToShortname)

    graph.generate(workbook,name.get())
    summary = Summary(workbook,pre,post,categoryToShortname,short_to_band,dateToRemark,bandvaluelist) #pass open_output_file
    summary.call_category(open_input_file,name.get()) #pass open_input_file as fourth parameter
    print("output has been generated!!!")
    workbook.close()

#Function for clearing widgets
def clear_widgets(name):
    name.delete(0,END)
    
    

#Function for clearing widgets
def clear_text(name):
    name.delete(0,END)
    
def interface4():
    root = Tk()    
    root.geometry("800x500")
    root.configure(bg='black')
    open_output_file = ''
    open_input_file = ''
    date_list = None
    short_name=None
#Title for tool
    title = Label(root, text = "CRR Tool Dashboard",font=('Calisto MT',15),background='black',foreground='Red').place(x = 300, y = 6) 

    #Input Button
    input_folder = Button(root, command=lambda:[selectInputFolder(),onclick()], text="Input File location")
    input_folder.pack(ipadx=5, ipady=5,pady=5)
    input_folder.place(x=5, y=40)

    #output Button
    output_folder = Button(root, command=selectOutputFolder, text="Output File location")
    output_folder.pack(ipadx=5, ipady=5,pady=5)
    output_folder.place(x=120, y=40)


    lbl = ttk.Label(root, text = "Enter the Header for Graph and Summary Table:",background='black',foreground='White').place(x = 250,y = 40)

    name = tk.Entry(root, width=13)
    name.pack(pady=20)
    name.place(x=520,y=40) 

        
        
        
    b = Button(root,command=lambda: _submit(open_input_file,open_output_file,name),text = "Generate Report",bg='red',  fg = 'blue')    
    b.pack(ipadx=5, ipady=5,pady=5)
    b.place(x=200, y=90)

    clear = Button(root,command=lambda:clear_text(name),text = "Clear Widget",bg='red',  fg = 'blue')    
    clear.pack(ipadx=5, ipady=5,pady=5)
    clear.place(x=320, y=90)


    d = Button(root,command=lambda:clear_widgets(name),text = "Clear",bg='red',  fg = 'blue')    
    d.pack(ipadx=5, ipady=5,pady=5)
    d.place(x=420, y=90)

    root.mainloop()