import os
import sys
from socket import timeout
from tkinter import *
import tkinter as tk
from tkinter import ttk
import tkinter.messagebox
from tkinter import Tk, filedialog, Button, StringVar, OptionMenu
from tkcalendar import Calendar, DateEntry
from cell_raw import write_to_filee,replaceComma
from hourwise import write_to_file
from cell_hourwise import write_to_file2
from cell_hourlycell_wise import write_to_file3,replaceComma
from cell_interfacee import interface2
from hour_interfacee import interface3
from cell_hourlywisw_interfacee import interfacecheck
from cell_hourly_interfacee import interface4


root = Tk()    
root.geometry("800x500")
root.configure(bg='black')




def secondcall():
    replaceComma()
    write_to_filee()
    interface2()
    
  
def thirdcall():
    write_to_file()
    interface3()
    
    

def fourthcall():
    write_to_file2()
    interface4()
    
    
def fifthcall():
    replaceComma()
    write_to_file3()
    interfacecheck()
    
    




    
#Title for tool
title = Label(root, text = "CRR Tool Dashboard",font=('Calisto MT',15),background='black',foreground='Red').place(x = 300, y = 6) 

#Input Button

#output Button
output_folder = Button(root, command=secondcall, text="CRR_Daily_Category && Cell_wise")
output_folder.pack(ipadx=5, ipady=5,pady=5)
output_folder.place(x=120, y=60)

output = Button(root, command=thirdcall, text="CRR_Hourly_Overall")
output.pack(ipadx=5, ipady=5,pady=5)
output.place(x=320, y=60)

input = Button(root, command=fourthcall, text="CRR_Hourly_Category")
input.pack(ipadx=5, ipady=5,pady=5)
input.place(x=440, y=60)

input2 = Button(root, command=fifthcall, text="CRR_Hourly_Cell_wise")
input2.pack(ipadx=5, ipady=5,pady=5)
input2.place(x=570, y=60)




root.mainloop()