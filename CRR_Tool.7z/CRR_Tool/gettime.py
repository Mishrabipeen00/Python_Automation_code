import os
import pandas as pd
from functools import cmp_to_key


year = {
    "Jan" : 0,
    "Feb" : 1,
    "Mar" : 2,
    "Apr" : 3,
    "May" : 4,
    "Jun" : 5, 
    "Jul" : 6,
    "Aug" : 7,
    "Sep" : 8,
    "Oct" : 9,
    "Nov" : 10, 
    "Dec" : 11
}

def calpoints(d):
    d_list = d.split('/')
    if len(d_list) == 1:
        d_list = d.split('-')
        if len(d_list) != 1:
            d_list[1] = year[d_list[1]]
    if len(d_list) == 1:
        d_list = d.split(' ')
        d_list[1] = year[d_list[1]]
    res = 0
    val = 1
    for item in d_list:
        res += int(item) * val
        val *= 10
    return res


def compare(d1, d2):
    d1_list = d1.split(',')
    d2_list = d2.split(',')

    points1 = calpoints(d1_list[0])
    points2 = calpoints(d2_list[0])

    if points1 < points2:
        return -1
    elif points1 == points2:
        if int(d1_list[1].split(':')[0].strip()) < int(d2_list[1].split(':')[0].strip()):
            return -1
        else:
            return 1
    else:
        return 1
    


def getDates():
    path=os.getcwd()
    folder=path+"\\"+"CRR_Tool\\input"
    files = os.listdir(folder)
    d=set()
    for filename in files:
        if filename == 'raw_input.csv':
            continue
        _input = folder + '\\' + filename
        df = pd.read_csv(_input,dtype={col: str for col in pd.read_csv(_input, nrows=1).columns})
        var=df.iloc[:,1].dropna()
        for line in var:
            d.add(line)

    l = list(d)
    l.sort(key=cmp_to_key(compare))
    for i in range(len(l)):
        l[i] = '"' + l[i] + '"'
    return l
    



    



