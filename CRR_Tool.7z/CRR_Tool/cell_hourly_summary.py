import xlsxwriter
from datetime import datetime,timedelta
import os
from cell_hourwise import write_map
from functools import cmp_to_key
from crr_criteria_calculation import criteria_cal

def isInt(x):
    try:
        int(x)
        return True
    except ValueError:
        return False

#To remove double quote from string
def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        s = s[1:]
    if s[-1:] == '"':
        s = s[0:-1]
    return s



def getKPIs(data):
    for i in range(2):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data


def getBandName(string):
    s = string.split('_')
    if isInt(s[0].split()[0]):
        return s[0] + " " + "Band"
    else:
        if(len(s) > 2):
            return s[-2] + " " + s[-1] + " " + "Band"
        else:
            return s[-1] + " " + "Band"

            



def getBands(data):
    temp = ['2300 C1 Band', '2300 C2 Band', '1800 Band', '850 C1 Band','850 C2 Band']
    # return l
    s = set()
    for line in data:
        line_list = line.split(',')
        if len(line_list[0]) != 0:
            s.add(getBandName(to_string(line_list[0])))
    #print(s)
    l = list(s)
    l.sort(key=cmp_to_key(compare)) # 4 temp[3:]
    for child in temp[len(l):]:
        l.append(child)
    #print(l)
    return l

def myFun(e):
      return e[2]
    



def isInt(x):
    try:
        int(x)
        return True
    except ValueError:
        return False

def compare(x1, y1):
    x = x1.split()
    y = y1.split()

    if int(x[0]) == int(y[0]): 
        if isInt(x[1][1]) and isInt(y[1][1]):
            if int(x[1][1]) < int(y[1][1]):
                return -1
            else:
                return 1
        else:
            if isInt(x[1][1]):
                return 1
            else: 
                return -1

    if int(x[0]) > int(y[0]):
        return -1
    return 1


def to_date(sdate):
    date_list = sdate.split('-')
    date_list2 = sdate.split('/')
    current_date = None
    if len(date_list) > 1:
        current_date = datetime.strptime(sdate,"%d-%m-%Y")
    
    elif len(date_list2) > 1:
        current_date = datetime.strptime(to_string(sdate), '%d/%m/%y')
    else:
        current_date = datetime.strptime(sdate,"%d %b %y")
    return current_date


def date_in_range(user_date, r, current_date):
        
    d1 = to_date(user_date)
    d2 = to_date(current_date)

    d  =  str(d2 - d1).split()
    
    if len(d) == 1:
        return True
    if int(d[0]) < r and int(d[0]) >= 0:
        return True
    else:
        return False



def date_in_list(l, scurr_date):
    current_date = to_date(scurr_date)
    for sdate in l:
        date = to_date(sdate)
        if date == current_date:
            return True
    return False
        

    
    

def get_delta(l):
    if len(str(l[0])) == 0 or len(str(l[1])) == 0 or float(l[0]) == 0:
        return 0.0
    
    ans = (float(l[1])-float(l[0]))*100/float(l[0])
    return ans


def getnew_remark(v,f,criteria):
    value = float(v)
    if f=="POS":
        # print(f) 
        if value >= -criteria and value <= criteria:
            return "No changes"
        
        elif value < -criteria:
            return "Degarded"
        else:
            return "Improved" 
    elif f=="NEG":
        if value >= -criteria and value <= criteria:
            return "No changes"
            
        elif value < -criteria:
            return "Improved"
        else:
            return "Degarded" 
    else:
        if value >= -5 and value <= 5:
            return "No changes"
            
        elif value < -5:
            return "Improved"
        else:
            return "Degarded"

def get_remark(v):
    value = float(v)
    if value >= -5 and value <= 5:
        return "No changes"
        
    elif value < -5:
        return "Improved"
    else:
        return "Degarded"
    

def make_range(row_no, inc):
    l = str(row_no)
    r = str(row_no + inc)
    s =  "A" + l + ":" + "D" + r
    return s


def isFloat(num):
    try:
        float(num)
        return True
    except ValueError:
        return False

def get_pre(pre_list, pos):
    date_list = pre_list[0].split(',')        
    res = "Pre"
    if pos > 0:
        res += " " + str(pos)
    res += "(" + to_string(pre_list[0]) + ' to ' + to_string(pre_list[-1]) + ")"

    return res

def get_post(post_list, nos):
    date_list = post_list[0].split(',')
    rest = "Post"
    if nos > 0:
        rest += " " + str(nos) 
    # Post 2
    rest += "(" + to_string(post_list[0]) + ' to ' + to_string(post_list[-1]) + ")"

    return rest


class Summary:
    def __init__(self, workbook, _pre_list, _post_list, _categoryToShortname, _short_to_band, _dateToRemark,_valuelist,_bandvaluelist):
        self.worksheet = workbook.add_worksheet("summary")
        self.condition = 0
        s = set()
        _bands = None
        for key in _short_to_band:
            s.add(_short_to_band[key])
        _bands = list(s)
        _bands.sort(key=cmp_to_key(compare)) # 4 temp[3:] 
        self.bands = _bands
        self.dateToRemark = _dateToRemark
        self.short_to_band = _short_to_band
        self.format1=workbook.add_format({'bg_color':'yellow'})
        self.format2=workbook.add_format({'bg_color':'green'})
        self.format3=workbook.add_format({'bg_color':'#D61C4E'})
        self.color_format=workbook.add_format({'border':1,
                                  'align':'center',
                                   'valign':'vcenter',
                                   'fg_color':'#C6DCE4','text_wrap':'true'})
        self.color_forma=workbook.add_format({'border':1,
                                   'align':'center',
                                   'valign':'vcenter',
                                   'fg_color':'#C6DCE4',
                                   'bold':True,'text_wrap':'true'})

        self.color_form=workbook.add_format({'bg_color':'black'})
        self.color_for=workbook.add_format({'border':1,'align':'center',
                                   'valign':'vcenter'})
        self.color_bol=workbook.add_format({'bold':True,'fg_color':'#C6DCE4','align':'center',
                                   'valign':'vcenter'})


        self.pre_list = _pre_list
        self.post_list = _post_list
        self.value_list=_valuelist
        self.categoryToShortname =_categoryToShortname
        self.bandvalue=_bandvaluelist

    def comparison(self,heading, ip, jp, shortname_list): 
        m = {}
        count = {}
        newkps=criteria_cal()
        path=os.getcwd()
        self.folder=path+"\\"+"CRR_Tool\\input"
        self.files = os.listdir(self.folder)
        file = open(self.folder + "\\" + self.files[0],'r')
        data = file.read().split('\n')
        data.pop()
        kpiss=getKPIs(data[0].split(','))
        bands = self.bands

                    
        row = 4
        if self.condition==0:
            for kpi in kpiss:
                self.worksheet.merge_range(make_range(row, len(bands)), kpi,self.color_format)
                row += len(bands) + 1
                    
        if self.condition >= 1:
                black_band = len(kpiss) * (len(bands) + 1) + 3
                self.worksheet.merge_range(0,4 + self.condition * 5, black_band - 1, 4 + self.condition*5,'',self.color_form)

        row = 3
        tcol = 4
        if self.condition >= 1:
            tcol += (self.condition) * 5
                    
                    
                    
        if self.condition == 0:
            self.worksheet.merge_range(row-3,tcol + 1,row-3,tcol+4,heading,self.color_bol)
            self.worksheet.merge_range(row-2,tcol-4,row-1,tcol-1,"KPI",self.color_forma)
            self.worksheet.merge_range(row-2, tcol, row-1, tcol, "Band",self.color_forma)
        if self.condition!=0:
            self.worksheet.merge_range(row-3,tcol + 1,row-3,tcol+4,heading,self.color_bol)
                
        self.worksheet.merge_range(row-2, tcol + 1,row-1, tcol + 1, get_pre(self.pre_list[ip], ip),self.color_forma)
        self.worksheet.merge_range(row-2, tcol + 2,row-1, tcol + 2, get_post(self.post_list[jp],jp),self.color_forma)
        self.worksheet.merge_range(row-2, tcol + 3, row-1, tcol + 3,"Delta %",self.color_forma)
        self.worksheet.merge_range(row-2, tcol + 4, row-1, tcol + 4,"Remark",self.color_forma)
        self.worksheet.set_column(tcol,tcol,12)
        self.worksheet.set_column(tcol+1,tcol+1,12)
        self.worksheet.set_column(tcol+2,tcol+2,12)
        self.worksheet.set_column(tcol+3,tcol+3,12)
        self.worksheet.set_column(tcol+4,tcol+4,12)
                
        if self.condition >=1:
            self.worksheet.set_column(tcol,tcol+1,2)

        for filename in self.files:
            if filename == 'raw_input.csv':
                continue
            file = open(self.folder + "\\" + filename) 
            datas = file.read().split('\n')
            datas.pop()
            bands = self.bands
            kpis = getKPIs(datas[0].split(','))
                    
                    
            row = 3
            for i in range(len(kpis)):
                idx = i + 3
                last_band = ''
                last_shortname = ''
                if i not in m:
                    m[i] = {}
                    for band in bands:
                        m[i][band] = [0,0]

                if i not in count:
                    count[i]={}
                    for band in bands:
                        count[i][band]=[0,0]
                        
            
                for data in datas[1:]:
                    line = data.split(',')

                    if len(line) < 2:
                        continue

                    if len(line[0]) != 0:
                        last_shortname = to_string(line[0])
                        last_band = self.short_to_band[last_shortname]
    
                    

                    
                    # if  date_in_list(self.pre_list[ip], to_string(line[1] + ',' + line[2])):
                    date = line[1] + ',' + line[2]
                    # print(date)
                    if last_shortname in shortname_list and date in self.dateToRemark and to_string(date) in self.pre_list[ip]:
                        count[i][last_band][0] += 1
                        if isFloat(line[idx]):
                            m[i][last_band][0] =  m[i][last_band][0] + float(line[idx])
                            

                    # if  date_in_list(self.post_list[jp], to_string(line[1] + ',' + line[2])):
                    if last_shortname in shortname_list and date in self.dateToRemark and to_string(date) in self.post_list[jp]:
                        count[i][last_band][1] += 1            
                        if isFloat(line[idx]):
                            m[i][last_band][1] = m[i][last_band][1] + float(line[idx])
                            

                

                    
        #print(m)                 
        for i in range(len(kpis)):
            col = 4 + self.condition * 5
            overall = [0,0,0,0]
            for key in m[i]:
                l = []
                if kpis[i] in self.bandvalue:
                    if count[i][key][0]!=0:
                        m[i][key][0] = m[i][key][0]/(count[i][key][0])
                    if count[i][key][1]!=0:
                        m[i][key][1] = m[i][key][1]/(count[i][key][1])
                l.append(m[i][key][0])
                l.append(m[i][key][1])
                delta=round(get_delta(l),2)
                type2 = newkps[kpis[i]][0] if kpis[i] in newkps else "nothing"
                self.worksheet.write(row, col, key,self.color_for)
                self.worksheet.write(row, col + 1, m[i][key][0],self.color_for)
                self.worksheet.write(row, col + 2, m[i][key][1],self.color_for)
                self.worksheet.write(row, col + 3, delta,self.color_for)
                self.worksheet.write(row, col + 4, getnew_remark(delta,type2,1),self.color_for)
                self.worksheet.conditional_format(row, col + 4, row, col + 4,{'type':'cell','criteria':'equal to','value':'"No changes"','format':self.format1})
                self.worksheet.conditional_format(row, col + 4, row, col + 4,{'type':'cell','criteria':'equal to','value':'"Improved"','format':self.format2})
                self.worksheet.conditional_format(row, col + 4, row, col + 4,{'type':'cell','criteria':'equal to','value':'"Degarded"','format':self.format3})
                if kpis[i] in self.value_list:
                    overall[0] += m[i][key][0]/(len(self.bands))
                    overall[1] += m[i][key][1]/(len(self.bands))
                    overall[2] += delta
                else:
                    overall[0] += m[i][key][0]
                    overall[1] += m[i][key][1]
                    overall[2] += delta
                    
                row += 1
            type2 = newkps[kpis[i]][0] if kpis[i] in newkps else "nothing"
            self.worksheet.write(row, col, "overall",self.color_for)
            self.worksheet.write(row, col + 1, overall[0],self.color_for)
            self.worksheet.write(row, col + 2, overall[1],self.color_for)
            self.worksheet.write(row, col + 3,round(get_delta([overall[0], overall[1]]), 2),self.color_for )
            self.worksheet.write(row, col + 4,getnew_remark(round(get_delta([overall[0], overall[1]]), 2),type2,1),self.color_for)
            self.worksheet.conditional_format(row, col + 4, row, col + 4,{'type':'cell','criteria':'equal to','value':'"No changes"','format':self.format1})
            self.worksheet.conditional_format(row, col + 4, row, col + 4,{'type':'cell','criteria':'equal to','value':'"Improved"','format':self.format2})
            self.worksheet.conditional_format(row, col + 4, row, col + 4,{'type':'cell','criteria':'equal to','value':'"Degarded"','format':self.format3})
            row += 1
        self.condition += 1
        
        
    def call_dates(self, shortname_list, heading):
        for ip  in range(len(self.pre_list)):
            for jp in range(len(self.post_list)):
                if len(self.pre_list[ip]) == 0 or len(self.post_list[jp]) == 0:
                    continue
                self.comparison(heading, ip, jp, shortname_list)

    def call_category(self,heading):
        categry=[]
        for category in self.categoryToShortname:
            categry.append(category)
        categry.sort(key=myFun,reverse=True)
        
        for cat in categry:
            shortname_list = self.categoryToShortname[cat]
            self.call_dates(shortname_list, heading + "(" + cat + ")-")



# shortnameToBand, pre, post, dateToRemark, remarkNameList,short_to_band,categoryToShortname=write_map("C:\\Users\\DELL\\Documents\\folder")   
# workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\outputfile.csv',{'strings_to_numbers':True})
# summary = Summary(workbook,pre,post,categoryToShortname,short_to_band, dateToRemark)
# _input = "C:\\Users\\DELL\\Documents\\folder"
# summary.call_category(_input,'heading')

# workbook.close()

