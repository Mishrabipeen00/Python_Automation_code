import xlsxwriter
import os
from datetime import datetime, timedelta
from functools import cmp_to_key
from gettime import getDates
from kpiformulamaking import getVariables, replace_percent
from formulakpi import formula_kpi
from final_kpi import final_kpi



def isInt(x):
    try:
        int(x)
        return True
    except ValueError:
        return False

# kpis, bands, toband
def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        s = s[1:]
    if s[-1:] == '"':
        s = s[0:-1]
    return s

def remove_single_quoute(s):
    if len(s) == 0:
        return s
    if s[0] == "'":
        return s[1:-1]
    else:
        return s

def getTime(i):
    m = {
        0:'00:00',
        1:'01:00', 
        2:'02:00', 
        3:'03:00', 
        4:'04:00', 
        5:'05:00', 
        6:'06:00', 
        7:'07:00', 
        8:'08:00', 
        9:'09:00', 
        10:'10:00',
        11:'11:00',
        12:'12:00',
        13:'13:00',
        14:'14:00',
        15:'15:00',
        16:'16:00',
        17:'17:00',
        18:'18:00',
        19:'19:00',
        20:'20:00',
        21:'21:00',
        22:'22:00',
        23:'23:00'
    }

    return m[i]

# Function for getting band name
def getBandName(string):
    s = string.split('_')
    if isInt(s[0].split()[0]):
        return s[0] + " " + "Band"
    else:
        if(len(s) > 2):
            return s[-2] + " " + s[-1] + " " + "Band"
        else:
            return s[-1] + " " + "Band"



# Function for getting kpi
def getKPIs(data):
    d = data.split(',')
    d.pop(0)
    d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d


def to_date(s):
    s_list = s.split('-')
    if len(s_list) > 1:
        date = datetime.strptime(to_string(s), '%d-%b-%y')
        return date
    else:
        date = datetime.strptime(to_string(s), '%d %b %y')
        return date



def changeDateFormat(date):
    # 14/07/22
    new_date = datetime.strptime(to_string(date), '%d/%m/%y')
    new_new_date = datetime.strftime(new_date, '%d-%m-%Y')
    return new_new_date


def compare(x1, y1):
    x = x1.split()
    y = y1.split()
    
    

    if int(x[0]) == int(y[0]): 
        if isInt(x[1][1]) and isInt(y[1][1]):
            if int(x[1][1]) < int(y[1][1]):
                return -1
            else:
                return 1
        else:
            if isInt(x[1][1]):
                return 1
            else: 
                return -1

    if int(x[0]) > int(y[0]):
        return -1
    return 1




def getCategory(s):
    s_list = s.split('_')
    return s_list[4]

def getname(s):
    sname=s.split('_')
    if isInt(sname[0].split()[0]):
        return '_'.join(sname[1:3])
    else:
        return '_'.join(sname[0:1])

    
def myFun(e):
      return e[2]
         

def name(s):
    name=s.split('_')
    if isInt(name[0].split()[0]):
        return '_'.join(name[3:])
    else:
        return '_'.join(name[0:])    

def getPos(dates):
    pos = {
        '00:00' :0,
        '01:00' :1, 
        '02:00' :2, 
        '03:00' :3, 
        '04:00' :4, 
        '05:00' :5, 
        '06:00' :6, 
        '07:00' :7, 
        '08:00' :8, 
        '09:00' :9, 
        '10:00' :10,
        '11:00' :11,
        '12:00' :12,
        '13:00' :13,
        '14:00' :14,
        '15:00' :15,
        '16:00' :16,
        '17:00' :17,
        '18:00' :18,
        '19:00' :19,
        '20:00' :20,
        '21:00' :21,
        '22:00' :22,
        '23:00' :23
    }
    
    return pos

def remove_zero_division(s, ans):
    idx = len(ans)
    ans.append(1)
    express = ""
    for i in range(len(s)):
       
       
        if i >= len(s):
            continue

        if s[i] == '/':
            end = i
            if i < len(s) and isInt(s[i + 1]):
                continue
            if s[i + 1] == '(':
                tmp_ans = 0
                f = -1
                while(i < len(s) and i != ')'):
                    if isInt(s[i]) and s[i - 1] == '[':
                        tmp_ans += ans[int(s[i])]
                        if f == -1:
                            f = i
                    i += 1
                if tmp_ans == 0:
                    express = s[0:f] + str(idx) + s[f + 1:]
                    s= express

            else:
                if ans[int(s[i + 5])] != 0:
                    continue
                express += s[:end + 1]
                while(s[i] != ']'): # finding last pos of ans[idx]
                    i += 1
                express += 'ans[' + str(idx) + s[i:]
                s = express
            
    return [s, ans]

def compare_var(s1, s2):
    if len(s1) > len(s2):
        return -1
    else:
        return 1


class catGraph:

    def __init__(self,_shortnameToBand, _dateToRemark,_remarkNameList, _categoryToShortname ):
        #self.folder = _folder
        self.dates = getDates() # it will return date with hour time
        self.pos = getPos(self.dates)
        path=os.getcwd()
        self.folder=path+"\\"+"input"
        self.files = os.listdir(self.folder)
        self.categoryToShortname = _categoryToShortname
        self.shortnameToBand = _shortnameToBand
        self.dateToRemark = _dateToRemark
        self.expected_length = 0
        self.remarkNameList = _remarkNameList
        self.name = ''
        self.end_col = 0
        self.end_row = 0
        

        
        self.pcol = 1
        self.row = 2
        self.f = 0
        self.wrow = 2
        

    def make_dates(self):
        return 24
        


    def write_to_temp_map(self, my_data,shortname, category):
        for filename in self.files:
            if filename == 'raw_input.csv':
                continue
            file = open(self.folder + "\\" + filename) 
            raw_data = file.read().split('\n')
            raw_data.pop()
            self.kpis = getKPIs(raw_data[0])
            _len = self.make_dates() # return no. of dates or no. of hours count
            last_short_name = None
            self.remark=""
            last_remark = ""
            for data in raw_data[1:]:
                data_list = data.split(',') 

                new_date = data_list[1] + ',' + data_list[2]
                if len(data_list[0]) != 0:
                    last_short_name = to_string(data_list[0])
                    self.remark=getname(to_string(data_list[0]))
                    self.name=name(to_string(data_list[0]))
                
                # print("First time " , new_date)
                # if not checkValidDate(new_date, self.dateToRemark):
                #     print(new_date)
                #     continue



                #Initializing my_data[kpi] as a map
                for kpi in self.kpis:
                    if kpi not in my_data:
                        my_data[kpi] = {}
                    else:
                        break
                
                # print("sEdond tiem ", new_date)
                if new_date in self.dateToRemark.keys():
                    last_remark = self.dateToRemark[new_date]
                else:
                    continue

               

                    
                for i in range(len(data_list[3:])):
                    if last_remark not in my_data[self.kpis[i]]:
                        my_data[self.kpis[i]][last_remark] = [0 for i in range(_len)]
                        #dont forgot to fill list

                    
 

                    # if last_short_name in self.categoryToShortname[category]:
                    if last_short_name == shortname:
                        if data_list[i + 3] == '':
                            data_list[i + 3] = 0
                        my_data[self.kpis[i]][last_remark][self.pos[to_string(data_list[2].strip())]] += float(data_list[i + 3])


                        
                    
   
    def write_to_file(self, my_data, cat,bandName,workbook, worksheet, worksheet1,heading):
        non_kpi_map = formula_kpi()
        final=final_kpi()
        color=workbook.add_format({'fg_color':'#C6DCE4'})
        color_format=workbook.add_format({'bold':True,'fg_color':'#C6DCE4','align':'center',
                                   'valign':'vcenter'})

        row = 2
        tcol = 4
        if self.f == 0:
            worksheet.write(row-1, 3, "Hour")
            worksheet.write(row-1, 1, "Remarks2")
            worksheet.write(row-1, 2, "Actual Band")
            worksheet.write(row-1, 0, "Remarks3")
        
        if self.f == 0:
            for kpi in self.kpis:
                if kpi in final:
                    if len(self.remarkNameList) > 1:
                        worksheet.merge_range(0, tcol, 0, tcol+len(self.remarkNameList) - 1, kpi,color)
                    else:
                        worksheet.write(0,tcol,kpi, color)
                    for remark in self.remarkNameList:
                        worksheet.write(1, tcol, remark)
                        tcol += 1
            for kpi in non_kpi_map:
                if kpi in final:
                    if len(self.remarkNameList) > 1:
                        worksheet.merge_range(0, tcol, 0, tcol+len(self.remarkNameList) - 1, kpi,color)
                    else:
                        worksheet.write(0,tcol,kpi, color)
                    
                    for remark in self.remarkNameList:
                        worksheet.write(1, tcol, remark)
                        tcol+=1
            
        non_kpi_map = formula_kpi()
        for i in range(24):
            worksheet.write(self.wrow, 1, cat)
            worksheet.write(self.wrow,0,self.remark)
            worksheet.write(self.wrow,2,bandName)
            worksheet.write(self.wrow,3,to_string(getTime(i)))
            
            
               
            col = 4
            for kpi in self.kpis:
                if kpi in final:
                    for remark in self.remarkNameList:
                        worksheet.write(self.wrow, col, my_data[kpi][remark][i])
                        col += 1
                        self.end_col = col


            #formula calculation
            for kpi in non_kpi_map:
                if kpi in final:
                    for remark in self.remarkNameList:
                        res = 0
                        kpi_formula = non_kpi_map[kpi]
                        var_list = getVariables(kpi_formula)
                        var = list(set(var_list)) # remove duplicate variables
                        var.sort(key=cmp_to_key(compare_var))
                        ans = []
                        for idx in range(len(var)):
                            new_string = 'ans[' + str(idx) + ']'
                            kpi_formula = kpi_formula.replace(var[idx], new_string)
                            ans.append(my_data[remove_single_quoute(var[idx])][remark][i]) # data of kpi of band and ith date
                        
                    
                        if kpi_formula[0]=="=":
                            kpi_formula = kpi_formula[1:]
                        kpi_formula = replace_percent(kpi_formula)
                        kpi_formula, ans = remove_zero_division(kpi_formula,ans)#formatting for zero division error
                        res = eval(kpi_formula)
                        worksheet.write(self.wrow, col, res) #4
                        col += 1
            
        
            self.wrow += 1

            

            

        
       
        prow = 3
        worksheet1.merge_range(0, self.pcol, 0, self.pcol + 7, heading +"("+ cat +")" + "-" "(" + bandName + ")- ",color_format)
        col = 4
        for kpi in self.kpis:
            if kpi in final:
                if self.f == 0:
                    worksheet1.write(prow, 0, kpi)
                chart = workbook.add_chart({'type': 'line'})       
                worksheet1.insert_chart(prow, self.pcol, chart)
                    
                chart.set_title({'name': to_string(kpi)})
                chart.set_legend({'position': 'bottom'})
                #chart.set_x_axis({'text_axis': True})
                #chart.set_x_axis({'minor_unit': 0.4, 'major_unit': 2})

                for remark in self.remarkNameList:
                        chart.add_series({'name' : remark,'categories': '=KPI_Day!$D$3:$D$26' ,'values' : ['KPI_Day',self.row, col, self.row + 24 - 1, col]})
                        col += 1
                prow += 17
        
        for kpi in non_kpi_map:
            if kpi in final:
                if self.f == 0:
                    worksheet1.write(prow, 0, kpi)
                chart = workbook.add_chart({'type': 'line'})       
                worksheet1.insert_chart(prow, self.pcol, chart)
                    
                chart.set_title({'name': to_string(kpi)})
                chart.set_legend({'position': 'bottom'})
                #chart.set_x_axis({'text_axis': True})
                #chart.set_x_axis({'minor_unit': 0.4, 'major_unit': 2})

                for remark in self.remarkNameList:
                        chart.add_series({'name' : remark,'categories': '=KPI_Day!$D$3:$D$26' ,'values' : ['KPI_Day',self.row, col, self.row + 24 - 1, col]})
                        col += 1
                prow += 17
        self.pcol += 8
        self.row += 24
        self.f = 1
    


    def generate(self,workbook,heading): # takes workbook and heading
        #workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\outputfile.csv',{'strings_to_numbers':True})
        worksheet = workbook.add_worksheet('KPI_Day')   
        worksheet1 = workbook.add_worksheet('Graph_Day')
        # for key in self.mapping:
        #     bandList.append(key)
        
        #sort bandList using comparator
        # for k in self.mapp:
        #     my_data = {}
        # for key in bandList:
        #     my_data = {}
        #     self.write_to_temp_map(my_data, k,key)
        #     self.write_to_file(my_data,k, key, workbook, worksheet, worksheet1,heading) 
        #print(self.categoryToShortname)
        categry=[]
        for category in self.categoryToShortname:
            categry.append(category)
        categry.sort(key=myFun,reverse=True)
        for category in self.categoryToShortname:
            my_data = {}
        for cat in categry:
            for shortname in self.categoryToShortname[cat]:
                #print(category)
                    self.write_to_temp_map(my_data, shortname, cat)
                    self.write_to_file(my_data, cat, self.shortnameToBand[shortname], workbook, worksheet, worksheet1, heading)

    
    
        #workbook.close()
            
            #temp_map
            #write into file
           

            
        

    
# mapping = {'mumbai' : ['1800_OR_OR_Circle_CDU_PKG900P2a_gb', '2300 C1_OR_OR_Circle_RDU_PKG900P2a_gb'],
#             'nagpur' : ['850_OR_OR_Circle_RDU_PKG900P2a_gb', '2300 C1_OR_OR_Circle_CDU_PKG900P2a_gb', '850_OR_OR_Circle_Overall_PKG900P2a_gb']
#     }
# workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\outputfile.csv',{'strings_to_numbers':True})
# shortnameToBand, pre, post, dateToRemark, remarkNameList, _ , categoryToShortname = write_map()
# graph = catGraph(shortnameToBand, "C:\\Users\\DELL\\Documents\\folder", dateToRemark, remarkNameList, categoryToShortname)
# graph.generate(workbook, "heading")
# workbook.close()

