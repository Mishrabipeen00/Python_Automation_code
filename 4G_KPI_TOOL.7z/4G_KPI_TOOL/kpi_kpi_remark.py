import os
def remark_map():
    map={}
    path=os.getcwd()
    folder=path+"\\"+"remark"
    files = os.listdir(folder)
    for file in files:
        if file=="remark_check.csv":
            continue
        f=open(folder + "\\" + file,"r")
        raw_data=f.read().split('\n')
        for data in raw_data[1:]:
            data_list = data.split(',') 
            if len(data_list)<2:
                continue   #check wheter sheet dat is greater than 2 or not
            if len(data_list[0]) != 0:
                kpis = data_list[0]
            if kpis not in map:
                map[kpis]=data_list[1]
    #print(len(map))

    return map