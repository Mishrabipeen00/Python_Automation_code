from numpy import NaN
import xlsxwriter
import os
from band_calculation import band_calculation
from gettime import getDates
import pandas as pd
from datetime import datetime, timedelta
from functools import cmp_to_key
from formulakpi import formula_kpi
from raw_kpi import raw_kpi
from final_kpi import final_kpi
from band_calculation import band_calculation

# kpis, bands, toband
def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        s = s[1:]
    if s[-1:] == '"':
        s = s[0:-1]
    return s

def isInt(x):
    try:
        int(x)
        return True
    except ValueError:
        return False

def getPoints(x):
    x_list = x.split('/')
    f = 1
    ans = 0
    for i in range(len(x_list)):
        ans += int(x_list[i]) * f
        f *= 10
    
    return ans

def compare(x1, y1):
    x = getPoints(x1)
    y = getPoints(y1)
    

    if x < y:
        return -1
    else:
        return 1
    
    
def getKPIs(data):
    for i in range(2):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data

def toLowerCase(s):
    return s.strip().lower()

def getPrePosName(i):
    m = {
        0 : 'pre',
        1 : 'pre1',
        2 : 'pre2',
        3 : 'pre3',
        4 : 'pre4',
        5 : 'pre5'
    }

    return m[i]

def getPostPosName(i):
    m = {
        0 : 'post',
        1 : 'post1',
        2 : 'post2',
        3 : 'post3',
        4 : 'post4',
        5 : 'post5'
    }

    return m[i]

def getPos(s):
    prePos = {
        'pre' : 0,
        'pre1': 1,
        'pre2': 2,
        'pre3': 3,
        'pre4': 4,
        'pre5': 5
    }

    postPos = {
        'post' : 0,
        'post1' : 1,
        'post2' : 2,
        'post3':  3,
        'post4':  4,
        'post5':  5
    }

    if s[1] == 'r':
        return prePos[s]
    else: 
        return postPos[s]

def getOnlyDates():
    l = getDates()
    d = set()
    for item in l:
        date = item.split(',')[0]
        d.add(to_string(date))
    return list(d)

def make_raw():
    l=[]
    t=set()
    last_short_name = None
    path=os.getcwd()
    folder=path+"\\"+"input"
    files=os.listdir(folder)

    f = 0
    for filename in files:
        if filename == 'raw_input.csv':
            continue
        if f == 1:
            break
        f += 1
        file = open(folder + "\\" + filename)
        data = file.read().split('\n')
        for d in data:
            data_list = d.split(',')
            if len(data_list[0]) != 0:
                last_short_name = to_string(data_list[0])
                l.append(last_short_name)
        
   
    return l[1:]

def all_kpi():
    all_kpis = getkpis()
    non_kpi = non_kpis_formula()
    for kpi in non_kpi:
        all_kpis.append(kpi)

    return all_kpis

def finalkpi():
    finall_kpi=[]
    kpilist=final_kpi()
    for kpi in kpilist:
        finall_kpi.append(kpi)
    return finall_kpi

def non_kpis_formula():
    kpi_list=[]
    non_kpis_formula=formula_kpi()
    for kpis in non_kpis_formula:
        kpi_list.append(kpis)
    return kpi_list



def getkpis():
    path=os.getcwd()
    folder=path+"\\"+"input"
    files=os.listdir(folder)
    file = open(folder+ "\\" + files[0],'r')
    data = file.read().split('\n')
    kpis = getKPIs(data[0].split(','))
    return kpis

def write_to_filee():
    l = make_raw()
    t=getDates()
    all_k=finalkpi()
    remark_kpi_1=raw_kpi()
    band_cal=band_calculation()
    path=os.getcwd()
    folder=path+"\\"+"input"
    f = open(folder + "\\" +'raw_input.csv', 'w')
    heading=['Short name','Band','Date','Remarks',"KPI","Value","BandCalculation"]
    
    f.write('sep=,')
    f.write('\n')
    for item in heading:
        f.write(item +',')
    f.write('\n')
    for i in range(max(len(all_k),len(t), len(l),len(remark_kpi_1),len(band_cal))):
        if i<len(l):
            f.write(l[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        f.write('')
        f.write(',')
       

        if i < len(t):
            f.write(t[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        f.write('')
        f.write(',')

        if i < len(all_k):
            f.write(all_k[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        if i < len(remark_kpi_1):
            f.write(remark_kpi_1[all_k[i]])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        if i < len(band_cal):
            f.write(band_cal[all_k[i]])
            f.write(',')
        else:
            f.write('')
            f.write(',')
        f.write('\n')




def write_map():
  
    m={}
    #short_to_band = {}
    path=os.getcwd()
    folder=path+"\\"+"input"
    file=open(folder + "\\" + 'raw_input.csv',"r")
    raw_data=file.read().split('\n')
    for d in raw_data[1:]:
        data_list = d.split(',') 
        if len(data_list[0]) == 0:
            break
        if len(data_list[1]) != 0:
            category = to_string(data_list[1])
           # short_to_band[to_string(data_list[0])] = to_string(data_list[2])
          
            if category not in m:
                m[category] = []
            m[category].append(to_string(data_list[0]))
    
    short_to_band={}
    # making pre, post list
    pre = [[],[],[],[],[],[]]
    post = [[],[],[],[],[],[]]
    valuelist=[]
    bandvaluelist=[]
    dateToRemark = {}
    for d in raw_data[1:]:
        data_list = d.split(',')
        if len(data_list) < 2:
            break

        
        if len(data_list[0]) != 0:
            last_shortname = to_string(data_list[0])
            short_to_band[last_shortname] = data_list[1]


        date=data_list[2] + ',' + data_list[3]
        # print(data_list)
        if len(data_list) <=7:
            data_list.insert(0, '')
        if len(data_list[4]) != 0:
            remark = to_string(data_list[4])
            #print(remark)
            dateToRemark[date] = toLowerCase(remark)
            
            if remark[1] == 'r':
                pre[getPos(toLowerCase(remark))].append(to_string(date))
            else:
                post[getPos(toLowerCase(remark))].append(to_string(date)) 
        

        # print(data_list)
        
        if len(data_list[6])!=0:
            value=to_string(data_list[6])
            if value[1]=='v':
                valuelist.append(to_string(data_list[5])) 

        if len(data_list[7])!=0:
            bandvalue=to_string(data_list[7])
            if bandvalue[1]=='v':
                bandvaluelist.append(to_string(data_list[5]))      

    remarkNameList = []

    for i in range(len(pre)):
        if len(pre[i]) != 0:
            remarkNameList.append(getPrePosName(i))
    

    for i in range(len(post)):
        if len(post[i]) != 0:
            remarkNameList.append(getPostPosName(i))
    return [m, pre, post, dateToRemark, remarkNameList, short_to_band,valuelist,bandvaluelist]
            
           
#write_to_file("C:\\Users\\DELL\\Documents\\folder")
# result = write_map("C:\\Users\\DELL\\Documents\\folder")
# for item in result:
#     print(item)









