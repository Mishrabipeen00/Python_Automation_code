from tkinter import *
import tkinter as tk
from tkinter import ttk
import tkinter.messagebox
from tkinter import Tk, filedialog, Button, StringVar, OptionMenu
from tkcalendar import Calendar, DateEntry
from kpifiles import write_to_file,replaceComma
from kpi_hourwise import write_to_filee
from kpii_catwise import write_to_file2
from kpi_cell_hourwise import write_to_file3,replaceComma
from kpi_interfacee import kpi_daily_interface
from kpi_hourwise_interfacee import kpi_hourwise
from kpi_catinterfacee import kpi_cat_interface
from kpi_cell_hour_interfacee import kpi_cell_interface


root = Tk()    
root.geometry("800x500")
root.configure(bg='black')




def secondcall():
    replaceComma()
    write_to_file()
    kpi_daily_interface()
    

def thirdcall():
    write_to_filee()
    kpi_hourwise()
    
    

def fourthcall():
    write_to_file2()
    kpi_cat_interface()
    
    
def fifthcall():
    replaceComma()
    write_to_file3()
    kpi_cell_interface()
    
    




    
#Title for tool
title = Label(root, text = "KPI Tool Dashboard",font=('Calisto MT',15),background='black',foreground='Red').place(x = 300, y = 6) 

#Input Button

#output Button
output_folder = Button(root, command=secondcall, text="KPI_Daily_Category && Cell_wise")
output_folder.pack(ipadx=5, ipady=5,pady=5)
output_folder.place(x=120, y=60)

output = Button(root, command=thirdcall, text="KPI_Hourly_Overall")
output.pack(ipadx=5, ipady=5,pady=5)
output.place(x=320, y=60)

input = Button(root, command=fourthcall, text="KPI_Hourly_Category")
input.pack(ipadx=5, ipady=5,pady=5)
input.place(x=440, y=60)

input2 = Button(root, command=fifthcall, text="KPI_Hourly_Cell_wise")
input2.pack(ipadx=5, ipady=5,pady=5)
input2.place(x=570, y=60)




root.mainloop()