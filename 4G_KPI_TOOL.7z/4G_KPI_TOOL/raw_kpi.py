from openpyxl import Workbook, load_workbook
import os
path=os.getcwd()
folder=path+"\\"+"kpi_input.xlsx"

wb = load_workbook(folder)
ws1= wb["raw"]


def raw_kpi():
    raw_kpi_remark = {}
    for row in range(2, ws1.max_row + 1):
        key = ws1.cell(row, 1).value
        value = ws1.cell(row, 2).value
        raw_kpi_remark[key] = value
    
    return raw_kpi_remark



        
