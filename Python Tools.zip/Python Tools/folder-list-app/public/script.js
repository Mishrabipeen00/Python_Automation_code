document.addEventListener('DOMContentLoaded', function () {
  const folderSelect = document.getElementById('folderSelect');

  // Clear existing options (in case there are any)
  folderSelect.innerHTML = '';

  // Fetch folder names from the server
  fetch('/folders')
    .then(response => response.json())
    .then(folderNames => {
      // Create an initial "Select a folder" option
      const defaultOption = document.createElement('option');
      defaultOption.text = '';
      folderSelect.add(defaultOption);

      // Populate the dropdown with folder names
      folderNames.forEach(folderName => {
        const option = document.createElement('option');
        option.text = folderName;
        folderSelect.add(option);
      });
    })
    .catch(error => console.error('Error fetching folder names:', error));
});

function submitForm() {
  const folderSelect = document.getElementById('folderSelect');
  const selectedFolder = folderSelect.value;

  if (!selectedFolder) {
    alert("Please select a folder first.");
    return;
  }

  // Fetch the HTML file content for the selected folder
  fetch(`/fileContent?folder=${encodeURIComponent(selectedFolder)}`)
    .then(response => response.text())
    .then(fileContent => {
      // Calculate the center position for the popup window
      const screenWidth = window.screen.width;
      const screenHeight = window.screen.height;
      const popupWidth = 600;
      const popupHeight = 400;
      const leftPosition = (screenWidth - popupWidth) / 2;
      const topPosition = (screenHeight - popupHeight) / 2;

      // Create a new popup window
      const popupWindow = window.open('', 'ReadMePopup', `width=${popupWidth},height=${popupHeight},left=${leftPosition},top=${topPosition},resizable=yes,scrollbars=yes`);

      // Display the HTML file content in the popup window
      popupWindow.document.write('<pre>' + fileContent + '</pre>');
    })
    .catch(error => console.error('Error fetching file content:', error));
}

function submitForm2() {
  const folderSelect = document.getElementById('folderSelect');
  const selectedFolder = folderSelect.value;

  if (!selectedFolder) {
    alert("Please select a folder first.");
    return;
  }

  // Fetch the Python script for the selected folder
  fetch(`/runPythonScript?folder=${encodeURIComponent(selectedFolder)}`)
    .then(response => response.text())
    .then(scriptOutput => {
      // Display the output of the Python script
      console.log('Output of Python script:', scriptOutput);
      // You can handle the script output as needed
    })
    .catch(error => console.error('Error running Python script:', error));
}


