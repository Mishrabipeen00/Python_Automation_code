const express = require('express');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const app = express();
const PORT = 3000;

app.use(express.static('public'));

app.get('/folders', (req, res) => {
  const directoryPath = 'D:/Python Tools/folder-list-app/tools';
  const folderNames = getFolderNames(directoryPath);
  res.json(folderNames);
});

app.get('/fileContent', (req, res) => {
  const selectedFolder = req.query.folder;
  const directoryPath = 'D:/Python Tools/folder-list-app/tools'; // Make sure this matches the folder path in '/folders'
  const filePath = path.join(directoryPath, selectedFolder, 'readme.txt');

  // Read the HTML file content
  fs.readFile(filePath, 'utf-8', (err, data) => {
    if (err) {
      console.error('Error reading file:', err);
      res.status(500).send('Error reading file');
      return;
    }

    res.send(data);
  });
});

app.get('/runPythonScript', (req, res) => {
  const selectedFolder = req.query.folder;
  const directoryPath = 'D:/Python Tools/folder-list-app/tools'; // Make sure this matches the folder path in '/folders'
  const pythonScriptPath = path.join(directoryPath, selectedFolder, 'test.py');

  // Run the Python script
  exec(`python "${pythonScriptPath}"`, (err, stdout, stderr) => {
    if (err) {
      console.error('Error running Python script:', err);
      res.status(500).send('Error running Python script');
      return;
    }
    console.log('File Excecuted:', stdout);
    res.send(stdout);
  });
});

function getFolderNames(directoryPath) {
  return fs.readdirSync(directoryPath, { withFileTypes: true })
    .filter(dirent => dirent.isDirectory())
    .map(dirent => dirent.name);
}

app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});


