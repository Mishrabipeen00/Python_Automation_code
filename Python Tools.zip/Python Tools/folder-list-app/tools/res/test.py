# def multiply_and_save_to_file(num1, num2, filename):
#     result = num1 * num2
#     with open(filename, 'w') as file:
#         file.write(str(result))

# if __name__ == "__main__":
#     num1=4
#     num2=5
#     filename = 'output.txt'
#     multiply_and_save_to_file(num1, num2, filename)

#     print(f"The result has been saved to {filename}.")



import os
from tkinter import *
import tkinter as tk
from tkinter import ttk
import tkinter.messagebox
from tkinter import Tk, filedialog, Button, StringVar, OptionMenu
import xlsxwriter


# Get output name from file
def getOutputName(s):
    s_list = s.split('.')
    return s_list[0]+"Output"

#Create folder name
def getFolderName(ll):
    print(ll)
    items = ll.split('\\')
    s = ''
    for item in items:
        s += item + '\\'
    print(s)
    return s[:-2]


root = Tk()   
root.geometry("800x500")
root.configure(bg='black')
open_output_file = ''
open_input_file = ''
date_list = None
short_name=None

#Creating input filedialog askdirectory

def selectInputFolder():
    global open_input_file
    global date_list
    global short_name
    file_name = filedialog.askdirectory()
    ll = file_name.split('/')
    s = ''
    for l in ll:
        s += l + "\\\\"
    open_input_file = s[:-2]
    

#Creating output filedialog askdirectory
    
def selectOutputFolder():
    global open_output_file
    file_name = filedialog.askdirectory()
    ll = file_name.split('/')
    s = ''
    for l in ll:
        s += l + "\\\\"
    open_output_file = s
    
#Function for Display message 
def onclick():
    tkinter.messagebox.showinfo("output location","Don't forget to Select output location")
    
#output Button
output_folder = Button(root, command=selectOutputFolder, text="Input File location")
output_folder.pack(ipadx=5, ipady=5,pady=5)
output_folder.place(x=282, y=50)

input_folder = Button(root, command=selectInputFolder, text="Output File location")
input_folder.pack(ipadx=5, ipady=5,pady=5)
input_folder.place(x=282, y=100)

root.mainloop()