Closed. This question needs to be more focused. It is not currently accepting answers.
Want to improve this question? Update the question so it focuses on one problem only by editing this post.

Closed 8 years ago.

I am seeking some help. I am very new to programming and I’m working on a new project.

The objective is to display the contents of a plain text file in a web page.

The text file (named title.txt) and has a single line of text The text file is located on my server The text content changes every three minutes or so.

I wish to read this file and display its content in a web page The web browser is to automatically re-read the file every three minutes or so.