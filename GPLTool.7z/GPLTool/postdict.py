import re
import os
import json
pattern = r"NODE-PATH=(.*)\n"
pattern2 = re.compile(r'^\[.*\] NE=.* , USER=.* , USER_IP=.* , OPERATION=.* , RESULT=.*\n\n?$')
pattern3 = re.compile(r'^RPC-REPLY-TABLE=\s*([^;]*);?\s*$')

def texttoparsepost():
    current_dir = os.getcwd()
    input_folder = os.path.join(current_dir, "GPLTool", "postinput")
    file_list = os.listdir(input_folder)

    counter = 0
    current_columns = []
    current_values = []
    postdict = {}
    key = ""
    for file_name in file_list:
        file_path = os.path.join(input_folder, file_name)
        with open(file_path, 'r') as f:
            for line in f:
                if line.startswith('NE Name'):
                    line = line.replace('NE Name', 'NE_Name').replace('NE ID', 'NE_Id')
                match = re.search(pattern, line)
                if match:
                    key = match.group(1)         
                elif line.startswith('-'):
                    if counter == 2 :
                        counter = 0
                    else:
                        counter += 1
                elif counter == 1:
                    current_columns = line.split()
                elif counter == 2:
                    if key not in postdict:
                        postdict[key] = {}

                    current_values = line.split()

                    for col in current_columns:
                        if col not in postdict[key]:
                            postdict[key][col] = []

                    for i in range(len(current_values)):
                        postdict[key][current_columns[i]].append(current_values[i])

    for key in postdict.keys():
        if 'NE_Name' in postdict[key]:
            del postdict[key]['NE_Name']
        if 'NE_Id' in postdict[key]:
            del postdict[key]['NE_Id']
    
    
    
    return postdict





    

    
