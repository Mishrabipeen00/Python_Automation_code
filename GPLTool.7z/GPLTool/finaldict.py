import xlsxwriter
from predict import texttoparsepre
from postdict import texttoparsepost


def compare_dicts():
    pre_dict=texttoparsepre()
    post_dict=texttoparsepost()
    result = {}
    for key in post_dict:
        if key not in pre_dict:
            result[key] = post_dict[key]
        else:
            for subkey, post_values in post_dict[key].items():
                pre_values = pre_dict[key].get(subkey, [])
                non_matching_values =[value for value in post_values if value not in pre_values]
                if non_matching_values:
                    if key not in result:
                        result[key] = {}
                    result[key][subkey] = non_matching_values
    
    return result

  
def write_to_excel():
    results = compare_dicts()
    workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\5Goutput.xlsx',{'strings_to_numbers':True})
    worksheet = workbook.add_worksheet()

    worksheet.write('A1', 'Id')
    subkeys_written = []
    for key in results:
        for subkey in results[key]:
            if subkey not in subkeys_written:
                subkeys_written.append(subkey)
    for col, subkey in enumerate(subkeys_written):  
        worksheet.write(0, col + 1, subkey)  

    row = 1
    for key in results:  # iterate over all keys in results
        found_subkey = False  # flag to keep track of whether subkey has been found for this key
        for col, subkey in enumerate(subkeys_written):
            if subkey in results[key]:
                found_subkey = True
                values = results[key][subkey]
                if isinstance(values, list):
                    for i, value in enumerate(values):
                        worksheet.write(row + i, 0, key) 
                        worksheet.write(row + i, col + 1, ','.join(values))
                else:
                    worksheet.write(row, 0, key) 
                    worksheet.write(row, col + 1, values)
                    row += 1
        if not found_subkey:  # if subkey not found for this key, write key with empty values
            worksheet.write(row, 0, key) 
            for col in range(len(subkeys_written)):
                worksheet.write(row, col + 1, '')
            row += 1
        found_subkey = False  # reset flag for next key
        row += 1  # increment row for next key
    row = 1  # reset row for next iteration

    workbook.close()

write_to_excel()


