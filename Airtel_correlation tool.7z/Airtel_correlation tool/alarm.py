from openpyxl import load_workbook
import os


def Alarm_file():
    path = os.getcwd()
    folder = os.path.join(path, "Airtel_correlation tool", "AlarmMapping.xlsx")
    wb = load_workbook(folder)
    ws1 = wb["AlaramMapping"]
    
    alrammapping = {}
    for row in range(2, ws1.max_row + 1):
        key = ws1.cell(row, 1).value
        newkey=str(key)
        value = ws1.cell(row, 2).value
        value2 = ws1.cell(row, 3).value
        value3 = ws1.cell(row, 4).value
        alrammapping[newkey] = [value, value2, str(value3)]

   
    
    wb.close()
    return alrammapping

def User_Alaram():
    path = os.getcwd()
    folder = os.path.join(path, "Airtel_correlation tool", "AlarmMapping.xlsx")
    wb = load_workbook(folder)
    ws2 = wb["UserInput"]
    
    userinput = []
    for row in range(2, ws2.max_row + 1):
        key = ws2.cell(row, 1).value
        userinput.append(key)
    
    wb.close()
    return userinput

def User_time():
    path = os.getcwd()
    folder = os.path.join(path, "Airtel_correlation tool", "AlarmMapping.xlsx")
    wb = load_workbook(folder)
    ws2 = wb["UserTime"]
    
    userinput = 0
    for row in range(2, ws2.max_row + 1):
        key = ws2.cell(row, 1).value
        userinput+=key
    
    wb.close()
    return userinput





                                                                                                    
