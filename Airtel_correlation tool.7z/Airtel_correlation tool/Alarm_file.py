import os
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter import Tk, Button
from alarmcorrelation import write_to_excel

# Get output name from file
def getOutputName(s):
    s_list = s.split('.')
    return s_list[0]+"Output"


root = Tk()   
root.geometry("800x500")
root.configure(bg='black')
open_output_file = ''
open_input_file = ''
date_list = None
short_name=None

#Title for tool
title = Label(root, text = "ACE_ENGINE_TOOL",font=('Calisto MT',15),background='black',foreground='Red').place(x = 250, y = 6) 

def _submit():
    write_to_excel()
    print("output has been generated!!!")
    
b = Button(root,command=lambda: _submit(),text = "Generate Report",bg='red',  fg = 'blue')    
b.pack(ipadx=5, ipady=5,pady=5)
b.place(x=300, y=50)


root.mainloop()
