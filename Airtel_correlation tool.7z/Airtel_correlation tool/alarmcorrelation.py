import os
from datetime import datetime,timedelta
from alarm import Alarm_file,User_Alaram,User_time
import xlsxwriter
import re


def sorting(my_list):
    sorted_list = sorted([sublist for sublist in my_list if sublist], key=lambda x: x[5])
    return sorted_list


useralarmkey,associatealarmkey,otheralarmkey='user_alarm','other_alarm','other_alarm_data'

def Alarmapping():
    useralrams=User_Alaram()
    global useralarmkey, associatealarmkey, otheralarmkey
    new_alarm_dict = {}
    mydata=[]
    alarmfunc=Alarm_file()
    current_dir = os.getcwd() 
    input_folder = os.path.join(current_dir, "Airtel_correlation tool", "input")
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file_path = os.path.join(input_folder, file_name)
        with open(file_path, 'r') as file:
            raw_file_data = file.read().split('\n')
        raw_file_data.pop()
        for val in raw_file_data[1:]:
            data_list = val.split(',')
            cleaned_data_list = []
            
            for item in data_list:
                cleaned_item = item.replace('"', '')
                cleaned_data_list.append(cleaned_item)

            code = cleaned_data_list[3] if len(cleaned_data_list[3]) != 0 else ""
           
            if code in alarmfunc:
                alarm_name = code
                alarm_value, alarm_value_problem, alarm_priority = alarmfunc[alarm_name][:3]
                cleaned_data_list.extend([alarm_value, alarm_value_problem, alarm_priority])
            else:
                cleaned_data_list.extend(['Under Investigation', 'Under Investigation', '200'])

            mydata.append(cleaned_data_list)

    mydata.sort(key=lambda x: x[8])
    
    alarm_dict = {}
    user_time = User_time()
    for data in mydata:
        enb_name,alarm_type,alarm_date, alarm_category,alarm_reason,alrampriority,alarm_cleartime= data[5],data[7].lower(),data[8],data[12],data[13],data[14],data[9]

        if enb_name not in alarm_dict:
            alarm_dict[enb_name] = {useralarmkey: [],associatealarmkey:[]}
        if alarm_type in useralrams:
            alarm_data = [alarm_date, alarm_type, alarm_cleartime, alarm_category, alarm_reason, alrampriority]
            alarm_dict[enb_name][useralarmkey].append(alarm_data)
            user_alram_date=alarm_date
            try:
                current_time = datetime.strptime(user_alram_date, '%m/%d/%Y %H:%M')
            except ValueError:
            # If parsing fails, try with the second date format ("%Y-%m-%d %H:%M:%S")
                current_time = datetime.strptime(user_alram_date, '%Y-%m-%d %H:%M:%S')
            one_hour_before = current_time - timedelta(minutes=user_time)
            start_time = one_hour_before.strftime('%m/%d/%Y %H:%M')
            end_time = alarm_date
            if otheralarmkey in alarm_dict[enb_name]:
                prev_alarms = [prev_alarm for prev_alarm in alarm_dict[enb_name][otheralarmkey] if start_time <= prev_alarm[0] <= end_time]
                if prev_alarms!=[]:
                    prevalarms=sorting(prev_alarms)
                    last_three_alarms = prevalarms[:3]
                    alarm_dict[enb_name][associatealarmkey].append(last_three_alarms or [['','','','','Under Investigation','200']])   
            else:
                alarm_dict[enb_name][associatealarmkey].append([['','','','','Under Investigation','200']])
        else:
            if otheralarmkey not in alarm_dict[enb_name]:
                alarm_dict[enb_name][otheralarmkey] = []
            alarm_dict[enb_name][otheralarmkey].append([alarm_date, alarm_type, alarm_cleartime, alarm_category, alarm_reason, alrampriority])

    for enb_name, alarms in alarm_dict.items():
        user_alarm_data = alarms[useralarmkey]
        other_alarm_data = alarms.get(associatealarmkey, [])
        
        if user_alarm_data and other_alarm_data:
            new_alarm_dict[enb_name] = {
                useralarmkey: user_alarm_data,
                associatealarmkey: other_alarm_data
            }

    # for enb_name, alarmdata in new_alarm_dict.items():
    #     if associatealarmkey in alarmdata:
    #         user_alarm_lists = alarmdata[associatealarmkey]
    #         alarmdata[associatealarmkey] = [sorted(sublist, key=lambda x: x[5]) if any(sublist) else sublist for sublist in user_alarm_lists]
   
   
    return new_alarm_dict



def write_to_excel():
    alramdata=Alarmapping()
    current_dir = os.getcwd()
    output_folder = os.path.join(current_dir, "Airtel_correlation tool", "output")
    new_output = os.path.join(output_folder, "Alarmreport.xlsx")
    workbook = xlsxwriter.Workbook(new_output,{'strings_to_numbers':True})
    color1=workbook.add_format({'fg_color':'#ADD8E6'})
    color2=workbook.add_format({'fg_color':'yellow'})
    worksheet = workbook.add_worksheet("Alarmreport") 
    worksheet2 = workbook.add_worksheet("Alarmsummary")
    worksheet3 = workbook.add_worksheet("Categoryreport") 
    worksheet2.merge_range(3,3,3,3+3,"Duration wise summary (Occurrences)",color2)
    
    headers = ['eNB NAME','Date', 'Useralram','ClearTime','Associated Alarmtime','Associated Alarm','Associated Cleartime','Category,','Reason','ReaminningAalarm']
    summaryhead=['Category','Unique eNB count', 'Count of alarm' ,'<1min' ,'1-5 Min', '5-10 min','>10min']
    global useralarmkey, associatealarmkey, otheralarmkey
    for i in range(len(headers)):
        worksheet.write(0, i, headers[i])
    
    for i in range(len(summaryhead)):
        worksheet2.write(4, i, summaryhead[i],color1)
    row,rows,catrow,enbrow=1,1,5,5
    col=3
    for enb, alarm_data in alramdata.items():
        user_alarm_list = alarm_data[useralarmkey]
        associatedalarmlist = alarm_data[associatealarmkey]
        for row_data in user_alarm_list:
            worksheet.write_row(row, 0, [enb] + row_data[:3])
            row += 1
        for rowdata in associatedalarmlist:
            worksheet.write_row(rows, 4, rowdata[0][:5])
            alarm_values = ','.join(value[1] for value in rowdata[1:] if len(value) > 1 and value[1])
            worksheet.write(rows, 9, alarm_values)
            rows += 1

    category_enbid_count_range, category_enbid_count, category_alarm_count, category_uniq_enbid_count, category_uniq_alarm_count,mdict,alcount = {}, {}, {}, {}, {},{},{}
    key_less_than_1_min, key_1_to_5_min, key_5_to_10_min, key_greater_than_10_min = "less_than_1_min", "1_to_5_min", "5_to_10_min", "greater_than_10_min"
    for enbid, alarmdatas in alramdata.items():
        alarm_list = alarmdatas[associatealarmkey]


        
        user_alarm_time = alarmdatas[useralarmkey]
        for cat,s_time in zip(alarm_list,user_alarm_time):
            associatealram=cat[0][1]
            if cat:
                if len(cat[0]) > 1:  
                    category = cat[0][4]
                    if category not in category_enbid_count:
                        category_enbid_count[category] = set()
                        category_alarm_count[category] = []
                    category_enbid_count[category].add(enbid)
                    category_alarm_count[category].append(enbid)

                    if category not in alcount:
                        alcount[category] = {}

                    if associatealram not in alcount[category]:
                        alcount[category][associatealram] = set() 
                    alcount[category][associatealram].add(enbid)
                    
    
                    if category not in category_enbid_count_range:
                        category_enbid_count_range[category] = {
                            key_less_than_1_min: 0,
                            key_1_to_5_min: 0,
                            key_5_to_10_min: 0,
                            key_greater_than_10_min: 0
                    }
                        

                    if category not in mdict:
                        mdict[category] = {}

                    if associatealram not in mdict[category]:
                        mdict[category][associatealram]=[0,0]
                    mdict[category][associatealram][0]+=1
                    mdict[category][associatealram][1] = len(alcount[category][associatealram])
                    
                    starttime=s_time[0]
                    cleartime=s_time[2]
                    if starttime=="NULL" or cleartime=="NULL" or starttime=='' or cleartime=='':
                        continue
                    # start_time_tamp=datetime.strptime(starttime, '%m/%d/%Y %H:%M')
                    # clera_time_tamp=datetime.strptime(cleartime, '%m/%d/%Y %H:%M')
                    try:
                        start_time_tamp= datetime.strptime(starttime, '%m/%d/%Y %H:%M')
                    except ValueError:
                        # If parsing fails, try with the second date format ("%Y-%m-%d %H:%M:%S")
                        start_time_tamp = datetime.strptime(starttime, '%Y-%m-%d %H:%M:%S')
                    try:
                        clera_time_tamp= datetime.strptime(cleartime, '%m/%d/%Y %H:%M')
                    except ValueError:
                        # If parsing fails, try with the second date format ("%Y-%m-%d %H:%M:%S")
                        clera_time_tamp = datetime.strptime(cleartime, '%Y-%m-%d %H:%M:%S')

                    time_difference = clera_time_tamp - start_time_tamp
                    minutes_difference = time_difference.total_seconds()//60
                    
                    if minutes_difference < 1:
                        category_enbid_count_range[category][key_less_than_1_min] += 1
                    elif 1 <= minutes_difference <= 5:
                        category_enbid_count_range[category][key_1_to_5_min] += 1
                    elif 5 < minutes_difference <= 10:
                        category_enbid_count_range[category][key_5_to_10_min] += 1
                    else:
                        category_enbid_count_range[category][key_greater_than_10_min] += 1
    
    for category, enbid_set in category_enbid_count.items():
        category_uniq_enbid_count[category] = len(enbid_set)

    for category, alarm_set in category_alarm_count.items():
        category_uniq_alarm_count[category] = len(alarm_set)
    maxrow=0
    for category, enbid_count in category_uniq_enbid_count.items():
        worksheet2.write(catrow, 0, category)
        worksheet2.write(catrow, 1, enbid_count)
        worksheet2.write(catrow, 2, category_uniq_alarm_count[category])
        catrow += 1
        maxrow=catrow
    total_enbid_count = sum(category_uniq_enbid_count.values())
    total_alarm_count = sum(category_uniq_alarm_count.values())
    worksheet2.write(maxrow,0,"Grand Total",color1)
    worksheet2.write(maxrow,1,total_enbid_count,color1 )
    worksheet2.write(maxrow,2,total_alarm_count,color1)

    for category, time_ranges in category_enbid_count_range.items():
        for time_range, count in time_ranges.items():
            worksheet2.write(enbrow, col, count)
            col += 1
        enbrow += 1
        col=3

    sum_values = {
    key_less_than_1_min: sum(time_ranges[key_less_than_1_min] for time_ranges in category_enbid_count_range.values()),
    key_1_to_5_min: sum(time_ranges[key_1_to_5_min] for time_ranges in category_enbid_count_range.values()),
    key_5_to_10_min: sum(time_ranges[key_5_to_10_min] for time_ranges in category_enbid_count_range.values()),
    key_greater_than_10_min: sum(time_ranges[key_greater_than_10_min] for time_ranges in category_enbid_count_range.values())
    }
    for col, count in enumerate(sum_values.values(), start=3):
        worksheet2.write(maxrow, col, count,color1)

    headers = ['Category', 'Alarms', 'Count','Unquie enbcount']
    worksheet3.write_row(0, 0, headers)

    keysum=[]
    enbsum=[]
    maxrows=0
    row_index = 1
    for category, enalcount in mdict.items():
        for key, data in enalcount.items():
            alrm=data[0]
            keysum.append(alrm)
            enb = data[1] 
            enbsum.append(enb)
            worksheet3.write(row_index, 0, category)
            worksheet3.write(row_index, 1, key)
            worksheet3.write(row_index, 2, alrm)
            worksheet3.write(row_index, 3, enb)

            row_index += 1
            maxrows=row_index

    worksheet3.write(row_index,0,"Grand Total")
    worksheet3.write(row_index,2,sum(keysum))
    worksheet3.write(row_index,3,sum(enbsum))


    workbook.close()


