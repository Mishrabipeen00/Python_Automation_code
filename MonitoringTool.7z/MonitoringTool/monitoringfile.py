import xlsxwriter
import os
from datetime import datetime
from functools import cmp_to_key
from formulacleanvariable import getVariables
from formulafile import formula_kpi
from average import average_kpi
import re


def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        s = s[1:]
    if s[-1:] == '"':
        s = s[0:-1]
    return s

def compare_var(s1, s2):
    if len(s1) > len(s2):
        return -1
    else:
        return 1

def remove_single_quoute(s):
    if len(s) == 0:
        return s
    if s[0] == "'":
        return s[1:-1]
    else:
        return s

def getValue(n):
    if n == '' or n == 'ND' or n=="NF":
        return float(0)
    else:
        return float(n)

def replacePercent(d):
    d=d.replace('%',"")
    return d

def getKPIs(data):
    for i in range(3):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data


def to_date(s):
    s_list = s.split('-')
    if len(s_list) > 1:
        date = datetime.strptime(to_string(s), '%Y-%m-%d')
        return date
    else:
        date = datetime.strptime(to_string(s), '%Y %m %d')
        return date

def getDate(d):
    d_list=d.split('-')
    if len(d_list)>1:
        dd = datetime.strptime(to_string(d),"%Y-%m-%d")
        sdate=dd.strftime("%d %b %y")
        return sdate
    else:
        dd = datetime.strptime(to_string(d),"%Y %m %d")
        sdate = dd.strftime("%d %b %y")

        return sdate


def date_in_range(user_date, r, current_date):
        
    d1 = to_date(user_date)
    d2 = to_date(current_date)

    d  =  str(d2 - d1).split()
    
    if len(d) == 1:
        return True
    if int(d[0]) < r and int(d[0]) >= 0:
        return True
    else:
        return False

def date_in_list(l, scurr_date):
    current_date = to_date(scurr_date)
    for sdate in l:
        date = to_date(sdate)
        if date == current_date:
            return True
    return False

def isInt(x):
    try:
        float(x)
        return True
    except ValueError:
        return False

def get_pre(pre_list, pos):
    date_list = pre_list[0].split(',')        
    res = "Pre"
    if pos > 0:
        res += " " + str(pos)
    res += "(" + to_string(pre_list[0]) + ' to ' + to_string(pre_list[-1]) + ")"

    return res

def get_post(post_list, nos):
    date_list = post_list[0].split(',')
    rest = "Post"
    if nos > 0:
        rest += " " + str(nos) 
    # Post 2
    rest += "(" + to_string(post_list[0]) + ' to ' + to_string(post_list[-1]) + ")"

    return rest


def compare(x1, y1):
    x = x1.split('-')
    y = y1.split('-')

    if len(x) == 1:
        x = x1.split()
        y = y1.split()
    
    if int(x[0]) == int(y[0]): 
        if isInt(x[1][1]) and isInt(y[1][1]):
            if int(x[1][1]) < int(y[1][1]):
                return -1
            else:
                return 1
        else:
            if isInt(x[1][1]):
                return 1
            else: 
                return -1

    if int(x[0]) > int(y[0]):
        return 1
    return -1

    


def make_range(row_no, inc):
    l = str(row_no)
    r = str(row_no + inc)
    s =  "A" + l + ":" + "D" + r
    return s

def getCounter(data):
    if ',' in data:
        d = data.split(',')
    elif '\t' in data:
        d = data.split('\t')
    else:
        # handle error case where neither comma nor tab is found
        return []
    for i in range(3):
        d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d


def isFloat(num):
    try:
        float(num)
        return True
    except ValueError:
        return False



def getKeys(hour): 
    fixTime = ['15', '30', '45', '00']
    l = []
    if hour <= 9:
        hour = '0' + str(hour)
    for i in range(len(fixTime)):
        if i == len(fixTime) - 1:
            val = str(int(hour) + 1) + ":" + fixTime[i] 
            l.append(val)
        else:
            val = str(hour) + ":" + fixTime[i] 
            l.append(val)
    return l



class Summary:
    def __init__(self,workbook):
        self.formulaKpi = formula_kpi()
        self.averagevalue=average_kpi()
        self.finalResult = {}
        self.cellnummap={}
        self.sitename=set()
        self.cellnum=set()
        self.worksheet = workbook.add_worksheet("summary")
        self.worksheet2=workbook.add_worksheet("cellnum_summary")
        self.row=0
        self.col=0
        self.cellrow=0
        self.cellcol=0
    

    def comparison(self):
        m = {}
        m2 = {}
        path = os.getcwd()
        self.folder = os.path.join(path, "MonitoringTool", "lteinput")
        self.files = os.listdir(self.folder)
        for file in self.files:
            subfiles = os.listdir(os.path.join(self.folder, file))
            for subfile in subfiles:
                with open(os.path.join(self.folder, file, subfile), 'r') as f:
                    datas = f.read().split('\n')
                    datas.pop()
                    counters = getCounter(datas[10])
                    if datas[2]!="FAMILY : E-RAB Release by eNB per Cell per QCI" and datas[2]!="FAMILY : E-RAB Release by MME per Cell per QCI":
                        for data in datas[11:]:
                            data_list = data.split(',')
                            for i in range(len(data_list[3:])):
                                if counters[i] not in m:
                                    m[counters[i]] = {}
                                if counters[i] not in m2:
                                    m2[counters[i]] = {}

                                if len(data_list[1])!=0:
                                    ne=data_list[1]
                                    self.sitename.add(ne)

                                cellnum = ''
                                if '-' in data_list[2]:
                                    continue
                                for item in data_list[2].split('/'):
                                    if item.startswith('cNum'):
                                        cellnum = item
                                        break

                                self.cellnum.add(cellnum + "," +ne)

                                currentDate = ""
                                currentTime = ""
                                if len(data_list[0])!=0:
                                    currentDate = data_list[0].split()[0]
                                    currentTime =to_string(data_list[0].split()[1])
                                    
                                currentDateInStr = currentDate
                                
                                if currentDateInStr not in m[counters[i]]:
                                    m[counters[i]][currentDateInStr] = {}
                                if currentDateInStr not in m2[counters[i]]:
                                    m2[counters[i]][currentDateInStr] = {}

                                
                                if  currentTime not in m[counters[i]][currentDateInStr]:
                                    m[counters[i]][currentDateInStr][currentTime] = 0
                                if  currentTime not in m2[counters[i]][currentDateInStr]:
                                    m2[counters[i]][currentDateInStr][currentTime] = 0
                                m[counters[i]][currentDateInStr][currentTime] += getValue(data_list[i+3])
                    else:
                        for data in datas[11:]:
                            data_list = data.split(',')
                            for i in range(len(data_list[3:])):
                                cellnum=""
                                cellnum2=""
                                if '-' in data_list[2]:
                                    continue
                                if len(data_list[2])!=0:
                                    celldata=data_list[2].split("/")[1]
                                    cellnum=celldata
                                
                                if cellnum=="QCI1":
                                    if counters[i] not in m:
                                        m[counters[i]] = {}

                                    currentDate = ""
                                    currentTime = ""
                                    if len(data_list[0])!=0:
                                        currentDate = data_list[0].split()[0]
                                        currentTime =to_string(data_list[0].split()[1])
                                        
                                    currentDateInStr = currentDate
                                    
                                    
                                    if currentDateInStr not in m[counters[i]]:
                                        m[counters[i]][currentDateInStr] = {}

                                    
                                    if  currentTime not in m[counters[i]][currentDateInStr]:
                                        m[counters[i]][currentDateInStr][currentTime] = 0
                                    m[counters[i]][currentDateInStr][currentTime] += getValue(data_list[i+3])
                                else:
                                    if counters[i] not in m2:
                                        m2[counters[i]] = {}
                                    if counters[i] not in m:
                                        m[counters[i]] = {}

                                    currentDate = ""
                                    currentTime = ""
                                    if len(data_list[0])!=0:
                                        currentDate = data_list[0].split()[0]
                                        currentTime =to_string(data_list[0].split()[1])
                                        
                                    currentDateInStr = currentDate
                                    
                                    
                                    if currentDateInStr not in m2[counters[i]]:
                                        m2[counters[i]][currentDateInStr] = {}
                                    if currentDateInStr not in m[counters[i]]:
                                        m[counters[i]][currentDateInStr] = {}

                                    
                                    if  currentTime not in m2[counters[i]][currentDateInStr]:
                                        m2[counters[i]][currentDateInStr][currentTime] = 0
                                    if  currentTime not in m[counters[i]][currentDateInStr]:
                                        m[counters[i]][currentDateInStr][currentTime] = 0
                                    m2[counters[i]][currentDateInStr][currentTime] += getValue(data_list[i+3])

                        
        
        self.myData=m
        self.myData2=m2


    def comparison_cellnum(self):
        celldict = {}
        path = os.getcwd()
        self.folder = os.path.join(path, "MonitoringTool", "lteinput")
        self.files = os.listdir(self.folder)
        for file in self.files:
            subfiles = os.listdir(os.path.join(self.folder, file))
            for subfile in subfiles:
                with open(os.path.join(self.folder, file, subfile), 'r') as f:
                    datas = f.read().split('\n')
                    datas.pop()
                    counters = getCounter(datas[10])
                    if datas[2]!="FAMILY : E-RAB Release by eNB per Cell per QCI" and datas[2]!="FAMILY : E-RAB Release by MME per Cell per QCI":
                        for data in datas[11:]:
                            data_list = data.split(',')
                            for i in range(len(data_list[3:])):
                                if len(data_list[1])!=0:
                                    ne=data_list[1]
                                    
                                if ne not in celldict:
                                    celldict[ne]={}

                                cellnum = ''
                                if '-' in data_list[2]:
                                    continue
                                for item in data_list[2].split('/'):
                                    if item.startswith('cNum'):
                                        cellnum = item
                                        break
                                    

                                if cellnum not in celldict[ne]:
                                    celldict[ne][cellnum]={}

                                if counters[i] not in celldict[ne][cellnum]:
                                    celldict[ne][cellnum][counters[i]]={}

                                currentDate = ""
                                currentTime = ""
                                if len(data_list[0])!=0:
                                    currentDate = data_list[0].split()[0]
                                    currentTime =to_string(data_list[0].split()[1])
                                    
                                currentDateInStr = currentDate
                                
                                
                                if currentDateInStr not in celldict[ne][cellnum][counters[i]]:
                                    celldict[ne][cellnum][counters[i]][currentDateInStr] = {}

                                
                                if  currentTime not in celldict[ne][cellnum][counters[i]][currentDateInStr]:
                                    celldict[ne][cellnum][counters[i]][currentDateInStr][currentTime] = 0
                                celldict[ne][cellnum][counters[i]][currentDateInStr][currentTime] += getValue(data_list[i+3])

                    else:
                        for data in datas[11:]:
                            data_list = data.split(',')
                            for i in range(len(data_list[3:])):
                                countercheck=""
                                if '-' in data_list[2]:
                                    continue
                                if len(data_list[2])!=0:
                                    qc1=data_list[2].split("/")[1]
                                    countercheck=qc1
                                if countercheck=="QCI1":
                                    if len(data_list[1])!=0:
                                        ne=data_list[1]

                                    if ne not in celldict:
                                        celldict[ne]={}

                                    cellnum = ''
                                    if '-' in data_list[2]:
                                        continue
                                    for item in data_list[2].split('/'):
                                        if item.startswith('cNum'):
                                            cellnum = item
                                            break

                                    if cellnum not in celldict[ne]:
                                        celldict[ne][cellnum]={}

                                    if counters[i] not in celldict[ne][cellnum]:
                                        celldict[ne][cellnum][counters[i]]={}

                                    currentDate = ""
                                    currentTime = ""
                                    if len(data_list[0])!=0:
                                        currentDate = data_list[0].split()[0]
                                        currentTime =to_string(data_list[0].split()[1])
                                        
                                    currentDateInStr = currentDate
                                    
                                    
                                    if currentDateInStr not in celldict[ne][cellnum][counters[i]]:
                                        celldict[ne][cellnum][counters[i]][currentDateInStr] = {}

                                    
                                    if  currentTime not in celldict[ne][cellnum][counters[i]][currentDateInStr]:
                                        celldict[ne][cellnum][counters[i]][currentDateInStr][currentTime] = 0
                                    celldict[ne][cellnum][counters[i]][currentDateInStr][currentTime] += getValue(data_list[i+3])



        
        self.cellmydata=celldict


    def formulaEvalwrite(self,currentDate, currenttime):
        for items in self.formulaKpi: # kpi which suppose to be calcualte using formula ( map )
            res= 0
            kpiFormula = self.formulaKpi[items]  # getting formula for given kpi
            varList = getVariables(kpiFormula)
            var = list(set(varList)) # remove duplicate variables
            posAns = []
            postkpiFormula = kpiFormula
            for idx in range(len(var)):
                if isInt(var[idx]):
                    posAns.append(float(var[idx]))
                    continue

                postTmpText = 'posAns[' + str(idx) + ']'
                
                postkpiFormula=postkpiFormula.replace(var[idx],postTmpText)
                postTmpResult = 0
                if items == 'PS DCR%' or items == "PS DCR_Nom" or items == "PS DCR_Denom":
                    try:
                        postTmpResult = self.myData2[var[idx]][currentDate][currenttime] + self.myData[var[idx]][currentDate][currenttime]
                    except:
                        pass
                else:
                    try : 
                        postTmpResult = self.myData[var[idx]][currentDate][currenttime]
                    except:
                        pass
                posAns.append(postTmpResult)
                try:
                    res = eval(postkpiFormula[1:])
                except:
                    pass

                if items not in self.finalResult:
                    self.finalResult[items] = {}

                if currentDate not in self.finalResult[items]:
                    self.finalResult[items][currentDate]={}
                if currenttime not in self.finalResult[items][currentDate]:
                    self.finalResult[items][currentDate][currenttime]=0
                self.finalResult[items][currentDate][currenttime] = res
        
        
    def formulaEvalwritecell(self,ne,cellnum,currentDate, currenttime):
        for items in self.formulaKpi: # kpi which suppose to be calcualte using formula ( map )
            result= 0
            kpiFormula = self.formulaKpi[items]  # getting formula for given kpi
            varList = getVariables(kpiFormula)
            var = list(set(varList)) # remove duplicate variables
            posAns = []
            postkpiFormula = kpiFormula
            for idx in range(len(var)):
                if isInt(var[idx]):
                    posAns.append(float(var[idx]))
                    continue

                postTmpText = 'posAns[' + str(idx) + ']'
                
                postkpiFormula=postkpiFormula.replace(var[idx],postTmpText)
                postTmpResult = 0
                try : 
                    postTmpResult = self.cellmydata[ne][cellnum][var[idx]][currentDate][currenttime]
                except:
                    pass
                posAns.append(postTmpResult)
                try:
                    result = eval(postkpiFormula[1:])
                except:
                    pass

                if ne not in self.cellnummap:
                    self.cellnummap[ne] = {}

                if cellnum not in self.cellnummap[ne]:
                    self.cellnummap[ne][cellnum]={}

                if items not in self.cellnummap[ne][cellnum]:
                    self.cellnummap[ne][cellnum][items] = {}

                if currentDate not in self.cellnummap[ne][cellnum][items]:
                    self.cellnummap[ne][cellnum][items][currentDate]={}
                if currenttime not in self.cellnummap[ne][cellnum][items][currentDate]:
                    self.cellnummap[ne][cellnum][items][currentDate][currenttime]=0
                self.cellnummap[ne][cellnum][items][currentDate][currenttime] = result

    
    def call_dates(self):
        self.comparison()
        lst_dates = set()
        lst_time = set()
        for kpi in self.myData:
            for currentdate in self.myData[kpi]:
                lst_dates.add(currentdate)
                for currenttime in self.myData[kpi][currentdate]:
                    lst_time.add(currenttime)

        lst_dates = sorted(list(lst_dates))
        lst_time = sorted(list(lst_time))

        for currentDate in lst_dates:
            for currenttime in lst_time:
                 self.formulaEvalwrite(currentDate,currenttime)

        prepostCall=self.finalResult
        
        self.worksheet.write(0, 0, 'DateTime')
        self.col = 1
        for kpi in prepostCall.keys():
            self.worksheet.write(0, self.col, kpi)
            self.col += 1

        
        self.row = 1
        for currentdate, times in prepostCall[list(prepostCall.keys())[0]].items():
            for currenttime in times:
                self.col = 0
                self.worksheet.write(self.row, self.col, f"{currentdate} {currenttime}")
                self.col += 1
                for kpi in prepostCall:
                    value = prepostCall[kpi][currentdate][currenttime]
                    if kpi in self.averagevalue:
                        value2 = prepostCall[kpi][currentdate][currenttime]/len(self.cellnum)
                        self.worksheet.write(self.row, self.col,value2 )
                    else:
                        self.worksheet.write(self.row, self.col, value)
                    self.col += 1
                self.row += 1

        self.comparison_cellnum()

        lstdates = set()
        lsttime = set()
        for ne in self.cellmydata:
            for cellnum in self.cellmydata[ne]:
                for kpi in self.cellmydata[ne][cellnum]:
                    for currentdate in self.cellmydata[ne][cellnum][kpi]:
                        lstdates.add(currentdate)
                        for currenttime in self.cellmydata[ne][cellnum][kpi][currentdate]:
                            lsttime.add(currenttime)
                        
        lstdates = sorted(list(lstdates))
        lsttime = sorted(list(lsttime))
        for ne in self.cellmydata:
            for cellnum in self.cellmydata[ne]:
                for currentDate in lstdates:
                    for currenttime in lsttime:
                        self.formulaEvalwritecell(ne,cellnum,currentDate,currenttime)

        writedictionay=self.cellnummap
       
        
        self.worksheet2.write(0, 0, 'Site')
        self.worksheet2.write(0, 1, 'CellNum')
        self.worksheet2.write(0, 2, 'DateTime')


        # Collect unique combinations of data
        unique_data = {}
        for sitename in writedictionay:
            for cellnum in writedictionay[sitename]:
                for kpi in writedictionay[sitename][cellnum]:
                    for date in writedictionay[sitename][cellnum][kpi]:
                        for time in writedictionay[sitename][cellnum][kpi][date]:
                            # Create a tuple of site name, cell number, date and time
                            data_tuple = (sitename, cellnum, date, time)
                            # If the tuple doesn't exist in the dictionary, add it with its KPI value
                            if data_tuple not in unique_data:
                                unique_data[data_tuple] = {kpi: writedictionay[sitename][cellnum][kpi][date][time]}
                            # Otherwise, add the KPI value to the existing tuple
                            else:
                                unique_data[data_tuple][kpi] = writedictionay[sitename][cellnum][kpi][date][time]

        # Write data to worksheet without duplicates
        for i, (data_tuple, kpis) in enumerate(unique_data.items()):
            sitename, cellnum, date, time = data_tuple
            self.worksheet2.write(i+1, 0, sitename)
            self.worksheet2.write(i+1, 1, cellnum)
            self.worksheet2.write(i+1, 2, f"{date} {time}")
            for j, (kpi_key, kpi_value) in enumerate(kpis.items()):
                # Write KPI header only once at the top row
                if i == 0:
                    self.worksheet2.write(0, j+3, kpi_key)
                self.worksheet2.write(i+1, j+3, kpi_value)


    def call_category(self):
        self.call_dates()

        
#         workbook.close()

        

# workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\5Goutput.xlsx',{'strings_to_numbers':True}) 

# summary=Summary(workbook)
# summary.call_category()





 

    
    
    