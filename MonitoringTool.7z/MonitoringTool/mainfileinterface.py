import os
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter import Tk, Button, StringVar, OptionMenu
import xlsxwriter
from datetime import datetime
import time
from monitoringfile import Summary
from monitoringfilenr import Summarycell
from hourlymonitoringTool import Hourlysummary
from hourlynrmonitoringTool import Hourlysummarycell


# Get output name from file
def getOutputName(s):
    s_list = s.split('.')
    return s_list[0]+"Output"



root = Tk()   
root.geometry("800x500")
root.configure(bg='black')
open_output_file = ''
open_input_file = ''
date_list = None
short_name=None




#Title for tool
title = Label(root, text = "Monitor Tool Dashboard",font=('Calisto MT',15),background='black',foreground='Red').place(x = 300, y = 6) 



def dailylte():
    path=os.getcwd()
    outfolder=path+"\\"+"MonitoringTool\\output"
    _output = outfolder + '\\' + "MonitorReportlte.xlsx"
    workbook = xlsxwriter.Workbook(_output,{'strings_to_numbers':True})
    summary = Summary(workbook)
    summary.call_category()
    print("output has been generated!!!")
    workbook.close()


def dailynr():
    path=os.getcwd()
    outfolder=path+"\\"+"MonitoringTool\\output"
    _output = outfolder + '\\' + "MonitorReportnr.xlsx"
    workbook = xlsxwriter.Workbook(_output,{'strings_to_numbers':True})
    summary = Summarycell(workbook)
    summary.callcategory()
    print("output has been generated!!!")
    workbook.close()

def hourlylte():
    path=os.getcwd()
    outfolder=path+"\\"+"MonitoringTool\\output"
    _output = outfolder + '\\' + "MonitorReportlte.xlsx"
    workbook = xlsxwriter.Workbook(_output,{'strings_to_numbers':True})
    summary = Hourlysummary(workbook)
    summary.callhourlylte()
    print("output has been generated!!!")
    workbook.close()

def hourlynr():
    path=os.getcwd()
    outfolder=path+"\\"+"MonitoringTool\\output"
    _output = outfolder + '\\' + "MonitorReportnr.xlsx"
    workbook = xlsxwriter.Workbook(_output,{'strings_to_numbers':True})
    summary = Hourlysummarycell(workbook)
    summary.callhourlynr()
    print("output has been generated!!!")
    workbook.close()


def callbothfunctiondailyreport():
    dailylte()
    dailynr()

def callbothfunctionHourlyreport():
    hourlylte()
    hourlynr()

b = Button(root,command=lambda:callbothfunctiondailyreport(),text = "Generate Quaterly Report",bg='red',  fg = 'blue')    
b.pack(ipadx=5, ipady=5,pady=5)
b.place(x=250, y=50)

b = Button(root,command=lambda:callbothfunctionHourlyreport(),text = "Generate Hourly Report",bg='red',  fg = 'blue')    
b.pack(ipadx=5, ipady=5,pady=5)
b.place(x=410, y=50)

root.mainloop()