from openpyxl import Workbook, load_workbook
import os
path=os.getcwd()
folder=path+"\\"+"MonitoringTool"+"\\" + "nrkpiformula.xlsx"

wb = load_workbook(folder)
ws1= wb["sitedisplay"]


def display_site():
    sitedisplay=[]
    for row in range(2, ws1.max_row + 1):
        key = ws1.cell(row, 1).value
        sitedisplay.append(key)
    
    return sitedisplay







