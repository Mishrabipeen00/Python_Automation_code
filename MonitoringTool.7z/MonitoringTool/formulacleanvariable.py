import re
import math
def isInt(x):
    try:
        int(x)
        return True
    except ValueError:
        return False
    
def replacePercent(d):
    d=d.replace('%',"")
    return d

def removeParenthesis(var):
    if len(var) == 0:
        return var
    
    
    state = 0
    for c in var:
        if c == '(':
            state += 1
        elif c == ')':
            state -= 1

            
    if state != 0:   
        # print(var)
        while var[-1] == ')' and var[-2] == ')':
            var = var[:-1]
            state += 1
        while var[0] == '(' and var[1] == '(':
            var = var[1:]
            state -= 1
        if state != 0 and var[0] == '(': # keep this one first
            var = var[1:]
            state -= 1
        elif state != 0 and var[-1] == ')':
            var = var[:-1]
            state += 1

    if state == 0:
        while var[0] == '(' and var[-1] == ')':
           var = var[1:-1]

    return var

def getVariables(formulastring): 
    variables = []
    lastIdx = 1
    for i in range(len(formulastring)):
        c = formulastring[i]
        if c == '*' or c == '/' or c == '+' or c == '-':
            if i > 0 and formulastring[i - 1] == ')':
                var = formulastring[lastIdx:i]
                var = removeParenthesis(var)
                variables.append(var)
                lastIdx = i + 1
        
    var = formulastring[lastIdx:]
    var = removeParenthesis(var)
    variables.append(var)
    
    #print(variables)
    return variables

#getVariables("=((1)-(ReadCellUnavailableTime(s)-ReadCellUnavailableTimeLock(s)-ReadCellUnavailableTimeES(s))/CellAvailPmPeriodTime(s))*(100)")