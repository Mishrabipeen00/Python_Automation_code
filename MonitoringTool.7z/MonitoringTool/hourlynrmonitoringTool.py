import xlsxwriter
import os
from datetime import datetime
from functools import cmp_to_key
from formulacleanvariable import getVariables
from formulafilenr import formulakpi
from sitedisplay import display_site
from overall import overallsitedsiplay
import re
import math

def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        s = s[1:]
    if s[-1:] == '"':
        s = s[0:-1]
    return s



def remove_single_quoute(s):
    if len(s) == 0:
        return s
    if s[0] == "'":
        return s[1:-1]
    else:
        return s

def getValue(n):
    if n == '' or n == 'ND' or n=="NF":
        return float(0)
    else:
        return float(n)

def replacePercent(d):
    d=d.replace('%',"")
    return d

def getKPIs(data):
    for i in range(3):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data



def isInt(x):
    try:
        float(x)
        return True
    except ValueError:
        return False



def getCounter(data):
    if ',' in data:
        d = data.split(',')
    elif '\t' in data:
        d = data.split('\t')
    else:
        # handle error case where neither comma nor tab is found
        return []
    for i in range(3):
        d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d


def isFloat(num):
    try:
        float(num)
        return True
    except ValueError:
        return False

class Hourlysummarycell:
    def __init__(self,workbook):
        self.formulaKpi = formulakpi()
        self.sitedisplay=display_site()
        self.overallsitedisplay=overallsitedsiplay()
        self.finalResult = {}
        self.cellnummap={}
        self.worksheet = workbook.add_worksheet("summary")
        self.worksheet2=workbook.add_worksheet("cellnum_summary")
        self.row=0
        self.col=0
        self.cellrow=0
        self.cellcol=0
    

    def comparison(self):
        m = {}
        path = os.getcwd()
        self.folder = os.path.join(path, "MonitoringTool", "nrinput")
        self.files = os.listdir(self.folder)
        for file in self.files:
            subfiles = os.listdir(os.path.join(self.folder, file))
            for subfile in subfiles:
                with open(os.path.join(self.folder, file, subfile), 'r') as f:
                    datas = f.read().split('\n')
                    datas.pop()
                    counters = getCounter(datas[10])
                    for data in datas[11:]:
                        data_list = data.split(',')
                        for i in range(len(data_list[3:])):
                            ne=""
                            pattern1 = r"\((\w+-\w+-\d+)-CELL"
                            match = re.search(pattern1, data_list[2])
                            if match:
                                cell_identity = match.group(1)
                                ne=cell_identity
                            if counters[i] not in m:
                                m[counters[i]] = {}

                            currentDate = ""
                            currentTime = ""
                            if len(data_list[0])!=0:
                                currentDate = data_list[0].split()[0]
                                currentTime =to_string(data_list[0].split()[1])
                                
                            currentHour = currentTime[:2]
                            currentDateInStr = currentDate
                            currentHourkey= currentHour + ":00"
                            
                        
                            if currentDateInStr not in m[counters[i]]:
                                m[counters[i]][currentDateInStr] = {}

                            if ne in self.overallsitedisplay:
                                if currentHourkey not in m[counters[i]][currentDateInStr]:
                                    m[counters[i]][currentDateInStr][currentHourkey] = 0
                                m[counters[i]][currentDateInStr][currentHourkey] += getValue(data_list[i+3])
                            
        
        self.myData=m
        

    def comparison_cellnum(self):
        celldict = {}
        path = os.getcwd()
        self.folder = os.path.join(path, "MonitoringTool", "nrinput")
        self.files = os.listdir(self.folder)
        for file in self.files:
            subfiles = os.listdir(os.path.join(self.folder, file))
            for subfile in subfiles:
                with open(os.path.join(self.folder, file, subfile), 'r') as f:
                    datas = f.read().split('\n')
                    datas.pop()
                    counters = getCounter(datas[10])
                    for data in datas[11:]:
                        data_list = data.split(',')
                        for i in range(len(data_list[3:])):
                            ne=""
                            pattern1 = r"\((\w+-\w+-\d+)-CELL"
                            match = re.search(pattern1, data_list[2])
                            if match:
                                cell_identity = match.group(1)
                                ne=cell_identity
                            
                            if ne not in celldict:
                                celldict[ne]={}

                            cellnum = ''
                            pattern = r"CellIdentity(\d+)"
                            match = re.search(pattern, data_list[2])
                            if match:
                                cell_identity = match.group(0)
                                cellnum=cell_identity

                            if cellnum not in celldict[ne]:
                                celldict[ne][cellnum]={}

                            if counters[i] not in celldict[ne][cellnum]:
                                celldict[ne][cellnum][counters[i]]={}

                            currentDate = ""
                            currentTime = ""
                            if len(data_list[0])!=0:
                                currentDate = data_list[0].split()[0]
                                currentTime =to_string(data_list[0].split()[1])
                                
                            currentHour = currentTime[:2]
                            currentDateInStr = currentDate
                            currentHourkey= currentHour + ":00"
                            
                            
                            if currentDateInStr not in celldict[ne][cellnum][counters[i]]:
                                celldict[ne][cellnum][counters[i]][currentDateInStr] = {}

                            if  currentHourkey not in celldict[ne][cellnum][counters[i]][currentDateInStr]:
                                celldict[ne][cellnum][counters[i]][currentDateInStr][currentHourkey] = 0
                            celldict[ne][cellnum][counters[i]][currentDateInStr][currentHourkey] += getValue(data_list[i+3])

        self.cellmydata=celldict


    def formulaEvalwrite(self,currentDate, currenttime):
        for items in self.formulaKpi: # kpi which suppose to be calcualte using formula ( map )
            res= 0
            kpiFormula = self.formulaKpi[items]  # getting formula for given kpi
            varList = getVariables(kpiFormula)
            var = list(set(varList)) # remove duplicate variables  
            posAns = []
            postkpiFormula = kpiFormula
            if postkpiFormula=="=((10)*(InterferencePowerPUSCHTot(mW*10^13)/InterferencePowerPUSCHCnt(count)))-(130)":
                postkpiFormula="=((10)*math.log10(InterferencePowerPUSCHTot(mW*10^13)/InterferencePowerPUSCHCnt(count)))-(130)"
            for idx in range(len(var)):
                if isInt(var[idx]):
                    posAns.append(float(var[idx]))
                    continue

                postTmpText = 'posAns[' + str(idx) + ']'
                postkpiFormula=postkpiFormula.replace(var[idx],postTmpText)
                postTmpResult = 0
                try : 
                    postTmpResult = self.myData[var[idx]][currentDate][currenttime]
                except:
                    pass
                posAns.append(postTmpResult)
                try:
                    res = eval(postkpiFormula[1:])
                except:
                    pass

                if items not in self.finalResult:
                    self.finalResult[items] = {}

                if currentDate not in self.finalResult[items]:
                    self.finalResult[items][currentDate]={}
                if currenttime not in self.finalResult[items][currentDate]:
                    self.finalResult[items][currentDate][currenttime]=0
                self.finalResult[items][currentDate][currenttime] = res
        
        
        
    def formulaEvalwritecell(self,ne,cellnum,currentDate, currenttime):
        for items in self.formulaKpi: # kpi which suppose to be calcualte using formula ( map )
            result= 0
            kpiFormula = self.formulaKpi[items]  # getting formula for given kpi
            varList = getVariables(kpiFormula)
            var = list(set(varList)) # remove duplicate variables
            posAns = []
            postkpiFormula = kpiFormula
            if postkpiFormula=="=((10)*(InterferencePowerPUSCHTot(mW*10^13)/InterferencePowerPUSCHCnt(count)))-(130)":
                postkpiFormula="=((10)*math.log10(InterferencePowerPUSCHTot(mW*10^13)/InterferencePowerPUSCHCnt(count)))-(130)"
            for idx in range(len(var)):
                if isInt(var[idx]):
                    posAns.append(float(var[idx]))
                    continue

                postTmpText = 'posAns[' + str(idx) + ']'
                
                postkpiFormula=postkpiFormula.replace(var[idx],postTmpText)
                
                postTmpResult = 0
                try : 
                    postTmpResult = self.cellmydata[ne][cellnum][var[idx]][currentDate][currenttime]
                except:
                    pass
                posAns.append(postTmpResult)
                try:
                    result = eval(postkpiFormula[1:])
                except:
                    pass

                if ne not in self.cellnummap:
                    self.cellnummap[ne] = {}

                if cellnum not in self.cellnummap[ne]:
                    self.cellnummap[ne][cellnum]={}

                if items not in self.cellnummap[ne][cellnum]:
                    self.cellnummap[ne][cellnum][items] = {}

                if currentDate not in self.cellnummap[ne][cellnum][items]:
                    self.cellnummap[ne][cellnum][items][currentDate]={}
                if currenttime not in self.cellnummap[ne][cellnum][items][currentDate]:
                    self.cellnummap[ne][cellnum][items][currentDate][currenttime]=0
                self.cellnummap[ne][cellnum][items][currentDate][currenttime] = result

    
    def call_dates(self):
        self.comparison()
        lst_dates = set()
        lst_time = set()
        for kpi in self.myData:
            for currentdate in self.myData[kpi]:
                lst_dates.add(currentdate)
                for currenttime in self.myData[kpi][currentdate]:
                    lst_time.add(currenttime)

        lst_dates = sorted(list(lst_dates))
        lst_time = sorted(list(lst_time))

        for currentDate in lst_dates:
            for currenttime in lst_time:
                 self.formulaEvalwrite(currentDate,currenttime)

        prepostCall=self.finalResult
        
        self.worksheet.write(0, 0, 'DateTime')
        self.col = 1
        for kpi in prepostCall.keys():
            self.worksheet.write(0, self.col, kpi)
            self.col += 1

        self.row = 1
        for currentdate, times in prepostCall[list(prepostCall.keys())[0]].items():
            for currenttime in times:
                self.col = 0
                self.worksheet.write(self.row, self.col, f"{currentdate} {currenttime}")
                self.col += 1
                for kpi in prepostCall:
                    value = prepostCall[kpi][currentdate][currenttime]
                    self.worksheet.write(self.row, self.col, value)
                    self.col += 1
                self.row += 1

        self.comparison_cellnum()

        lstdates = set()
        lsttime = set()
        for ne in self.cellmydata:
            for cellnum in self.cellmydata[ne]:
                for kpi in self.cellmydata[ne][cellnum]:
                    for currentdate in self.cellmydata[ne][cellnum][kpi]:
                        lstdates.add(currentdate)
                        for currenttime in self.cellmydata[ne][cellnum][kpi][currentdate]:
                            lsttime.add(currenttime)
                        
        lstdates = sorted(list(lstdates))
        lsttime = sorted(list(lsttime))
        for ne in self.cellmydata:
            for cellnum in self.cellmydata[ne]:
                for currentDate in lstdates:
                    for currenttime in lsttime:
                        self.formulaEvalwritecell(ne,cellnum,currentDate,currenttime)

        writedictionay=self.cellnummap
        
        
        self.worksheet2.write(0, 0, 'Site')
        self.worksheet2.write(0, 1, 'CellNum')
        self.worksheet2.write(0, 2, 'DateTime')


        unique_data = {}
        for sitename in self.sitedisplay:
            if sitename not in writedictionay:
                continue
            for cellnum in writedictionay[sitename]:
                for kpi in writedictionay[sitename][cellnum]:
                    for date in writedictionay[sitename][cellnum][kpi]:
                        for time in writedictionay[sitename][cellnum][kpi][date]:
                            data_tuple = (sitename, cellnum, date, time)
                            if data_tuple not in unique_data:
                                unique_data[data_tuple] = {kpi: writedictionay[sitename][cellnum][kpi][date][time]}
                            else:
                                unique_data[data_tuple][kpi] = writedictionay[sitename][cellnum][kpi][date][time]

        # Write data to worksheet without duplicates
        for i, (data_tuple, kpis) in enumerate(unique_data.items()):
            sitename, cellnum, date, time = data_tuple
            self.worksheet2.write(i+1, 0, sitename)
            self.worksheet2.write(i+1, 1, cellnum)
            self.worksheet2.write(i+1, 2, f"{date} {time}")
            for j, (kpi_key, kpi_value) in enumerate(kpis.items()):
                if i == 0:
                    self.worksheet2.write(0, j+3, kpi_key)
                self.worksheet2.write(i+1, j+3, kpi_value)


  
    def callhourlynr(self):
        self.call_dates()

        
#         workbook.close()

        

# workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\5Goutput.xlsx',{'strings_to_numbers':True}) 

# summary=Hourlysummarycell(workbook)
# summary.callhourlynr()





 

    
    
    