import os
from datetime import datetime
import xlsxwriter

def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s
    
def getValue(n):
    if n == '' :
        return float(0)
    else:
        return float(n)

    
def getKPIs(data):
    d = data.split(',')
    d.pop(0)
    d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d




def MakedataFile():
    mapdata = {}
    current_dir = os.getcwd()
    input_folder = os.path.join(current_dir, "AlarmcorrelationTool", "input2")
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file_path = os.path.join(input_folder, file_name)
        with open(file_path, 'r') as file:
            raw_file_data = file.read().split('\n')  
        raw_file_data.pop()
        for data in raw_file_data[15:]:
            data_list = data.split(',')
            if len(data_list[6]) != 0:
                sitename = data_list[6].split('/')[2]
            if sitename not in mapdata:
                mapdata[sitename] = {}
            if len(data_list[7]) != 0:
                alaram = data_list[7]
            currentDate = ""
            currentTime = ""
            if len(data_list[8]) != 0:
                # Convert date string to datetime object
                if '-' in data_list[8]:
                    date_obj = datetime.strptime(data_list[8].split()[0], '%Y-%m-%d')
                else:
                    date_obj = datetime.strptime(data_list[8].split()[0], '%m/%d/%Y')
                # Format the datetime object to new string format
                currentd = date_obj.strftime('%d-%b-%y')
                currentDate=datetime.strptime(currentd, '%d-%b-%y').date()
                currentTime = data_list[8].split()[1]
            if currentDate not in mapdata[sitename]:
                mapdata[sitename][currentDate] = {}
            mapdata[sitename][currentDate][alaram] = mapdata[sitename][currentDate].get(alaram, 0) + 1
        
  
    return mapdata





def MakeRawDatafile():
    current_dir = os.getcwd()
    datafile=[]
    input_folder = os.path.join(current_dir, "AlarmcorrelationTool", "input2")
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file_path = os.path.join(input_folder, file_name)
        with open(file_path, 'r') as file:
            raw_file_data = file.read().split('\n')  
        raw_file_data.pop()
        for data in raw_file_data[15:]:
            data_list = data.split(',')
            sitename=""
            if len(data_list[6]) != 0:
                sitename = data_list[6].split('/')[2]
            currentDate = ""
            if len(data_list[8]) != 0:
                currentDate = data_list[8].split()[0]
            data_list.insert(7,sitename)
            data_list.insert(10,currentDate)
            datafile.append(data_list)

    
    return datafile



def write_to_excel():
    writemap=MakedataFile()
    rawmap=MakeRawDatafile()
    current_dir = os.getcwd()
    outfolder_folder = os.path.join(current_dir, "AlarmcorrelationTool", "output")
    new_output = outfolder_folder + '\\'+'raw_output.xlsx'
    workbook = xlsxwriter.Workbook(new_output,{'strings_to_numbers':True})
    worksheet = workbook.add_worksheet("AlarmCount") 
    date_format = workbook.add_format({'num_format': 'dd-mmm-yy'})
    worksheet2 = workbook.add_worksheet("raw_datafor7days")
    row1=0
    col1=0
    
    row = 0
    col = 0
    alarmnames = [] 
    for sitename in writemap:
        for currentDate in writemap[sitename]:
            for alarmname in writemap[sitename][currentDate]:
                if alarmname not in alarmnames: 
                    alarmnames.append(alarmname)
    alarmnames.sort() 
    worksheet.write(row, col, "Site Name")
    worksheet.write(row, col+1, "Date")
    worksheet.write(row, col+2, "Loc")
    for i in range(len(alarmnames)):
        worksheet.write(row, col+3+i, alarmnames[i]) 
    row += 1
    for sitename in writemap:
        for currentDate in writemap[sitename]:
            currentd = currentDate.strftime('%d-%b-%y')
            col = 0
            worksheet.write(row, col, sitename) 
            worksheet.write(row, col+1, currentDate,date_format)
            concatenated_value = sitename +"_" +currentd
            worksheet.write(row, col+2, concatenated_value)
            col=col+3
            for i in range(len(alarmnames)):
                if alarmnames[i] in writemap[sitename][currentDate].keys(): 
                    worksheet.write(row,col,writemap[sitename][currentDate][alarmnames[i]]) 
                else:
                    worksheet.write(row,col,"")
                col=col+1
            row=row+1 

    headers = ['No.', 'AckType', 'Severity', 'Code', 'Group', 'NE ID', 'Location', 'Sitename', 'Specific Problem', 'Time','Time','Clear time','Clear type','Ack user']

    for i in range(len(headers)):
        worksheet2.write(0, i, headers[i])

    for row1 in range(len(rawmap)):
        for col1 in range(len(rawmap[row1])):
            worksheet2.write(row1+1, col1, rawmap[row1][col1])
    workbook.close()









