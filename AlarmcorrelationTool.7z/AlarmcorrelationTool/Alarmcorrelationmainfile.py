import os
from tkinter import *
import tkinter as tk
from tkinter import ttk
import tkinter.messagebox
from tkinter import Tk, filedialog, Button, StringVar, OptionMenu
import xlsxwriter
from Alarmcorrelationfile import write_to_excel
from Alarmfile import writetoexcel
from replacecomma import replaceComma
 

root = Tk()   
root.geometry("800x500")
root.configure(bg='black')
open_output_file = ''
open_input_file = ''
date_list = None
short_name=None

#Title for tool
title = Label(root, text = "Alaram Correlation Tool",font=('Calisto MT',15),background='black',foreground='Red').place(x = 230, y = 6) 

def _submit():
    t=write_to_excel()
    print("output has been generated!!!")
    return t

def submit():
    t=writetoexcel()
    print("output has been generated!!!")
    return t

def call_both_functions():
    replaceComma()
    _submit()
    submit()
    

    
b = Button(root,command=lambda:call_both_functions(),text = "Generate Report",bg='red',  fg = 'blue')    
b.pack(ipadx=5, ipady=5,pady=5)
b.place(x=300, y=50)


root.mainloop()