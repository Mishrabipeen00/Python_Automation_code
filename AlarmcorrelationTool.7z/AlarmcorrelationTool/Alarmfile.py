import os
import xlsxwriter
from Alarmcorrelationfile import MakedataFile
from datetime import datetime
from replacecomma import headerfunction

def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s
    
def getValue(n):
    if n == '' :
        return float(0)
    else:
        return float(n)
    
def getCounter(data):
    d = data.split(',')
    d.pop(0)
    d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d

    
def getKPIs(data):
    d = data.split(',')
    d.pop(0)
    d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d



def MakeInputfile():
    my_data=[]
    current_dir = os.getcwd()
    input_folder = current_dir + "\\" + "AlarmcorrelationTool\\input1"
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file= open(input_folder + "\\" + file_name, 'r')
        raw_file_data = file.read().split('\n')  
        raw_file_data.pop()
        counters = getCounter(raw_file_data[0])
        shortname = ""
        sitename=""
        for data in raw_file_data[1:]:
            data_list = data.split(',')
            if len(data_list[0]) != 0:
                shortname = to_string(data_list[0])
            if len(data_list[0]) != 0:
                sitename = to_string(data_list[0]).split(';')[1]

            if len(data_list[1]) != 0:
                date_string = to_string(data_list[1])
                if '-' in date_string:
                    date_obj = datetime.strptime(date_string, '%d-%b-%y')
                else:
                    date_obj = datetime.strptime(date_string.replace(' ', '-'), '%d-%b-%y')
                date_string_formatted = date_obj.strftime('%d-%b-%y')
                data_list[1] = datetime.strptime(date_string_formatted, '%d-%b-%y').date()
                
            if len(data_list[0]) == 0:
                data_list[0] = shortname
            if len(data_list[0]) == 0:
                data_list[0] = sitename
            data_list.insert(1,sitename)
            my_data.append(data_list)
                 
    
    return my_data


def create_alarm_dict():
    alarm_dict = {}
    makerawdata = MakeInputfile()
    mergemap = MakedataFile()
    for data in makerawdata:
        sitename = data[1]
        date_str = data[2]
        if sitename in mergemap and date_str in mergemap[sitename]:
            alarm_data = mergemap[sitename][date_str]
            for alarm_name, alarm_value in alarm_data.items():
                alarm_dict.setdefault(sitename, {})
                alarm_dict[sitename].setdefault(date_str, {})
                alarm_dict[sitename][date_str][alarm_name] = alarm_value

    
    return alarm_dict




def create_final_dict():
    final_dict = {} 
    makerawdata = MakeInputfile()
    mergemap = MakedataFile()
    for data in makerawdata:
        sitename = data[1]
        date_str = data[2]
        if sitename in mergemap and date_str in mergemap[sitename]:
            alarm_data = mergemap[sitename][date_str]
            for alarm_name, alarm_count in alarm_data.items():
                if sitename not in final_dict:
                    final_dict[sitename] = {}
                if alarm_name not in final_dict[sitename]:
                    final_dict[sitename][alarm_name] = 0
                final_dict[sitename][alarm_name] += alarm_count

    return final_dict




def create_counter_dict():
    counterdict={}
    current_dir = os.getcwd()
    input_folder = current_dir + "\\" + "AlarmcorrelationTool\\input1"
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file= open(input_folder + "\\" + file_name, 'r')
        raw_file_data = file.read().split('\n')  
        raw_file_data.pop()
        counters = getCounter(raw_file_data[0])
        shortname = ""
        sitename=""
        for data in raw_file_data[1:]:
            data_list = data.split(',')
            if len(data_list[0]) != 0:
                shortname = to_string(data_list[0])
            if len(data_list[0]) != 0:
                sitename = to_string(data_list[0]).split(';')[1]

            if sitename not in counterdict:
                counterdict[sitename] = {}

            for i in range(len(counters)):
                if counters[i] not in counterdict[sitename]:
                    counterdict[sitename][counters[i]] = 0
                counterdict[sitename][counters[i]] += getValue(data_list[i+2])
    
    
    return counterdict




def final_pivot_dict():
    raw_dict = create_counter_dict()
    raw_alram_dict = create_final_dict()
    final_dict = {}
    for sitename, counters in raw_dict.items():
        if sitename in raw_alram_dict:
            counter_dict = {}
            for counter, countervalue in counters.items():
                counter_dict[counter] = countervalue
            for alramname, alramvalue in raw_alram_dict[sitename].items():
                counter_dict[alramname] = alramvalue
            final_dict[sitename] = counter_dict
            
    
    return final_dict



def writetoexcel():
    alramdict=create_alarm_dict()
    headerfilename=headerfunction()
    makerawdata=MakeInputfile()
    finalmap=final_pivot_dict()
    current_dir = os.getcwd()
    outfolder_folder = os.path.join(current_dir, "AlarmcorrelationTool", "output")
    new_output = outfolder_folder + '\\'+'output.xlsx'
    workbook = xlsxwriter.Workbook(new_output,{'strings_to_numbers':True})
    worksheet = workbook.add_worksheet("AlarmCorrelation") 
    date_format = workbook.add_format({'num_format': 'dd-mmm-yy'})
    worksheet2 = workbook.add_worksheet("raw_datafor7days")
    row1=0
    col1=0

    row=0
    col=0
    
    
    for i in range(len(headerfilename)):
        worksheet2.write(0, i, headerfilename[i])

    for row1 in range(len(makerawdata)):
        for col1 in range(len(makerawdata[row1])):
            if col1 == 2:
                worksheet2.write(row1+1, col1, makerawdata[row1][col1], date_format)
            else:
                worksheet2.write(row1+1, col1, makerawdata[row1][col1])

    max_col = worksheet2.dim_colmax + 1

    # Get all alarm names
    alarm_names = set()
    for sitename in alramdict:
        for date_str in alramdict[sitename]:
            alarm_data = alramdict[sitename][date_str]
            for alarm_name in alarm_data:
                alarm_names.add(alarm_name)
    
    for alarm_idx, alarm_name in enumerate(alarm_names):
        worksheet2.write(0, max_col + alarm_idx, alarm_name)

    for row_idx, data_row in enumerate(makerawdata):
        sitename = data_row[1]
        date_str = data_row[2]
        alarm_data = alramdict.get(sitename, {}).get(date_str, {})
        for alarm_idx, alarm_name in enumerate(alarm_names):
            alarm_value = alarm_data.get(alarm_name, "")
            worksheet2.write(row_idx+1, max_col + alarm_idx, alarm_value)

    header_names = []
    for sitename, counters in finalmap.items():
        for counter in counters.keys():
            if counter not in header_names:
                header_names.append(counter)
        for alarm in finalmap[sitename].keys():
            if alarm not in header_names:
                header_names.append(alarm)

    
    worksheet.write(0, 0, 'Sitename')

    # Write header names in the next columns
    for i, header in enumerate(header_names):
        worksheet.write(0, i+1, header)

    # Write data for each sitename
    row = 1
    for sitename, counters in finalmap.items():
        worksheet.write(row, 0, sitename)
        col = 1
        for header in header_names:
            if header in counters:
                worksheet.write(row, col, counters[header])
            elif header in finalmap[sitename]:
                worksheet.write(row, col, finalmap[sitename][header])
            col += 1
        row += 1

    workbook.close()





        