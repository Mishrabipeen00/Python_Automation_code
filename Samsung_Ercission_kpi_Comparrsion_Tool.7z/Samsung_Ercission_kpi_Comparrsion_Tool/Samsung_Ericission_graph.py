import xlsxwriter
import os
from datetime import datetime
from functools import cmp_to_key
from kpi_to_display import ercission_kpi,samsung_kpi
from formulaclenavariable import getVariables
from userinput import write_map


def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s

def remove_single_quoute(s):
    if len(s) == 0:
        return s
    if s[0] == "'":
        return s[1:-1]
    else:
        return s

def getValue(n):
    if n == '':
        return float(0)
    return float(n)

def getfloatvalue(n):
    if n == '':
        return float(0)
    elif n=='-':
        return float(0)
    return float(n)


def to_band(band):
    band_name = band.split('_')[0] + " Band"
    return band_name

# Function for getting kpi
def getKPIs(data):
    d = data.split(',')
    d.pop(0)
    d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d

def getKPI(data):
    d = data.split(',')
    for i in range(12):
        d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d


def to_date(s):
    s_list = s.split('-')
    if len(s_list) > 1:
        date = datetime.strptime(to_string(s), '%d-%b-%y')
        return date
    else:
        date = datetime.strptime(to_string(s), '%d %b %y')
        return date

def getDate(d):
    d_list=d.split('/')
    if len(d_list)>1:
        dd = datetime.strptime(to_string(d),"%m/%d/%Y")
        sdate=dd.strftime("%d %b %y")
        return sdate
    else:
        dd = datetime.strptime(to_string(d),"%d %b %y")
        sdate = dd.strftime("%d %b %y")
        return sdate
    
def compare_var(s1, s2):
    if len(s1) > len(s2):
        return -1
    else:
        return 1
    
def isInt(x):
    try:
        float(x)
        return True
    except ValueError:
        return False
    

def get_pre(pre_list, pos,val):
    if val==1:
        res = "n28"
    else:
        res="n78"
    if pos > 0:
        res += "  " + str(pos) 
    # Pre 2
    res += "(" + pre_list[0] + " to " + pre_list[-1] + ")"

    return res


def get_delta(l):
    deltas = []
    for sublist in l:
        if len(str(sublist[0])) == 0 or len(str(sublist[1])) == 0 or float(sublist[0]) == 0:
            deltas.append(0.0)
        else:
            delta = (float(sublist[1])-float(sublist[0]))*100/float(sublist[0])
            deltas.append(delta)
    
    return deltas

def abs_delta(value1, value2):
    deltas = [round(v2 - v1,2) for v1, v2 in zip(value1, value2)]
    return deltas


class catGraph:
    def __init__(self,_pre_list):
        path=os.getcwd()
        self.folder = os.path.join(path, "Samsung_Ercission_kpi_Comparrsion_Tool", "input1")
        self.ercfolder=os.path.join(path, "Samsung_Ercission_kpi_Comparrsion_Tool", "input2")
        self.files = os.listdir(self.folder)
        self.ercfiles = os.listdir(self.ercfolder)
        self.samforcal={}
        self.eriforcal={}
        self.average_dict = {}
        self.ercaverage_dict={}
        self.eric_kpi_display=ercission_kpi()
        self.sam_kpi_display=samsung_kpi()
        self.pre_list = _pre_list

        self.n28=[]
        self.n78=[]
        self.count={}


        #position for graph1
        self.pcol = 1
        self.row = 2
        self.wrow = 2

        #position for graph2
        self.ericcol = 1
        self.rows = 2
        self.wrows = 2

        #position for graph3
        self.poscol = 1
        self.posrow = 2
        self.widrows = 2


    def write_to_temp_map_samsung(self):
        for filename in self.files:
            my_data={}
            file = open(self.folder + "\\" + filename) 
            raw_data = file.read().split('\n')
            raw_data.pop()
            self.kpis = getKPIs(raw_data[0])
            for data in raw_data[1:]:
                data_list = data.split(',')
                if len(data_list[0]) != 0:
                    band= to_string(data_list[0])
                    for kpi in self.kpis:
                        if kpi not in my_data:
                            my_data[kpi] = {}
                        else:
                            break

                date=getDate(to_string(data_list[1]))
                for i in range(len(data_list[2:])):
                    if band not in my_data[self.kpis[i]]:
                        my_data[self.kpis[i]][band] = {}
                    if date not in my_data[self.kpis[i]][band]:
                         my_data[self.kpis[i]][band][date]=0
                    my_data[self.kpis[i]][band][date] += getValue(data_list[i+2])
        
        for kpi in my_data:
            for band in my_data[kpi]:
                sorted_data = sorted(my_data[kpi][band].items(), key=lambda x: x[0])
                my_data[kpi][band] = {date: value for date, value in sorted_data}
               
        self.myData=my_data
        
       
        
    def write_to_temp_map_ercission(self):
        for filename in self.ercfiles:
            ercission_data={}
            file = open(self.ercfolder + "\\" + filename) 
            raw_data = file.read().split('\n')
            raw_data.pop()
            self.kpis = getKPI(raw_data[0])
            for data in raw_data[1:]:
                data_list = data.split(',')
                if len(data_list[10]) != 0:
                    band= to_string(data_list[10])
                    for kpi in self.kpis:
                        if kpi not in ercission_data:
                            ercission_data[kpi] = {}
                        else:
                            break
                        if kpi not in self.count:
                            self.count[kpi]={}
                    
                date_string=data_list[0]
                date_object = datetime.strptime(date_string, "%Y%m%d")
                formatted_date = date_object.strftime("%m/%d/%Y")
                date=getDate(to_string(formatted_date))
                for i in range(len(data_list[12:])):
                    if band not in ercission_data[self.kpis[i]]:
                        ercission_data[self.kpis[i]][band] = {}
                    
                    if band not in self.count[self.kpis[i]]:
                        self.count[self.kpis[i]][band] = {}
                    if date not in ercission_data[self.kpis[i]][band]:
                         ercission_data[self.kpis[i]][band][date]=0
                    if date not in self.count[self.kpis[i]][band]:
                        self.count[self.kpis[i]][band][date]=0
                    self.count[self.kpis[i]][band][date]+=1
                    ercission_data[self.kpis[i]][band][date] += getfloatvalue(data_list[i+12])
                    

        for kpi in ercission_data:
            for band in ercission_data[kpi]:
                sorted_data = sorted(ercission_data[kpi][band].items(), key=lambda x: x[0])
                ercission_data[kpi][band] = {date: value for date, value in sorted_data}
                average_cal=self.eric_kpi_display[kpi][1] if kpi in self.eric_kpi_display else "nothing"
                if average_cal == "average":
                    for date in ercission_data[kpi][band]:
                        if self.count[kpi][band][date] != 0:
                            ercission_data[kpi][band][date] /= self.count[kpi][band][date]

        
        self.ercission=ercission_data
        

    def write_to_formula_sam(self,band,date):
        for kpis in self.sam_kpi_display:
            result=0
            kpi_formula = self.sam_kpi_display[kpis][0]
            var_list = getVariables(kpi_formula)
            var = list(set(var_list)) # remove duplicate variables
            #var.sort(key=cmp_to_key(compare_var))
            posAns = []
            postkpiFormula = kpi_formula
            for idx in range(len(var)):
                if isInt(var[idx]):
                    posAns.append(float(var[idx]))
                    continue

                postTmpText = 'posAns[' + str(idx) + ']'
                
                postkpiFormula=postkpiFormula.replace(var[idx],postTmpText)
                postTmpResult = 0
                try : 
                    postTmpResult = self.myData[remove_single_quoute(var[idx])][band][date]
                except:
                    pass
                posAns.append(postTmpResult)
                try:
                    result=round(eval(postkpiFormula),2)
                except ZeroDivisionError:
                    result = 0
            
            if kpis not in self.samforcal:
                self.samforcal[kpis]={}
            if band not in self.samforcal[kpis]:
                self.samforcal[kpis][band]={}

            if date not in self.samforcal:
                self.samforcal[kpis][band][date]=0
            self.samforcal[kpis][band][date]=result

        

    def write_to_formula_eric(self,band,date):
        for kpis in self.eric_kpi_display:
            result2=0
            kpi_formula = self.eric_kpi_display[kpis][0]
            var_list = getVariables(kpi_formula)
            var = list(set(var_list)) # remove duplicate variables
            #var.sort(key=cmp_to_key(compare_var))
            ericAns = []
            ericformulakpi = kpi_formula
            for idx in range(len(var)):
                if isInt(var[idx]):
                    ericAns.append(float(var[idx]))
                    continue

                erictemp = 'ericAns[' + str(idx) + ']'
                ericformulakpi=ericformulakpi.replace(var[idx],erictemp)
                ericTmpResult = 0
                try : 
                    ericTmpResult = self.ercission[remove_single_quoute(var[idx])][band][date]
                except:
                    pass
                ericAns.append(ericTmpResult)
                try:
                    result2=round(eval(ericformulakpi),2)
                except ZeroDivisionError:
                    result2 = 0
            
            if kpis not in self.eriforcal:
                self.eriforcal[kpis]={}
            if band not in self.eriforcal[kpis]:
                self.eriforcal[kpis][band]={}

            if date not in self.eriforcal:
                self.eriforcal[kpis][band][date]=0
            self.eriforcal[kpis][band][date]=result2

        

    
    def calculatesam_average(self, dates, value):
        for kpi in self.samforcal:
            self.average_dict[kpi] = {}
            for band in self.samforcal.get(kpi, {}):
                self.average_dict[kpi][band] = 0
                total_sum = 0
                total_count = 0
                for date_list in dates:
                    for date in date_list:
                        for sam_date in self.samforcal.get(kpi, {}).get(band, {}):
                            if datetime.strptime(date, "%d-%b-%y").date().strftime('%d %b %y') == sam_date:
                                total_sum += self.samforcal[kpi][band][sam_date]
                                total_count += 1
                if total_count > 0:
                    if kpi in value:
                        average = round(total_sum / total_count, 2)
                        self.average_dict[kpi][band] = average
                    else:
                        self.average_dict[kpi][band] = round(total_sum,2)
        
        for kpi in self.average_dict:
            for band in self.average_dict[kpi]:
                if band=="n28":
                    sam_value=self.average_dict[kpi][band]
                    self.n28.append([sam_value])
                else:
                    sam_value=self.average_dict[kpi][band]
                    self.n78.append([sam_value])



       
    def calculateeric_average(self,ericdates,ericvalue):
        for kpi in self.eriforcal:
            self.ercaverage_dict[kpi] = {}
            for band in self.eriforcal.get(kpi, {}):
                self.ercaverage_dict[kpi][band] = 0
                total_sum = 0
                total_count = 0
                for date_list in ericdates:
                    for date in date_list:
                        for ericdate in self.eriforcal.get(kpi, {}).get(band, {}):
                            if datetime.strptime(date, "%d-%b-%y").date().strftime('%d %b %y') == ericdate:
                                total_sum += self.eriforcal[kpi][band][ericdate]
                                total_count += 1
                if total_count > 0:
                    if kpi in ericvalue:
                        average = round(total_sum / total_count,2)
                        self.ercaverage_dict[kpi][band] = average
                    else:
                        self.ercaverage_dict[kpi][band] = round(total_sum,2)

        sam_values = [sublist[0] for sublist in self.n28]  # Get the first values from the existing sublists
        self.n28 = []  # Clear self.n28 for reassignment
        
        ericvalues= [sublist[0] for sublist in self.n78]
        self.n78=[]
        for i, (kpi, band_dict) in enumerate(self.ercaverage_dict.items()):
            for band, erc_dict in band_dict.items():
                if band == "n28":
                    erc_value = erc_dict
                    self.n28.append([sam_values[i], erc_value])
                else:
                    erc_value = erc_dict
                    self.n78.append([ericvalues[i], erc_value])

        
       
        
    def write_to_excel_file(self,workbook,worksheet,worksheet2,worksheet3,worksheet4,worksheet5,worksheet6,worksheet7,ip):
        color_format=workbook.add_format({'bold':True,'fg_color':'#C6DCE4','align':'center',
                                   'valign':'vcenter'})
        date_format= workbook.add_format({'num_format': 'dd/mm/yy'})
        color=workbook.add_format({'fg_color':'#C6DCE4'})
        self.color_forma=workbook.add_format({'border':1,
                                   'align':'center',
                                   'valign':'vcenter',
                                   'fg_color':'#C6DCE4',
                                   'bold':True,'text_wrap':'true'})
        self.color_bol=workbook.add_format({'align':'center',
                                   'valign':'vcenter'})

        mercol,merrow=1,0
        
        worksheet.write(1, 0, "Date")
        worksheet2.write(1, 0, "Date")
        worksheet5.write(1, 0, "Date")

        worksheet7.write(2,0,"Kpi",self.color_forma)
        worksheet7.write(2,1,"S",self.color_forma)
        worksheet7.write(2,2,"E",self.color_forma)
        worksheet7.write(2,3,"Delta abs(E-S)",self.color_forma)
        worksheet7.write(2,4,"Delta %",self.color_forma)

        worksheet7.write(2,5,"S",self.color_forma)
        worksheet7.write(2,6,"E",self.color_forma)
        worksheet7.write(2,7,"Delta abs(E-S)",self.color_forma)
        worksheet7.write(2,8,"Delta %",self.color_forma)

        worksheet7.merge_range(merrow,mercol,merrow+1,mercol+3,get_pre(self.pre_list[ip], ip,1),self.color_forma)
        mercol,merrow=5,0
        worksheet7.merge_range(merrow,mercol,merrow+1,mercol+3,get_pre(self.pre_list[ip], ip,2),self.color_forma)
        
        myData_kpi_names = list(self.samforcal.keys())
        ercission_kpi_names = list(self.eriforcal.keys())

        trow=2
        tcol=1
        datacol=1
        datarow=2

        bands=set()
        for kpis in myData_kpi_names:
            for band in self.samforcal[kpis]:
                bands.add(band)

        for kpiss in myData_kpi_names:
            if len(bands) > 1:
                worksheet5.merge_range(0, tcol, 0, tcol+len(bands) - 1, kpiss,color)
            else:
                worksheet5.write(0,tcol,kpiss,color)
            for newband in sorted(bands):
                worksheet5.write(1, tcol, newband)
                tcol += 1
            
        for samkpi in myData_kpi_names:
            for samband in self.samforcal[samkpi]:
                for samdate in self.samforcal[samkpi][samband]:
                    value = self.samforcal[samkpi][samband][samdate]
                    worksheet5.write(datarow, datacol, value)
                    datarow += 1
                datacol += 1
                datarow = 2

        #writing kpi name in column header
        header_row = []
        for i in range(max(len(myData_kpi_names), len(ercission_kpi_names))):
            if i < len(myData_kpi_names):
                header_row.append( myData_kpi_names[i])
            if i < len(ercission_kpi_names):
                header_row.append(ercission_kpi_names[i])
        worksheet.write_row(0, 1, header_row)
        worksheet2.write_row(0, 1, header_row)

        # Collect all unique dates from both dictionaries
        dates = set()
        samdates=set()
        for kpi in self.samforcal:
            for band in self.samforcal[kpi]:
                dates.update(self.samforcal[kpi][band].keys())
                samdates.update(self.samforcal[kpi][band].keys())

        for kpi in self.eriforcal:
            for band in self.eriforcal[kpi]:
                dates.update(self.eriforcal[kpi][band].keys())

        for date in sorted(samdates):
            worksheet5.write(trow, 0, to_date(date),date_format)
            trow+=1

        # Write the KPI values for each date
        row = 2
        ercrow=2
        for date in sorted(dates):
            worksheet.write(row, 0, to_date(date),date_format)  # Write the date in the first column
            worksheet2.write(row, 0, to_date(date),date_format)

            col = 1
            for kpi in myData_kpi_names:
                for band in self.samforcal[kpi]:
                    if band !="n28":
                        continue
                    if date in self.samforcal[kpi][band]:
                        value = self.samforcal[kpi][band][date]
                        worksheet.write(row, col, value)
                        worksheet.write(1,col,'S')
                        col+=1
                    col += 1
                    
            col = 2
            for kpi in ercission_kpi_names:
                for band in self.eriforcal[kpi]:
                    if band !="n28":
                        continue
                    if date in self.eriforcal[kpi][band]:
                        value = self.eriforcal[kpi][band][date]
                        worksheet.write(row, col, value)
                        worksheet.write(1,col,'E')
                        col+=1 
                    col += 1

            erccol=1
            for kpi in myData_kpi_names:
                for band in self.samforcal[kpi]:
                    if band !="n78":
                        continue
                    if date in self.samforcal[kpi][band]:
                        value = self.samforcal[kpi][band][date]
                        worksheet2.write(ercrow, erccol, value)
                        worksheet2.write(1,erccol,'S')
                        erccol +=1
                    erccol+=1


            erccol=2
            for kpi in ercission_kpi_names:
                for band in self.eriforcal[kpi]:
                    if band !="n78":
                        continue
                    if date in self.eriforcal[kpi][band]:
                        value = self.eriforcal[kpi][band][date]
                        worksheet2.write(ercrow, erccol, value)
                        worksheet2.write(1,erccol,'E')
                        erccol += 1
                    erccol+=1
            
            row += 1
            ercrow+=1


        #write comparsion summary data
        sumrow,sumrow2,sumrow3,delrow=3,3,3,3
        n28row,n28row2,erow=3,3,3

        deltarow=3
        deltn78row=3

        delta_cal= [round(delta, 2) for delta in get_delta(self.n28)]
        delta_cal78= [round(delta, 2) for delta in get_delta(self.n78)]
        average_dict_kpi_names = list(self.average_dict.keys())
        for items in average_dict_kpi_names:
            worksheet7.write(sumrow,0,items,self.color_bol)
            sumrow+=1

        values1,values2,values3,values4=[],[],[],[]

        for kpi in self.average_dict:
            for band in self.average_dict[kpi]:
                if band=="n28":
                    value=self.average_dict[kpi][band]
                    values1.append(self.average_dict[kpi][band])
                    worksheet7.write(sumrow2,1,value)
                    sumrow2+=1
                else:
                    value=self.average_dict[kpi][band]
                    values3.append(self.average_dict[kpi][band])
                    worksheet7.write(n28row,5,value)
                    n28row+=1
                    

        for kpi in self.ercaverage_dict:
            for band in self.ercaverage_dict[kpi]:
                if band=="n28":
                    value=self.ercaverage_dict[kpi][band]
                    values2.append(self.ercaverage_dict[kpi][band])
                    worksheet7.write(sumrow3,2,value)
                    sumrow3+=1
                else:
                    value=self.ercaverage_dict[kpi][band]
                    values4.append(self.ercaverage_dict[kpi][band])
                    worksheet7.write(n28row2,6,value)
                    n28row2+=1

        deltaresultn28=abs_delta(values1,values2)
        for d28 in deltaresultn28:
            worksheet7.write(delrow,3,d28)
            delrow+=1

        deltaresultn78=abs_delta(values3,values4)
        for d78 in deltaresultn78:
            worksheet7.write(erow,7,d78)
            erow+=1

        for delta_value in delta_cal:
            worksheet7.write(deltarow,4,delta_value)
            deltarow+=1

        for deltavalue in delta_cal78:
            worksheet7.write(deltn78row,8,deltavalue)
            deltn78row+=1
            


        series=['S','E'] 
        prow = 3
        worksheet3.merge_range(0, self.pcol, 0, self.pcol + 7, "Kpis" ,color_format)
        col = 1
        for kpi in self.samforcal:
            worksheet3.write(prow, 0, kpi)
            chart = workbook.add_chart({'type': 'line'})       
            worksheet3.insert_chart(prow, self.pcol, chart)
                
            chart.set_title({'name': to_string(kpi)})
            chart.set_legend({'position': 'bottom'})
            chart.set_x_axis({'date_axis': True})
            chart.set_x_axis({'minor_unit': 1, 'major_unit':1})


            last = 3 + len(dates) - 1
            for item in series:
                chart.add_series({'name' : item,'categories': '=n28_summary!$A$3:$A$' + str(last) ,'values' : ['n28_summary',self.row, col, self.row + len(dates) - 1, col]})
                col += 1
            prow += 17
        
        self.pcol += 8
        self.row += len(dates)

        pric = 3
        worksheet4.merge_range(0, self.ericcol, 0, self.ericcol + 7, "Kpis" ,color_format)
        col = 1
        for kpi in self.samforcal:
            worksheet4.write(pric, 0, kpi)
            chart = workbook.add_chart({'type': 'line'})       
            worksheet4.insert_chart(pric, self.ericcol, chart)
                
            chart.set_title({'name': to_string(kpi)})
            chart.set_legend({'position': 'bottom'})
            chart.set_x_axis({'date_axis': True})
            chart.set_x_axis({'minor_unit': 1, 'major_unit':1})


            last = 3 + len(dates) - 1
            for item in series:
                chart.add_series({'name' : item,'categories': '=n78_summary!$A$3:$A$' + str(last) ,'values' : ['n78_summary',self.rows, col, self.rows + len(dates) - 1, col]})
                col += 1
            pric += 17
        
        self.ericcol += 8
        self.rows += len(dates)

        newrow = 3
        worksheet6.merge_range(0, self.poscol, 0, self.poscol + 7, "Kpis" ,color_format)
        column = 1
        for kpi in self.samforcal:
            worksheet6.write(newrow, 0, kpi)
            chart = workbook.add_chart({'type': 'line'})       
            worksheet6.insert_chart(newrow, self.poscol, chart)
                
            chart.set_title({'name': to_string(kpi)})
            chart.set_legend({'position': 'bottom'})
            chart.set_x_axis({'date_axis': True})
            chart.set_x_axis({'minor_unit': 1, 'major_unit':1})


            last = 3 + len(samdates) - 1
            for item in bands:
                chart.add_series({'name' : item,'categories': '=sam_summary!$A$3:$A$' + str(last) ,'values' : ['sam_summary',self.posrow, column, self.posrow + len(samdates) - 1, column]})
                column += 1
            newrow += 17
        
        self.poscol += 8
        self.posrow += len(samdates)

        workbook.close()
        
    def generate_report(self,pre,bandvaluelist,ericbandvaluelist):
        self.write_to_temp_map_samsung()
        self.write_to_temp_map_ercission()
        for kpi in self.myData:
            for band in self.myData[kpi]:
                for date in self.myData[kpi][band]:
                    self.write_to_formula_sam(band,date)

        for kpi in self.ercission:
            for band2 in self.ercission[kpi]:
                for date2 in self.ercission[kpi][band]:
                    self.write_to_formula_eric(band2,date2)

        self.calculatesam_average(pre,bandvaluelist)
        self.calculateeric_average(pre,ericbandvaluelist)

        workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\5Goutput.xlsx',{'strings_to_numbers':True})
        worksheet = workbook.add_worksheet("n28_summary")
        worksheet2 = workbook.add_worksheet("n78_summary")
        worksheet3 = workbook.add_worksheet("n28_Graph")
        worksheet4 = workbook.add_worksheet("n78_Graph")
        worksheet5 = workbook.add_worksheet("sam_summary")
        worksheet6 = workbook.add_worksheet("sam_Graph")
        worksheet7 = workbook.add_worksheet("S vs E Comparison")

        for ip  in range(len(self.pre_list)):
            if len(self.pre_list[ip]) == 0:
                continue
            self.write_to_excel_file(workbook,worksheet,worksheet2,worksheet3,worksheet4,worksheet5,worksheet6,worksheet7,ip)



pre,bandvaluelist,ericbandvaluelist=write_map() 
d=catGraph(pre)
d.generate_report(pre,bandvaluelist,ericbandvaluelist)
# # # d.calculatesam_average(pre,bandvaluelist)
# # # d.calculateeric_average(pre,ericbandvaluelist)




 