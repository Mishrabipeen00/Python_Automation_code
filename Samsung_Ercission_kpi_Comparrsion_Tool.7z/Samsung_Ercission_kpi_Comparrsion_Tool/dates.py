import os
import pandas as pd
from datetime import datetime
from functools import cmp_to_key

year = {
    "Jan" : 0,
    "Feb" : 1,
    "Mar" : 2,
    "Apr" : 3,
    "May" : 4,
    "Jun" : 5, 
    "Jul" : 6,
    "Aug" : 7,
    "Sep" : 8,
    "Oct" : 9,
    "Nov" : 10, 
    "Dec" : 11
}

def compare(d1, d2):
    d1_list = d1.split()
    d2_list = d2.split()

    

    if int(d1_list[2]) < int(d2_list[2]):
        return -1
    elif int(d1_list[2]) == int(d2_list[2]):
        if year[d1_list[1]] < year[d2_list[1]]:
            return -1
        elif year[d1_list[1]] == year[d2_list[1]]:
            if int(d1_list[0]) < int(d2_list[0]):
                return -1
            elif int(d1_list[0]) == int(d2_list[0]):
                return 0
            else:
                return 1
        else:
            return 1
    else:
        return 1
    

def comparator(item1,item2):
    d1_list = item1.split()
    d2_list = item2.split()
    if int(d1_list[2]) < int(d2_list[2]):
        return -1
    elif int(d1_list[2]) > int(d2_list[2]):
        return 1
    return 0

def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s


def reformat(d):
    d_list = d.split('/')
    date = None
    if len(d_list) > 1:
        date = datetime.strptime(to_string(d), '%m/%d/%Y')
    else:
        date = datetime.strptime(to_string(d), '%m %d %Y')
    return  date.strftime("%d %b %y")



def getDates(): 
    path = os.getcwd()
    folder = path + "\\" + "Samsung_Ercission_kpi_Comparrsion_Tool\\input1"
    folder2 = path + "\\" + "Samsung_Ercission_kpi_Comparrsion_Tool\\input2"
    files = os.listdir(folder)
    files2=os.listdir(folder2)
    d = set()
    for file in files:
        _input = folder + '\\' + file
        df = pd.read_csv(_input, dtype={col: str for col in pd.read_csv(_input, nrows=1).columns})
        var = df.iloc[:, 1]
        for line in var:
            line_list = line.split('/')
            if len(line_list) > 1:
                new_line = ' '.join(tuple(line.split('/')))
                d.add(reformat(new_line))
                
            line_list = line.split()
            if len(line_list) > 1:
                d.add(reformat(line))
    for file in files2:
        _input = folder2 + '\\' + file
        df = pd.read_csv(_input, dtype={col: str for col in pd.read_csv(_input, nrows=1).columns})
        var = df['Date']
        date_objects = var.apply(lambda x: datetime.strptime(x, "%Y%m%d"))
        formatted_dates = date_objects.apply(lambda x: x.strftime("%m/%d/%Y"))
        df['Date'] = formatted_dates
        for line in formatted_dates:
            line_list = line.split('/')
            if len(line_list) > 1:
                new_line = ' '.join(tuple(line.split('/')))
                d.add(reformat(new_line))
                
            line_list = line.split()
            if len(line_list) > 1:
                d.add(reformat(line))

    dates = list(d)
    dates.sort(key=cmp_to_key(compare))
   
    return dates












    
    
        
        
        
