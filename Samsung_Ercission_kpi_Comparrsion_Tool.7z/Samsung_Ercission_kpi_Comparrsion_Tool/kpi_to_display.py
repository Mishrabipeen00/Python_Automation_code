from openpyxl import Workbook, load_workbook
import os
path=os.getcwd()
folder=path+"\\"+"Samsung_Ercission_kpi_Comparrsion_Tool\\kpi_formula.xlsx"

wb = load_workbook(folder)
ws1= wb["Samsung"]
ws2=wb["Ercission"]


def samsung_kpi():
    final_kpi_samsung={}
    for row in range(2, ws1.max_row + 1):
        key = ws1.cell(row, 1).value
        value = ws1.cell(row, 2).value
        value2=ws1.cell(row,3).value
        value3=ws1.cell(row,4).value
        final_kpi_samsung[key] = []
        final_kpi_samsung[key].append(value)
        final_kpi_samsung[key].append(value2)
        final_kpi_samsung[key].append(value3)

    
    return final_kpi_samsung



def ercission_kpi():
    final_kpi_ercission={}
    for row in range(2, ws2.max_row + 1):
        key = ws2.cell(row, 1).value
        value = ws2.cell(row, 2).value
        value2=ws2.cell(row,3).value
        value3=ws2.cell(row,4).value
        final_kpi_ercission[key] = []
        final_kpi_ercission[key].append(value)
        final_kpi_ercission[key].append(value2)
        final_kpi_ercission[key].append(value3)

    return final_kpi_ercission
