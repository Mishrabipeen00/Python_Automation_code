import re

def isInt(x):
    try:
        int(x)
        return True
    except ValueError:
        return False
    
def replacePercent(d):
    d=d.replace('%',"")
    return d

def removeParenthesis(var):
    if len(var) == 0:
        return var
    
    
    state = 0
    for c in var:
        if c == '(':
            state += 1
        elif c == ')':
            state -= 1

            
    if state != 0:   
        # print(var)
        while var[-1] == ')' and var[-2] == ')':
            var = var[:-1]
            state += 1
        while var[0] == '(' and var[1] == '(':
            var = var[1:]
            state -= 1
        if state != 0 and var[0] == '(': # keep this one first
            var = var[1:]
            state -= 1
        elif state != 0 and var[-1] == ')':
            var = var[:-1]
            state += 1

    if state == 0:
        while var[0] == '(' and var[-1] == ')':
           var = var[1:-1]

    return var

def getVariables(formulastring):
    variables = []
    lastIdx = 1
    #formula usecode mai hai
    for i in range(len(formulastring)):
        c = formulastring[i]

        if (c == '*' or c == '/' or c == '+'):
            if i > 0 and formulastring[i - 1] == ')':
                var = formulastring[lastIdx:i]
                var = removeParenthesis(var)
                variables.append(var)
                lastIdx = i + 1

        elif c == '-' and formulastring[i:i+2] != '- ':
            if i > 0 and formulastring[i - 1] == ')':
                var = formulastring[lastIdx:i]
                var = removeParenthesis(var)
                variables.append(var)
                lastIdx = i + 1

    var = formulastring[lastIdx:]
    var = removeParenthesis(var)
    variables.append(var)
    #print(variables)
    return variables


#getVariables("=((DLReceivedCQI0(count)*(0))+(DLReceivedCQI1(count)*(1))+(DLReceivedCQI2(count)*(2))+(DLReceivedCQI3(count)*(3))+(DLReceivedCQI4(count)*(4))+(DLReceivedCQI5(count)*(5))+(DLReceivedCQI6(count)*(6))+(DLReceivedCQI7(count)*(7))+(DLReceivedCQI8(count)*(8))+(DLReceivedCQI9(count)*(9))+(DLReceivedCQI10(count)*(10))+(DLReceivedCQI11(count)*(11))+(DLReceivedCQI12(count)*(12))+(DLReceivedCQI13(count)*(13))+(DLReceivedCQI14(count)*(14))+(DLReceivedCQI15(count)*(15)))/(DLReceivedCQI0(count)+DLReceivedCQI1(count)+DLReceivedCQI2(count)+DLReceivedCQI3(count)+DLReceivedCQI4(count)+DLReceivedCQI5(count)+DLReceivedCQI6(count)+DLReceivedCQI7(count)+DLReceivedCQI8(count)+DLReceivedCQI9(count)+DLReceivedCQI10(count)+DLReceivedCQI11(count)+DLReceivedCQI12(count)+DLReceivedCQI13(count)+DLReceivedCQI14(count)+DLReceivedCQI15(count))")



