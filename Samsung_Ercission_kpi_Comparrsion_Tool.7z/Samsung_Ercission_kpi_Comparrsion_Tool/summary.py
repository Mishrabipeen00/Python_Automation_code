import xlsxwriter
from datetime import datetime
import os
from functools import cmp_to_key
from kpi_to_display import ercission_kpi,samsung_kpi
from formulaclenavariable import getVariables
from userinput import write_map


#To remove double quote from string
def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        s = s[1:]
    if s[-1:] == '"':
        s = s[0:-1]
    return s

def remove_quote(s):
    if len(s) == 0:
        return s
    if s[0] == "'":
        s = s[1:]
    if s[-1:] == "'":
        s = s[0:-1]
    return s

def compare_var(s1, s2):
    if len(s1) > len(s2):
        return -1
    else:
        return 1

def remove_single_quoute(s):
    if len(s) == 0:
        return s
    if s[0] == "'":
        return s[1:-1]
    else:
        return s


def getKPIs(data):
    for i in range(2):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data

def getDate(d):
    d_list=d.split('/')
    if len(d_list)>1:
        dd = datetime.strptime(to_string(d),"%m/%d/%Y")
        sdate=dd.strftime("%d %b %y")
        return sdate
    else:
        dd = datetime.strptime(to_string(d),"%d %b %y")
        sdate = dd.strftime("%d %b %y")
        return sdate
    

def getBandName(string):
    s = string.split('_')
    if isInt(s[0].split()[0]):
        return s[0] + " " + "Band"
    else:
        if(len(s) > 2):
            return s[-2] + " " + s[-1] + " " + "Band"
        else:
            return s[-1] + " " + "Band"

def getBands(data):
    temp = ['2300 C1 Band', '2300 C2 Band', '1800 Band','850 C1 Band','850 C2 Band']
    # return l
    s = set()
    for line in data:
        line_list = line.split(',')
        if len(line_list[0]) != 0:
            s.add(getBandName(to_string(line_list[0])))
    #print(s)
    l = list(s)
    #print(l)
    l.sort(key=cmp_to_key(compare)) # 4 temp[3:]
    
    return l

def isInt(x):
    try:
        int(x)
        return True
    except ValueError:
        return False

def compare(x1, y1):
    x = x1.split()
    y = y1.split()

    if int(x[0]) == int(y[0]): 
        if isInt(x[1][1]) and isInt(y[1][1]):
            if int(x[1][1]) < int(y[1][1]):
                return -1
            else:
                return 1
        else:
            if isInt(x[1][1]):
                return 1
            else: 
                return -1

    if int(x[0]) > int(y[0]):
        return -1
    return 1



def to_date(sdate):
    date_list = sdate.split('-')
    current_date = None
    if len(date_list) > 1:
        current_date = datetime.strptime(sdate,"%d-%b-%y")
    else:
        current_date = datetime.strptime(sdate,"%d %b %y")

    return current_date

def date_in_range(user_date, r, current_date):
        
    d1 = to_date(user_date)
    d2 = to_date(current_date)

    d  =  str(d2 - d1).split()
    
    if len(d) == 1:
        return True
    if int(d[0]) < r and int(d[0]) >= 0:
        return True
    else:
        return False
    

def getValue(n):
    if n == '':
        return float(0)
    return float(n)

def getfloatvalue(n):
    if n == '':
        return float(0)
    elif n=='-':
        return float(0)
    return float(n)


def to_band(band):
    band_name = band.split('_')[0] + " Band"
    return band_name

# Function for getting kpi
def getKPIs(data):
    d = data.split(',')
    d.pop(0)
    d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d


def getKPI(data):
    d = data.split(',')
    for i in range(12):
        d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d



def date_in_list(l, scurr_date):
    current_date = to_date(scurr_date)
    for sdate in l:
        date = to_date(sdate)
        if date == current_date:
            return True
    return False
        


def get_delta(l):
    if len(str(l[0])) == 0 or len(str(l[1])) == 0 or float(l[0]) == 0:
        return 0.0
    
    ans = (float(l[1])-float(l[0]))*100/float(l[0])
    return ans



def get_pre(pre_list, pos,val):
    if val==1:
        res = "n28"
    else:
        res="n78"
    if pos > 0:
        res += "  " + str(pos) 
    # Pre 2
    res += "(" + pre_list[0] + " to " + pre_list[-1] + ")"

    return res

def get_delta(l):
    deltas = []
    for sublist in l:
        if len(str(sublist[0])) == 0 or len(str(sublist[1])) == 0 or float(sublist[0]) == 0:
            deltas.append(0.0)
        else:
            delta = (float(sublist[1])-float(sublist[0]))*100/float(sublist[0])
            deltas.append(delta)
    
    return deltas


def get_absdelta(l):
    deltas = []
    for sublist in l:
        delta = (float(sublist[1])-float(sublist[0]))
        deltas.append(delta)
    
    return deltas




    
class Summary:
    def __init__(self,_pre_list):
        self.condition = 0
        path=os.getcwd()
        self.folder = os.path.join(path, "Samsung_Ercission_kpi_Comparrsion_Tool", "input1")
        self.ercfolder=os.path.join(path, "Samsung_Ercission_kpi_Comparrsion_Tool", "input2")
        self.files = os.listdir(self.folder)
        self.ercfiles = os.listdir(self.ercfolder)
        self.samforcal={}
        self.eriforcal={}
        self.average_dict = {}
        self.ercaverage_dict={}
        self.eric_kpi_display=ercission_kpi()
        self.sam_kpi_display=samsung_kpi()
        self.count={}
        self.pre_list = _pre_list
        
        
    def write_to_temp_map_samsung(self):
        for filename in self.files:
            my_data={}
            file = open(self.folder + "\\" + filename) 
            raw_data = file.read().split('\n')
            raw_data.pop()
            self.kpis = getKPIs(raw_data[0])
            for data in raw_data[1:]:
                data_list = data.split(',')
                if len(data_list[0]) != 0:
                    band= to_string(data_list[0])
                    for kpi in self.kpis:
                        if kpi not in my_data:
                            my_data[kpi] = {}
                        else:
                            break

                date=getDate(to_string(data_list[1]))
                for i in range(len(data_list[2:])):
                    if band not in my_data[self.kpis[i]]:
                        my_data[self.kpis[i]][band] = {}
                    if date not in my_data[self.kpis[i]][band]:
                         my_data[self.kpis[i]][band][date]=0
                    my_data[self.kpis[i]][band][date] += getValue(data_list[i+2])
        
        for kpi in my_data:
            for band in my_data[kpi]:
                sorted_data = sorted(my_data[kpi][band].items(), key=lambda x: x[0])
                my_data[kpi][band] = {date: value for date, value in sorted_data}
               
        self.myData=my_data
        
       
        
    def write_to_temp_map_ercission(self):
        for filename in self.ercfiles:
            ercission_data={}
            file = open(self.ercfolder + "\\" + filename) 
            raw_data = file.read().split('\n')
            raw_data.pop()
            self.kpis = getKPI(raw_data[0])
            for data in raw_data[1:]:
                data_list = data.split(',')
                if len(data_list[10]) != 0:
                    band= to_string(data_list[10])
                    for kpi in self.kpis:
                        if kpi not in ercission_data:
                            ercission_data[kpi] = {}
                        else:
                            break
                        if kpi not in self.count:
                            self.count[kpi]={}
                    
                date_string=data_list[0]
                date_object = datetime.strptime(date_string, "%Y%m%d")
                formatted_date = date_object.strftime("%m/%d/%Y")
                date=getDate(to_string(formatted_date))
                for i in range(len(data_list[12:])):
                    if band not in ercission_data[self.kpis[i]]:
                        ercission_data[self.kpis[i]][band] = {}
                    
                    if band not in self.count[self.kpis[i]]:
                        self.count[self.kpis[i]][band] = {}
                    if date not in ercission_data[self.kpis[i]][band]:
                         ercission_data[self.kpis[i]][band][date]=0
                    if date not in self.count[self.kpis[i]][band]:
                        self.count[self.kpis[i]][band][date]=0
                    self.count[self.kpis[i]][band][date]+=1
                    ercission_data[self.kpis[i]][band][date] += getfloatvalue(data_list[i+12])
                    

        for kpi in ercission_data:
            for band in ercission_data[kpi]:
                sorted_data = sorted(ercission_data[kpi][band].items(), key=lambda x: x[0])
                ercission_data[kpi][band] = {date: value for date, value in sorted_data}
                average_cal=self.eric_kpi_display[kpi][1] if kpi in self.eric_kpi_display else "nothing"
                if average_cal == "average":
                    for date in ercission_data[kpi][band]:
                        if self.count[kpi][band][date] != 0:
                            ercission_data[kpi][band][date] /= self.count[kpi][band][date]

        
        self.ercission=ercission_data
        

    def write_to_formula_sam(self,band,date):
        for kpis in self.sam_kpi_display:
            result=0
            kpi_formula = self.sam_kpi_display[kpis][0]
            var_list = getVariables(kpi_formula)
            var = list(set(var_list)) # remove duplicate variables
            #var.sort(key=cmp_to_key(compare_var))
            posAns = []
            postkpiFormula = kpi_formula
            for idx in range(len(var)):
                if isInt(var[idx]):
                    posAns.append(float(var[idx]))
                    continue

                postTmpText = 'posAns[' + str(idx) + ']'
                
                postkpiFormula=postkpiFormula.replace(var[idx],postTmpText)
                postTmpResult = 0
                try : 
                    postTmpResult = self.myData[remove_single_quoute(var[idx])][band][date]
                except:
                    pass
                posAns.append(postTmpResult)
                try:
                    result=round(eval(postkpiFormula),2)
                except ZeroDivisionError:
                    result = 0
            
            if kpis not in self.samforcal:
                self.samforcal[kpis]={}
            if band not in self.samforcal[kpis]:
                self.samforcal[kpis][band]={}

            if date not in self.samforcal:
                self.samforcal[kpis][band][date]=0
            self.samforcal[kpis][band][date]=result

        

    def write_to_formula_eric(self,band,date): 
        for kpis in self.eric_kpi_display:
            result2=0
            kpi_formula = self.eric_kpi_display[kpis][0]
            var_list = getVariables(kpi_formula)
            var = list(set(var_list)) # remove duplicate variables
            #var.sort(key=cmp_to_key(compare_var))
            ericAns = []
            ericformulakpi = kpi_formula
            for idx in range(len(var)):
                if isInt(var[idx]):
                    ericAns.append(float(var[idx]))
                    continue

                erictemp = 'ericAns[' + str(idx) + ']'
                ericformulakpi=ericformulakpi.replace(var[idx],erictemp)
                ericTmpResult = 0
                try : 
                    ericTmpResult = self.ercission[remove_single_quoute(var[idx])][band][date]
                except:
                    pass
                ericAns.append(ericTmpResult)
                try:
                    result2=round(eval(ericformulakpi),2)
                except ZeroDivisionError:
                    result2 = 0
            
            if kpis not in self.eriforcal:
                self.eriforcal[kpis]={}
            if band not in self.eriforcal[kpis]:
                self.eriforcal[kpis][band]={}

            if date not in self.eriforcal:
                self.eriforcal[kpis][band][date]=0
            self.eriforcal[kpis][band][date]=result2


        
        
    def calculatesam_average(self,ip,values):
        self.n28=[]
        self.n78=[]
        for kpi in self.samforcal:
            self.average_dict[kpi] = {}
            for band in self.samforcal.get(kpi, {}):
                self.average_dict[kpi][band] = 0
                total_sum = 0
                total_count = 0
                for sam_date in self.samforcal.get(kpi, {}).get(band, {}):
                    if date_in_list(self.pre_list[ip], sam_date):
                        total_sum += self.samforcal[kpi][band][sam_date]
                        total_count += 1
                if total_count > 0:
                    if kpi in values:
                        average = round(total_sum / total_count, 2)
                        self.average_dict[kpi][band] = average
                    else:
                        self.average_dict[kpi][band] = round(total_sum,2)
        
                        
        for kpi in self.average_dict:
            for band in self.average_dict[kpi]:
                if band == "n28":
                    sam_value = self.average_dict[kpi][band]
                    self.n28.append([sam_value])  
                elif band == "n78":
                    sam_value = self.average_dict[kpi][band]
                    self.n78.append([sam_value])  

    def calculateeric_average(self,ip,ericvalue):
        for kpi in self.eriforcal:
            self.ercaverage_dict[kpi] = {}
            for band in self.eriforcal.get(kpi, {}):
                self.ercaverage_dict[kpi][band] = 0
                total_sum = 0
                total_count = 0
                for ericdate in self.eriforcal.get(kpi, {}).get(band, {}):
                    if date_in_list(self.pre_list[ip], ericdate):
                        total_sum += self.eriforcal[kpi][band][ericdate]
                        total_count += 1
                if total_count > 0:
                    if kpi in ericvalue:
                        average = round(total_sum / total_count,2)
                        self.ercaverage_dict[kpi][band] = average
                    else:
                        self.ercaverage_dict[kpi][band] = round(total_sum,2)

        sam_values = [sublist[0] for sublist in self.n28]  # Get the first values from the existing sublists
        self.n28 = []  # Clear self.n28 for reassignment
        
        ericvalues= [sublist[0] for sublist in self.n78]
        self.n78=[]
        for i, (kpi, band_dict) in enumerate(self.ercaverage_dict.items()):
            for band, erc_dict in band_dict.items():
                if band == "n28":
                    erc_value = erc_dict
                    self.n28.append([sam_values[i], erc_value])
                else:
                    erc_value = erc_dict
                    self.n78.append([ericvalues[i], erc_value])

        

    
    def write_to_excel(self,workbook):
        self.worksheet = workbook.add_worksheet("summary")
        color_format=workbook.add_format({'bold':True,'fg_color':'#C6DCE4','align':'center',
                                   'valign':'vcenter'})
        date_format= workbook.add_format({'num_format': 'dd/mm/yy'})
        color=workbook.add_format({'fg_color':'#C6DCE4'})
        self.color_forma=workbook.add_format({'border':1,
                                   'align':'center',
                                   'valign':'vcenter',
                                   'fg_color':'#C6DCE4',
                                   'bold':True,'text_wrap':'true'})
        self.color_bol=workbook.add_format({'align':'center',
                                   'valign':'vcenter'})
        
        self.worksheet.write(2,0,"Kpi",self.color_forma)
        self.worksheet.write(2,1,"S",self.color_forma)
        self.worksheet.write(2,2,"E",self.color_forma)
        self.worksheet.write(2,3,"Delta abs(E-S)",self.color_forma)
        self.worksheet.write(2,4,"Delta %",self.color_forma)

        self.worksheet.write(2,5,"S",self.color_forma)
        self.worksheet.write(2,6,"E",self.color_forma)
        self.worksheet.write(2,7,"Delta abs(E-S)",self.color_forma)
        self.worksheet.write(2,8,"Delta %",self.color_forma)
        sumrow2=3
        for kpi in self.average_dict:
            for band in self.average_dict[kpi]:
                if band=="n28":
                    value=self.average_dict[kpi][band]
                    self.worksheet.write(sumrow2,1,value)
                    sumrow2+=1

        

    def generate_report(self,bandvaluelist,ericbandvaluelist):
        self.write_to_temp_map_samsung()
        self.write_to_temp_map_ercission()
        for kpi in self.myData:
            for band in self.myData[kpi]:
                for date in self.myData[kpi][band]:
                    self.write_to_formula_sam(band,date)

        for kpi in self.ercission:
            for band2 in self.ercission[kpi]:
                for date2 in self.ercission[kpi][band]:
                    self.write_to_formula_eric(band2,date2)

        for ip  in range(len(self.pre_list)):
            if len(self.pre_list[ip]) == 0:
                continue
            self.calculatesam_average(ip,bandvaluelist)
            self.calculateeric_average(ip,ericbandvaluelist)

    def call_category(self,workbook):
        self.write_to_excel(workbook)
   

workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\outputfile.xlsx',{'strings_to_numbers':True})

pre,bandvaluelist,ericbandvaluelist=write_map()
summary = Summary(pre)
summary.generate_report(bandvaluelist,ericbandvaluelist)
summary.call_category(workbook)

workbook.close()
