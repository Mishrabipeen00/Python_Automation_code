import os
from tkinter import *
import tkinter as tk
from tkinter import ttk
from Samsung_Ericission_graph import catGraph
from userinput import write_map,write_to_file
from tkinter import Tk, Button
import xlsxwriter



# Get output name from file
def getOutputName(s):
    s_list = s.split('.')
    return s_list[0]+"Output"



root = Tk()   
root.geometry("800x500")
root.configure(bg='black')
open_output_file = ''
open_input_file = ''
date_list = None
short_name=None

#Title for tool
title = Label(root, text = "Samsung&Ercission Comparision Tool Dashboard",font=('Calisto MT',15),background='black',foreground='Red').place(x = 170, y = 6) 

 
write_to_file()
def _submit():
    path=os.getcwd()
    outfolder=path+"\\"+"Samsung_Ercission_kpi_Comparrsion_Tool\\output"
    _output = outfolder + '\\'+"Samsung_ercission_comparsion_report.xlsx"
    pre,bandvaluelist,ericbandvaluelist=write_map() 
    workbook = xlsxwriter.Workbook(_output,{'strings_to_numbers':True})

    graph = catGraph(pre)
    graph.generate_report(workbook,pre,bandvaluelist,ericbandvaluelist)
    print("output has been generated!!!")
    workbook.close()
    
    
b = Button(root,command=lambda: _submit(),text = "Generate Report",bg='red',  fg = 'blue')    
b.pack(ipadx=5, ipady=5,pady=5)
b.place(x=330, y=50)



root.mainloop()