import xlsxwriter
from numpy import NaN
import os
from dates import getDates
import pandas as pd
from kpi_to_display import samsung_kpi,ercission_kpi


# kpis, bands, toband
def to_string(s):
    if len(s) == 0:
        return
    if s[0] == '"':
        return s[1:-1]
    else:
        return s

def toLowerCase(s):
    return s.strip().lower()

def getKPIs(data):
    for i in range(2):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data

#return non_kpis 


def getPos(s):
    prePos = {
        'prs' : 0,
        'prs1': 1,
        'prs2': 2,
        'prs3': 3,
        'prs4': 4,
        'prs5': 5
    }

    
    if s[1] == 'r':
        return prePos[s]
    
    
def listofsamsungkpi():
    samkpilist=[]
    samfunc=samsung_kpi()
    for kpi in samfunc:
        samkpilist.append(kpi)

    return samkpilist


def listofercikpi():
    erickpilist=[]
    ericfunc=ercission_kpi()
    for kpi in ericfunc:
        erickpilist.append(kpi)
    
    return erickpilist
    
def sam_remark():
    samremarklist = []
    remarkmap = samsung_kpi()
    for kpi in remarkmap:
        samremarklist.append(remarkmap[kpi][2])  # Append the second value from each key-value pair
    return samremarklist

def eric_remark():
    ericremarklist = []
    remarkmap = ercission_kpi()
    for kpi in remarkmap:
       ericremarklist.append(remarkmap[kpi][2])  # Append the second value from each key-value pair
    
    return ericremarklist

   


def write_to_file():
    all_k=listofsamsungkpi()
    l=listofercikpi()
    t=getDates()
    sr=sam_remark()
    er=eric_remark()
    
    path=os.getcwd()
    folder=path+"\\"+"Samsung_Ercission_kpi_Comparrsion_Tool"
    f = open(folder + "\\" +'raw_input.csv', 'w')
    heading=['Date','Remarks','Samsung_kpi','Value','Ercission_kpi','Value1']
    
    f.write('sep=,')
    f.write('\n')
    for item in heading:
        f.write(item +',')
    f.write('\n')

    for i in range(max(len(all_k),len(t), len(l),len(sr),len(er))):
        if i<len(t):
            f.write(t[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        f.write('')
        f.write(',')
       
        if i < len(all_k):
            f.write(all_k[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        if i < len(sr):
            f.write(sr[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')
        

        if i < len(l):
            f.write(l[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        if i < len(er):
            f.write(er[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        f.write('\n')


# short name to band
def write_map():
    m={}
    short_to_band = {}
    formulamap={}
    path=os.getcwd()
    folder=path+"\\"+"Samsung_Ercission_kpi_Comparrsion_Tool"
    file=open(folder + "\\" + 'raw_input.csv',"r")
    raw_data=file.read().split('\n')
    raw_data.pop()
    
    
    # making pre, post list
    pre = [[],[],[],[],[],[]]
    bandvaluelist=[]
    ericbandvaluelist=[]
    dateToRemark = {}
    
    
    for d in raw_data[1:]:
        data_list = d.split(',') 
        if len(data_list[0]) == 0:
            break
        if len(data_list[0]) != 0:
            date= to_string(data_list[0])

        if len(data_list[1]) != 0:
            remark= to_string(data_list[1])
            dateToRemark[date] = toLowerCase(remark)
            if remark[1] == 'r':
                pre[getPos(toLowerCase(remark))].append(to_string(data_list[0]))

    
    for d in raw_data[1:]:
        data_list = d.split(',')
        if len(data_list) <1:
            break

        if len(data_list[3])!=0:
            value=to_string(data_list[3])

            if value[1]=='v':
                bandvaluelist.append(to_string(data_list[2]))

        if len(data_list[5])!=0:
            bandvalue=to_string(data_list[5])
            if bandvalue[1]=='v':
                ericbandvaluelist.append(to_string(data_list[4]))
       
    
    return [pre,bandvaluelist,ericbandvaluelist]
            
        
#write_to_file()
# result=write_map()
# for item in result:
#    print(item)








