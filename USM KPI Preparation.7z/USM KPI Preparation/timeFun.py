import os
import pandas as pd
from functools import cmp_to_key
import time



year = {
    "Jan" : 0,
    "Feb" : 1,
    "Mar" : 2,
    "Apr" : 3,
    "May" : 4,
    "Jun" : 5, 
    "Jul" : 6,
    "Aug" : 7,
    "Sep" : 8,
    "Oct" : 9,
    "Nov" : 10, 
    "Dec" : 11
}



def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s



time_format = '%H:%M:%S' 

def compare_as_time(time_str1, time_str2):
    time1 = time.strptime(time_str1, time_format)
    time2 = time.strptime(time_str2, time_format)

    if time1 < time2:
        return -1
    elif time1 > time2:
        return 1
    else:
        return 0



def getTimes(): 
    path=os.getcwd()
    folder=path+"\\"+"USM KPI Preparation\\input"
    files = os.listdir(folder)
    demo=set()
    dateTimeInString=[]
    datesInStr=[]
    for file in files:
        if file == 'raw_input.csv':
            continue
        _input = folder + '\\' + file
        f=open(_input)
        data=f.read().split('\n')
        for d in data[4:]:
            data_list = d.split(',')
            if len(data_list[0]) == 0:
                break
            if len(data_list[3]) != 0:
                date= to_string(data_list[3])
                dateTimeInString.append(date)

        for item in dateTimeInString:
            tmp=item.split()[1]
            datesInStr.append(tmp)

        for line in datesInStr:
            demo.add(line)

    dates= list(demo)
    sorted_times = sorted(dates, key=cmp_to_key(compare_as_time))
    #print(sorted_times)
    return sorted_times
    




      
        







    
    
        
        
        


    



    



