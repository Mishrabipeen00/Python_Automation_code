import xlsxwriter
import os
from datetime import datetime
from functools import cmp_to_key
from dateFun import getDates
from formulaMap import formula_kpi
from finalKpi import final_kpi
from dailysiterawinput import non_kpis_formula,write_map
from timeFun import getTimes
from formulaCleanvariable import getVariables
import multiprocessing
from multiprocessing import Process, current_process


# function to remove remove quotes
def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s

def remove_single_quoute(s):
    if len(s) == 0:
        return s
    if s[0] == "'":
        return s[1:-1]
    else:
        return s

def getValue(n):
    if n == '':
        return float(0)
    return float(n)

def replacePercent(d):
    d=d.replace('%',"")
    return d

def getKPIs(data):
    for i in range(7):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data


def to_date(s):
    s_list = s.split('-')
    if len(s_list) > 1:
        date = datetime.strptime(to_string(s), '%Y-%m-%d')
        return date
    else:
        date = datetime.strptime(to_string(s), '%Y %m %d')
        return date

def getDate(d):
    d_list=d.split('-')
    if len(d_list)>1:
        dd = datetime.strptime(to_string(d),"%Y-%m-%d")
        sdate=dd.strftime("%d %b %y")
        return sdate
    else:
        dd = datetime.strptime(to_string(d),"%Y %m %d")
        sdate = dd.strftime("%d %b %y")

        return sdate

def isInt(x):
    try:
        float(x)
        return True
    except ValueError:
        return False


def compare(x1, y1):
    x = x1.split('-')
    y = y1.split('-')

    if len(x) == 1:
        x = x1.split()
        y = y1.split()
    
    if int(x[0]) == int(y[0]): 
        if isInt(x[1][1]) and isInt(y[1][1]):
            if int(x[1][1]) < int(y[1][1]):
                return -1
            else:
                return 1
        else:
            if isInt(x[1][1]):
                return 1
            else: 
                return -1

    if int(x[0]) > int(y[0]):
        return 1
    return -1

    
def getBands():
    temp = ['1800 C1 Band']
    return temp

def getPos(dates):
    pos = {}
    for i in range(len(dates)):
        pos[dates[i]] = i
    return pos

def compare_var(s1, s2):
    if len(s1) > len(s2):
        return -1
    else:
        return 1

# class Logger:
#     l = []
#     Integer = 100
    
#     def __init__(self, mode):
#         if mode == 1:
#             self.f = open("logger.txt", 'a')
#         else:
#             self.f = open("logger.txt", 'w')


#     def namestr(self, obj, namespace):
#         return [name for name in namespace if namespace[name] is obj]
    
#     def log(self, data, variableName, lineBreak):
#         if type(data) == list:
#             self.f.write(variableName + " : [")
#             for item in data:
#                 self.f.write(str(item))
#                 self.f.write(",")
#             self.f.write("]\n")

#         elif lineBreak == 1:
#             self.f.write('######################################################################')
#             self.f.write('\n')
#         else:
#             self.f.write(variableName + " : ")
#             self.f.write(str(data))
#             self.f.write('\n')
#     def closeLog(self):
#         self.f.close()

def getKeys(hour): 
    fixTime = ['15', '30', '45', '00']
    l = []
    for i in range(len(fixTime)):
        if i == len(fixTime) - 1:
            val = str(int(hour) + 1) + ":" + fixTime[i] + ":" + fixTime[-1]
            l.append(val)
        else:
            val = str(hour) + ":" + fixTime[i] + ":" + fixTime[-1]
            l.append(val)
    return l

def myFunc(e):
      return e[2]



class Graph:
    
    def __init__(self,mapping,_band):
        self.dates = getDates()
        self.pos = getPos(self.dates)
        path=os.getcwd()
        self.folder=path+"\\"+"USM KPI Preparation\\input"
        self.files = os.listdir(self.folder)
        self.mapping=mapping
        self.bands =_band
        self.expected_length = 0
        self.end_col = 0
        self.end_row = 0
        #position for graph
        self.GraphRow=2
        self.pcol = 1
        self.GraphCol=3
        self.f = 0
        self.wrow = 2
        self.formulaKpi = formula_kpi()
        self.kpitoDisplay=final_kpi()
        


    def AddDataToMap(self,_sitelist,category):
        my_data={}
        for filename in self.files:
            if filename == 'raw_input.csv':
                continue
            file = open(self.folder + "\\" + filename) 
            raw_data = file.read().split('\n')
            raw_data.pop()
            kpilist = getKPIs(raw_data[3].split(','))
            if raw_data[0] !="#family:Active E-RAB Number":
                for data in raw_data[4:]:
                    data_list = data.split(',')

                    if len(data_list[2])!=0:
                        site_value=data_list[2]

                    if category not in my_data:
                        my_data[category] = {}

                    for i in range(len(data_list[7:])):
                        if kpilist[i] not in my_data[category]:
                            my_data[category][kpilist[i]] = {}

                        currentDate = ""
                        currentTime = ""
                        if len(data_list[3])!=0:
                            currentDate = data_list[3].split()[0]
                            currentTime = data_list[3].split()[1]

                        for band in self.bands:
                            if band not in my_data[category][kpilist[i]]:
                                my_data[category][kpilist[i]][band] = {}

                            if currentDate not in my_data[category][kpilist[i]][band]:
                                my_data[category][kpilist[i]][band][currentDate] = {}
                            
                            
                            if  currentTime not in my_data[category][kpilist[i]][band][currentDate]:
                                my_data[category][kpilist[i]][band][currentDate][currentTime] = 0
                            
                                            
                            if site_value in self.mapping[category]: # site -> [] 
                                my_data[category][kpilist[i]][band][currentDate][currentTime] += getValue(data_list[i+7])

            else:
                for data in raw_data[4:]:
                    data_list = data.split(',')

                    if len(data_list[2])!=0:
                        site_value=data_list[2]

                    if category not in my_data:
                        my_data[category] = {}

                    if len(data_list[6])!=0:
                        cellnum=data_list[6].split("/")[1]
                        if cellnum=="QCI1":
                            for i in range(len(data_list[7:])):
                                if kpilist[i] not in my_data[category]:
                                    my_data[category][kpilist[i]] = {}

                                currentDate = ""
                                currentTime = ""
                                if len(data_list[3])!=0:
                                    currentDate = data_list[3].split()[0]
                                    currentTime = data_list[3].split()[1]

                                for band in self.bands:
                                    if band not in my_data[category][kpilist[i]]:
                                        my_data[category][kpilist[i]][band] = {}

                                    if currentDate not in my_data[category][kpilist[i]][band]:
                                        my_data[category][kpilist[i]][band][currentDate] = {}
                                    
                                    
                                    if  currentTime not in my_data[category][kpilist[i]][band][currentDate]:
                                        my_data[category][kpilist[i]][band][currentDate][currentTime] = 0
                                    
                                                    
                                    if site_value in self.mapping[category]: # site -> [] 
                                        my_data[category][kpilist[i]][band][currentDate][currentTime] += getValue(data_list[i+7])

                    
        #print(my_data)
        self.myData=my_data

    
    def calVariablesValue(self,category, kpi, band, date, hour):
        data = {}
        try:
            data = self.myData[category][kpi][band][date]
        except:
            return 0
        val = 0.0
        for hour in data:
            val += float(data[hour])    
        return val 

    def formulaEvaluation(self, category, band, currentDate, hour,worksheet):
        for items in self.formulaKpi: # kpi which suppose to be calcualte using formula ( map )
            if items in self.kpitoDisplay: # kpi to be displayed ( checking )
                res = 0
                kpi_formula = self.formulaKpi[items]  # getting formula for given kpi
                varList = getVariables(kpi_formula)
                var = list(set(varList)) # remove duplicate variables
                ans = []
                for idx in range(len(var)):
                    if isInt(var[idx]):
                        ans.append(float(var[idx]))
                        continue
                    new_string = 'ans[' + str(idx) + ']'
                    kpi_formula = kpi_formula.replace(var[idx], new_string)
                    tmpRes = self.calVariablesValue(category, var[idx], band, currentDate, hour)
                    ans.append(tmpRes)
                # we formual and answer list
                # calculate values
                res = 0
                try:
                    res = eval(kpi_formula[1:])
                except:
                    pass
                worksheet.write(self.wrow, self.col, res)
                self.col += 1

        
        


    def WriteToExcelSheet(self,category,workbook, worksheet, worksheet1,heading): 
        date_format= workbook.add_format({'num_format': 'dd/mm/yy'})
        color=workbook.add_format({'fg_color':'#C6DCE4'})
        color_format=workbook.add_format({'bold':True,'fg_color':'#C6DCE4','align':'center',
                                   'valign':'vcenter'})
        dailyRow=0
        dailyCol=3


        #Writing Header in th sheeet
        if self.f == 0:
            worksheet.write(dailyRow+1, dailyCol-1, "Date")
            worksheet.write(dailyRow+1, dailyCol-2, "Empty")
            worksheet.write(dailyRow+1, dailyCol-3, "Remarks2")

        if self.f == 0:
            for kpiWrite in self.formulaKpi:
                if kpiWrite in self.kpitoDisplay:
                    worksheet.write(dailyRow, dailyCol, kpiWrite,color)
                    for band in self.bands:
                        worksheet.write(dailyRow+1,dailyCol,band) 
                        dailyCol+=1

        
        
        #calculation of DailyWise,HourlyWise,QuartelyWise
        # self.wrow = 2
        dates=[]
        self.col=3
        # site wala loop
        #print(self.myData)
        for Category in self.myData:
            key = ""
            for kpi in self.myData[Category]:
                key = kpi
                break
            for band in self.myData[Category][key]:
                for currentDate in self.myData[Category][key][band]:
                    dates.append(currentDate)
                    worksheet.write(self.wrow,self.col-2,"(blank)")
                    worksheet.write(self.wrow,self.col-3,category)
                    worksheet.write(self.wrow, self.col-1, to_date(currentDate),date_format)
                    self.formulaEvaluation(category, band, currentDate, 5, worksheet)   
                    self.wrow += 1
                    self.col = 3  

    
        self.GraphCol=3
        prow = 3
        worksheet1.merge_range(0, self.pcol, 0, self.pcol + 7, heading + "(" + category+ ")- ",color_format)
        #code for graph 
        for kpis in self.formulaKpi:
            if kpis in self.kpitoDisplay:
                if self.f == 0:
                    worksheet1.write(prow, 0, kpis)
                chart = workbook.add_chart({'type': 'line'})       
                worksheet1.insert_chart(prow, self.pcol, chart)
                
                chart.set_title({'name': to_string(kpis)})
                chart.set_legend({'position': 'bottom'})
                chart.set_x_axis({'date_axis': True})
                chart.set_x_axis({'minor_unit': 1, 'major_unit':1})

                last = 2 + len(dates)
                for band in self.bands:
                    # print("row",self.GraphRow)
                    # print("col",self.GraphCol)
                    chart.add_series({'name' : band,'categories': '=KPI_Day!$C$3:$C$' + str(last) ,'values' : ['KPI_Day',self.GraphRow, self.GraphCol, self.GraphRow + len(dates)-1, self.GraphCol]})
                    self.GraphCol += 1
                    
                prow += 17
        self.pcol += 8
        self.GraphRow +=len(dates)
        self.f = 1

    def generate(self,workbook,heading,_sitelist):
        #workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\outputfile.xlsx',{'strings_to_numbers':True})
        worksheet = workbook.add_worksheet('KPI_Day')   
        worksheet1 = workbook.add_worksheet('Graph_Day')
        keylist=[]
        for key in self.mapping:
            keylist.append(key)
        keylist.sort(key=myFunc,reverse=True)
        for keys in keylist:
            self.AddDataToMap(_sitelist,keys)
            self.WriteToExcelSheet(keys,workbook,worksheet, worksheet1,heading) # keys = category


       

        #workbook.close()
        #logger.closeLog()

        
                    
                        
if __name__=="__main__":
    p1=Process(target=Graph)
    p1.start()
    p1.join()


# pre, post,dateToRemark,remarkNameList,valuelist,bandvaluelist,band,sitelist,mapcategory=write_map()                 
# graph = Graph(mapcategory,band)
# graph.generate("data",sitelist)


















        






