import os
from tkinter import *
import tkinter as tk
from tkinter import ttk
from kpiQuaterGraph import Graph
from quatterSummary import Summary
from quaterrawinput import write_map
from tkinter import Tk, Button, StringVar, OptionMenu
import xlsxwriter
from datetime import datetime
import time


 

# Get output name from file
def getOutputName(s):
    s_list = s.split('.')
    return s_list[0]+"Output"


def _submit(name):
    path=os.getcwd()
    folder=path+"\\"+"USM KPI Preparation\\input"
    files = os.listdir(folder)
    path=os.getcwd()
    outfolder=path+"\\"+"USM KPI Preparation\\output"
    for file in files:
        if file=="raw_input.csv":
            continue

    _output = outfolder + '\\' + "KPI_Report.xlsx"
    workbook = xlsxwriter.Workbook(_output,{'strings_to_numbers':True})
    pre, post,dateToRemark,remarkNameList,valuelist,bandvaluelist,band,PreCount, PostCount,DateRemarkHour= write_map() 
    graph = Graph(dateToRemark,remarkNameList,band,PreCount,PostCount,DateRemarkHour)
    graph.generate(workbook,name.get())
    summary = Summary(workbook,pre,post,valuelist,bandvaluelist,name.get(),band) #pass open_output_file
    summary.call_category(dateToRemark)
    print("output has been generated!!!")
    workbook.close()

    

#Function for clearing widgets
def clear_widgets(name):
    name.delete(0,END)
    
    
#Function for clearing widgets
def clear_text(name):
    name.delete(0,END)


def quaterwiseInterface():
    root = Tk()   
    root.geometry("800x500")
    root.configure(bg='black')
    open_output_file = ''
    open_input_file = ''
    date_list = None
    short_name=None
        
    #Title for tool
    title = Label(root, text = "4G & 5G KPI Tool Dashboard",font=('Calisto MT',15),background='black',foreground='Red').place(x = 300, y = 6) 

    lbl = ttk.Label(root, text = "Enter the Header for Graph and Summary Table:",background='black',foreground='White').place(x = 150,y =40)

    name = tk.Entry(root, width=13)
    name.pack(pady=20)
    name.place(x=420,y=40) 
        
    b = Button(root,command=lambda: _submit(name),text = "Generate Report",bg='red',  fg = 'blue')    
    b.pack(ipadx=5, ipady=5,pady=5)
    b.place(x=200, y=90)

    clear = Button(root,command=clear_text(name),text = "Clear Widget",bg='red',  fg = 'blue')    
    clear.pack(ipadx=5, ipady=5,pady=5)
    clear.place(x=320, y=90)


    d = Button(root,command=clear_widgets(name),text = "Clear",bg='red',  fg = 'blue')    
    d.pack(ipadx=5, ipady=5,pady=5)
    d.place(x=420, y=90)

    root.mainloop()