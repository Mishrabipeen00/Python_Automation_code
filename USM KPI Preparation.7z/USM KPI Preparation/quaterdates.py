import os
import pandas as pd
from datetime import datetime
from functools import cmp_to_key
year = {
    "Jan" : 0,
    "Feb" : 1,
    "Mar" : 2,
    "Apr" : 3,
    "May" : 4,
    "Jun" : 5, 
    "Jul" : 6,
    "Aug" : 7,
    "Sep" : 8,
    "Oct" : 9,
    "Nov" : 10, 
    "Dec" : 11
}

def compare(d1, d2):
    d1_list = d1.split()
    d2_list = d2.split()
    

    

    if int(d1_list[2]) < int(d2_list[2]):
        return -1
    elif int(d1_list[2]) == int(d2_list[2]):
        if year[d1_list[1]] < year[d2_list[1]]:
            return -1
        elif year[d1_list[1]] == year[d2_list[1]]:
            if int(d1_list[0]) < int(d2_list[0]):
                return -1
            elif int(d1_list[0]) == int(d2_list[0]):
                return 0
            else:
                return 1
        else:
            return 1
    else:
        return 1
    

def comparator(item1,item2):
    d1_list = item1.split()
    d2_list = item2.split()
    if int(d1_list[2]) < int(d2_list[2]):
        return -1
    elif int(d1_list[2]) > int(d2_list[2]):
        return 1
    return 0

def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s


def reformat(d):
    d_list = d.split('-')
    date = None
    if len(d_list) > 1:
        date = datetime.strptime(to_string(d), '%Y-%m-%d')
    else:
        date = datetime.strptime(to_string(d), '%Y %m %d')
    return  date.strftime("%d %b %y")


def getKeys(hour): 
    fixTime = ['15', '30', '45', '00']
    l = []
    if hour <= 9:
        hour = '0' + str(hour)
    for i in range(len(fixTime)):
        if i == len(fixTime) - 1:
            val = str(int(hour) + 1) + ":" + fixTime[i] + ":" + fixTime[-1]
            l.append(val)
        else:
            val = str(hour) + ":" + fixTime[i] + ":" + fixTime[-1]
            l.append(val)
    
    return l


def getDates(): 
    path=os.getcwd()
    folder=path+"\\"+"USM KPI Preparation\\input"
    files = os.listdir(folder)
    demo=set()
    
    MPDateWithTime = {}
    for file in files:
        if file == 'raw_input.csv':
            continue
        _input = folder + '\\' + file
        f=open(_input)
        data=f.read().split('\n')
        for d in data[4:]:
            data_list = d.split(',')
            if len(data_list[0]) == 0:
                break
            if len(data_list[3]) != 0:
                date= to_string(data_list[3])
                newdate=date.split()[0]
                DateOnly = to_string(data_list[3]).split()[0]
                time=date.split()[1]
                line_list = newdate.split('-')
                if DateOnly not in MPDateWithTime:
                    MPDateWithTime[DateOnly] = set()
                MPDateWithTime[DateOnly].add(time[:5])
                if len(line_list) > 1:
                    new_line = ' '.join(tuple(newdate.split('-')))
                    demo.add(reformat(new_line))
                
                if len(line_list) <= 1:
                    demo.add(reformat(newdate))
    dates = list(demo)
    dates.sort(key=cmp_to_key(compare))
    newdates=[]
    for DateOnly in MPDateWithTime: # WithHour
        for Hour in MPDateWithTime[DateOnly]:
            StrDateWithHour = DateOnly + ';' + Hour 
            newdates.append(StrDateWithHour)

    newdates.sort()
    return newdates























    
    
        
        
        
