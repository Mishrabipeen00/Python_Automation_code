import xlsxwriter
import os
from datetime import datetime
from functools import cmp_to_key
from quaterdates import getDates
from formulaMap import formula_kpi
from finalKpi import final_kpi
from quaterrawinput import non_kpis_formula
from timeFun import getTimes
from formulaCleanvariable import getVariables
from getTime import getTimeMinute
from quaterrawinput import write_map,writetoFile


# function to remove remove quotes
def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s

def remove_single_quoute(s):
    if len(s) == 0:
        return s
    if s[0] == "'":
        return s[1:-1]
    else:
        return s

def getValue(n):
    if n == '':
        return float(0)
    return float(n)

def replacePercent(d):
    d=d.replace('%',"")
    return d

def getKPIs(data):
    for i in range(7):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data


def to_date(s):
    s_list = s.split('-')
    if len(s_list) > 1:
        date = datetime.strptime(to_string(s), '%Y-%m-%d')
        return date
    else:
        date = datetime.strptime(to_string(s), '%Y %m %d')
        return date

def getDate(d):
    d_list=d.split('-')
    if len(d_list)>1:
        dd = datetime.strptime(to_string(d),"%Y-%m-%d")
        sdate=dd.strftime("%d %b %y")
        return sdate
    else:
        dd = datetime.strptime(to_string(d),"%Y %m %d")
        sdate = dd.strftime("%d %b %y")

        return sdate

def isInt(x):
    try:
        float(x)
        return True
    except ValueError:
        return False


def compare(x1, y1):
    x = x1.split('-')
    y = y1.split('-')

    if len(x) == 1:
        x = x1.split()
        y = y1.split()
    
    if int(x[0]) == int(y[0]): 
        if isInt(x[1][1]) and isInt(y[1][1]):
            if int(x[1][1]) < int(y[1][1]):
                return -1
            else:
                return 1
        else:
            if isInt(x[1][1]):
                return 1
            else: 
                return -1

    if int(x[0]) > int(y[0]):
        return 1
    return -1

    
def getBands():
    temp = ['1800 C1 Band']
    return temp

def getTime(i):
    m = {
        0:'00:00',
        1:'01:00', 
        2:'02:00', 
        3:'03:00', 
        4:'04:00', 
        5:'05:00', 
        6:'06:00', 
        7:'07:00', 
        8:'08:00', 
        9:'09:00', 
        10:'10:00',
        11:'11:00',
        12:'12:00',
        13:'13:00',
        14:'14:00',
        15:'15:00',
        16:'16:00',
        17:'17:00',
        18:'18:00',
        19:'19:00',
        20:'20:00',
        21:'21:00',
        22:'22:00',
        23:'23:00'
    }

    return m[i]


def getPos(dates):
    pos = {}
    for i in range(len(dates)):
        pos[dates[i]] = i
    return pos

def compare_var(s1, s2):
    if len(s1) > len(s2):
        return -1
    else:
        return 1

class Logger:
    l = []
    Integer = 100
    
    def __init__(self, mode):
        if mode == 1:
            self.f = open("logger.txt", 'a')
        else:
            self.f = open("logger.txt", 'w')


    def namestr(self, obj, namespace):
        return [name for name in namespace if namespace[name] is obj]
    
    def log(self, data, lineBreak):
        if type(data) == list:
            for item in data:
                self.f.write(str(item))
                self.f.write('\n')
        elif lineBreak == 1:
            self.f.write('######################################################')
            self.f.write('\n')
        else:
            self.f.write(str(data))
            self.f.write('\n')
    def closeLog(self):
        self.f.close()

def getKeys(hour): 
    fixTime = ['15', '30', '45', '00']
    l = []
    if hour <= 9:
        hour = '0' + str(hour)
    for i in range(len(fixTime)):
        if i == len(fixTime) - 1:
            val = str(int(hour) + 1) + ":" + fixTime[i]
            l.append(val)
        else:
            val = str(hour) + ":" + fixTime[i]
            l.append(val)
    return l

 

class Graph:
    
    def __init__(self,_dateToRemark,_remarkNameList,_band,PreCount, PostCount,DateRemarkHour):
        self.dates = getDates()
        self.pos = getPos(self.dates)
        path=os.getcwd()
        self.folder=path+"\\"+"USM KPI Preparation\\input"
        self.files = os.listdir(self.folder)
        self.bands = _band
        self.expected_length = 0
        self.dateToRemark = _dateToRemark
        self.remarkNameList = _remarkNameList
        self.end_col = 0
        self.end_row = 0
        #position for graph
        self.pcol = 1
        self.row = 2
        self.f = 0
        self.wrow = 2
        self.formulaKpi = formula_kpi()
        self.kpitoDisplay=final_kpi()
        self.PreCount = PreCount
        self.PostCount = PostCount
        self.PreCol = 3
        self.PostCol = 3 + PreCount
        self.DateRemarkHour = DateRemarkHour
        #print("intiazl vlals",self.PostCol)


    def AddDataToMap(self):
        my_data = {}
        for filename in self.files:
            if filename == 'raw_input.csv':
                continue
            file = open(self.folder + "\\" + filename) 
            raw_data = file.read().split('\n')
            raw_data.pop()
            kpilist = getKPIs(raw_data[3].split(','))
            if raw_data[0] !="#family:Active E-RAB Number":
                for data in raw_data[4:]:
                    data_list = data.split(',')
                    
                    for i in range(len(data_list[7:])):
                        if kpilist[i] not in my_data:
                            my_data[kpilist[i]] = {}

                        currentDate = ""
                        currentTime = ""
                        if len(data_list[3])!=0:
                            currentDate = data_list[3].split()[0]
                            currentTime = data_list[3].split()[1]
                            
                        
                        currentDateInStr = currentDate
                        
                        if currentDateInStr not in my_data[kpilist[i]]:
                            my_data[kpilist[i]][currentDateInStr] = {}
                        

                        if  currentTime[:5] not in my_data[kpilist[i]][currentDateInStr]:
                            my_data[kpilist[i]][currentDateInStr][currentTime[:5]] = [0, 0]

                        if currentDateInStr in self.dateToRemark.keys(): # for pre
                            if currentTime[:5] in self.dateToRemark[currentDateInStr]:
                                if self.dateToRemark[currentDateInStr][currentTime[:5]][:3] == 'pre': # only check first 3 char
                                    # count[kpilist[i]][band][currentDateInStr][currentTime][0]+=1
                                    my_data[kpilist[i]][currentDateInStr][currentTime[:5]][0] += getValue(data_list[i+7])
                                else:
                                    # count[kpilist[i]][band][currentDateInStr][currentTime][1]+=1
                                    my_data[kpilist[i]][currentDateInStr][currentTime[:5]][1] += getValue(data_list[i+7])
            else:
                for data in raw_data[4:]:
                    data_list = data.split(',')
                    if len(data_list[6])!=0:
                        cellnum=data_list[6].split("/")[1]
                        if cellnum=="QCI1":
                            for i in range(len(data_list[7:])):
                                if kpilist[i] not in my_data:
                                    my_data[kpilist[i]] = {}

                                currentDate = ""
                                currentTime = ""
                                if len(data_list[3])!=0:
                                    currentDate = data_list[3].split()[0]
                                    currentTime = data_list[3].split()[1]
                                    
                                
                                currentDateInStr = currentDate
                                
                                if currentDateInStr not in my_data[kpilist[i]]:
                                    my_data[kpilist[i]][currentDateInStr] = {}
                                

                                if  currentTime[:5] not in my_data[kpilist[i]][currentDateInStr]:
                                    my_data[kpilist[i]][currentDateInStr][currentTime[:5]] = [0, 0]

                                if currentDateInStr in self.dateToRemark.keys(): # for pre
                                    if currentTime[:5] in self.dateToRemark[currentDateInStr]:
                                        if self.dateToRemark[currentDateInStr][currentTime[:5]][:3] == 'pre': # only check first 3 char
                                            # count[kpilist[i]][band][currentDateInStr][currentTime][0]+=1
                                            my_data[kpilist[i]][currentDateInStr][currentTime[:5]][0] += getValue(data_list[i+7])
                                        else:
                                            # count[kpilist[i]][band][currentDateInStr][currentTime][1]+=1
                                            my_data[kpilist[i]][currentDateInStr][currentTime[:5]][1] += getValue(data_list[i+7])


                    

        #print(my_data)
        self.myData = my_data
        return my_data
    
    

    def formulaEvaluation(self,currentDate,time,worksheet,isMinutePresent):
        self.WPreCol = self.PreCol
        self.WPostCol = self.PostCol
        for items in self.formulaKpi: # kpi which suppose to be calcualte using formula ( map )
            if items in self.kpitoDisplay: # kpi to be displayed ( checking )
                preKpiFormula = self.formulaKpi[items]  # getting formula for given kpi
                postKpiFormula = self.formulaKpi[items]
                varList = getVariables(preKpiFormula)
                var = list(set(varList)) # remove duplicate variables
                preAns = []
                for idx in range(len(var)):
                    if isInt(var[idx]):
                        preAns.append(float(var[idx]))
                        continue
                    preTmpText = 'preAns[' + str(idx) + ']'
                    preKpiFormula = preKpiFormula.replace(var[idx], preTmpText)
                    preTmpResult = 0
                    try : 
                        preTmpResult = self.myData[var[idx]][currentDate][time][0]
                    except:
                        pass
                    preAns.append(preTmpResult)
            
                
                # we formual and answer list
                # calculate value
                preResult = 0
                try:
                    preResult = eval(preKpiFormula[1:])   
                except:
                    pass
                hasPre = 0
                for _hour in self.dateToRemark[currentDate]:
                    if self.dateToRemark[currentDate][_hour][:3] == 'pre':
                        hasPre = 1
                        break
                if isMinutePresent == 0:
                    preResult = 0
                if hasPre:
                    worksheet.write(self.wrow, self.WPreCol, preResult)
                    
                varList = getVariables(postKpiFormula)
                var = list(set(varList)) # remove duplicate variables
                postAns = []
                for idx in range(len(var)):
                    if isInt(var[idx]):
                        postAns.append(float(var[idx]))
                        continue
                    postTmpText = 'postAns[' + str(idx) + ']'
                    postKpiFormula = postKpiFormula.replace(var[idx], postTmpText)
                    postTmpResult = 0
                    try : 
                        postTmpResult = self.myData[var[idx]][currentDate][time][1]
                    except:
                        pass
                    postAns.append(postTmpResult)
    
                # we formual and answer list
                # calculate value
                postResult = 0
                try:
                    postResult = eval(postKpiFormula[1:])
                except:
                    pass
                hasPost = 0
                for _hour in self.dateToRemark[currentDate]:
                    if self.dateToRemark[currentDate][_hour][:3] == 'pos':
                        hasPost = 1
                        break
                if isMinutePresent == 0:
                    postResult = 0
                if hasPost:
                    worksheet.write(self.wrow, self.WPostCol, postResult)
                self.WPreCol += (self.PreCount  + self.PostCount) 
                self.WPostCol += (self.PreCount  + self.PostCount) 
                
                
                


    def WriteToExcelSheet(self,workbook,worksheet,worksheet1,heading):
        # workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\outputfile.xlsx',{'strings_to_numbers':True})
        # worksheet = workbook.add_worksheet('KPI_Day')
        # worksheet1 = workbook.add_worksheet('Graph_Day') 
        date_format= workbook.add_format({'num_format': 'dd/mm/yy'})
        color=workbook.add_format({'fg_color':'#C6DCE4'})
        color_format=workbook.add_format({'bold':True,'fg_color':'#C6DCE4','align':'center',
                                   'valign':'vcenter'})
        dailyRow=0
        dailyCol=3

        #Writing Header in th sheeet
        worksheet.write(dailyRow+1, dailyCol-1, "Date")
        worksheet.write(dailyRow+1, dailyCol-2, "Empty")
        worksheet.write(dailyRow+1, dailyCol-3, "Remarks2") 

        dateRow=2
        dateCol=3

        for hour in range(24):
            keys = getKeys(hour)
            for hourkey in keys:
                worksheet.write(dateRow, dateCol - 1,hourkey)
                worksheet.write(dateRow,dateCol-2,"(blank)")
                worksheet.write(dateRow,dateCol-3,"Overall")
                dateRow+=1
    
        #Writing kpi and band in the sheet
        for kpiWrite in self.formulaKpi:
            if kpiWrite in self.kpitoDisplay:
                if len(self.remarkNameList) > 1:
                    worksheet.merge_range(dailyRow, dailyCol, dailyRow, dailyCol+len(self.remarkNameList) - 1, kpiWrite,color)
                else:
                    worksheet.write(dailyRow,dailyCol,kpiWrite, color)
                for remark in self.remarkNameList:
                    worksheet.write(1, dailyCol, remark)
                    dailyCol += 1
        
        #calculation of DailyWise,HourlyWise,QuartelyWise
        logger = Logger(0)
        self.wrow = 2
        self.col=3
        key = ""
        for kpi in self.myData:
            key = kpi
            break
        for CurrentDate in self.DateRemarkHour:
            for Remark in self.DateRemarkHour[CurrentDate]:
                self.wrow = 2
                for hour in range(24):
                    keys = getKeys(hour)
                    for hourkey in keys:
                        isMinutePresent = 0
                        if hourkey in self.DateRemarkHour[CurrentDate][Remark]:
                            isMinutePresent = 1
                        self.formulaEvaluation(CurrentDate, hourkey, worksheet,isMinutePresent)  
                        self.wrow += 1

                if Remark[:3] == 'pos':
                    self.PostCol += 1
                else:
                    self.PreCol += 1

            


        prow = 3
        self.pcol = 1
        self.row = 2
        self.wrow = 2
        worksheet1.merge_range(0, self.pcol+3, 0, self.pcol + 9, heading ,color_format)
        Col = 3
        self.pcol=1
        #code for graph 
        for kpis in self.formulaKpi:
            if kpis in self.kpitoDisplay:
                worksheet1.write(prow, 0, kpis)
                chart = workbook.add_chart({'type': 'line'})       
                worksheet1.insert_chart(prow, self.pcol, chart,{'x_scale':2,'y_scale':1})
                    
                chart.set_title({'name': to_string(kpis)})
                chart.set_legend({'position': 'bottom'})
                chart.set_x_axis({'date_axis': True})
                chart.set_x_axis({'minor_unit': 1, 'major_unit':1})
                self.wrow = 2
                for remark in self.remarkNameList:
                    chart.add_series({'name' : remark,'categories': '=KPI_Day!$C$3:$C$98' ,'values' : ['KPI_Day',self.row, Col, self.row + 96-1, Col]})
                    Col += 1
                prow += 17

        self.pcol += 8
        self.row += 96
        
        
        
    def generate(self,workbook,heading):
        #workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\outputfile.xlsx',{'strings_to_numbers':True})
        worksheet = workbook.add_worksheet('KPI_Day')   
        worksheet1 = workbook.add_worksheet('Graph_Day')
        self.AddDataToMap()
        self.WriteToExcelSheet(workbook,worksheet,worksheet1,heading)


       

        #workbook.close()
        # logger.closeLog()

        
                    
                        
     
# pre, post,dateToRemark,remarkNameList,valuelist,bandvaluelist,band,PreCount, PostCount,DateRemarkHour= write_map()   
# graph = Graph(dateToRemark,remarkNameList,band,PreCount,PostCount,DateRemarkHour)
# myData = graph.AddDataToMap()
# graph.generate("data")



















        






