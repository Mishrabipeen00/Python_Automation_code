import xlsxwriter
import os
from datetime import datetime
from functools import cmp_to_key
from dateFun import getDates
from formulaMap import formula_kpi
from finalKpi import final_kpi
from rawInput import non_kpis_formula,write_map
from timeFun import getTimes
from formulaCleanvariable import getVariables
import multiprocessing
from multiprocessing import Process, current_process

def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        s = s[1:]
    if s[-1:] == '"':
        s = s[0:-1]
    return s

def compare_var(s1, s2):
    if len(s1) > len(s2):
        return -1
    else:
        return 1

def remove_single_quoute(s):
    if len(s) == 0:
        return s
    if s[0] == "'":
        return s[1:-1]
    else:
        return s

def getValue(n):
    if n == '':
        return float(0)
    return float(n)

def replacePercent(d):
    d=d.replace('%',"")
    return d

def getKPIs(data):
    for i in range(7):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data


def to_date(s):
    s_list = s.split('-')
    if len(s_list) > 1:
        date = datetime.strptime(to_string(s), '%Y-%m-%d')
        return date
    else:
        date = datetime.strptime(to_string(s), '%Y %m %d')
        return date

def getDate(d):
    d_list=d.split('-')
    if len(d_list)>1:
        dd = datetime.strptime(to_string(d),"%Y-%m-%d")
        sdate=dd.strftime("%d %b %y")
        return sdate
    else:
        dd = datetime.strptime(to_string(d),"%Y %m %d")
        sdate = dd.strftime("%d %b %y")

        return sdate


def date_in_range(user_date, r, current_date):
        
    d1 = to_date(user_date)
    d2 = to_date(current_date)

    d  =  str(d2 - d1).split()
    
    if len(d) == 1:
        return True
    if int(d[0]) < r and int(d[0]) >= 0:
        return True
    else:
        return False

def date_in_list(l, scurr_date):
    current_date = to_date(scurr_date)
    for sdate in l:
        date = to_date(sdate)
        if date == current_date:
            return True
    return False

def isInt(x):
    try:
        float(x)
        return True
    except ValueError:
        return False


def compare(x1, y1):
    x = x1.split('-')
    y = y1.split('-')

    if len(x) == 1:
        x = x1.split()
        y = y1.split()
    
    if int(x[0]) == int(y[0]): 
        if isInt(x[1][1]) and isInt(y[1][1]):
            if int(x[1][1]) < int(y[1][1]):
                return -1
            else:
                return 1
        else:
            if isInt(x[1][1]):
                return 1
            else: 
                return -1

    if int(x[0]) > int(y[0]):
        return 1
    return -1

    
def getBands():
    temp = ['1800 C1 Band']
    return temp


def get_delta(l):
    if len(str(l[0])) == 0 or len(str(l[1])) == 0 or float(l[0]) == 0:
        return 0.0
    
    ans = (float(l[1])-float(l[0]))*100/float(l[0])
    return ans

def make_range(row_no, inc):
    l = str(row_no)
    r = str(row_no + inc)
    s =  "A" + l + ":" + "D" + r
    return s


def isFloat(num):
    try:
        float(num)
        return True
    except ValueError:
        return False

def get_pre(pre_list, pos):
    res = "Pre"
    if pos > 0:
        res += "  " + str(pos) 
    # Pre 2
    res += "(" + pre_list[0] + " 00:00 to " + pre_list[-1] + " 23:00)"

    return res

def get_post(post_list, nos):
    rest = "Post"
    if nos > 0:
        rest += "  " + str(nos) 
    # Post 2
    rest += " (" + post_list[0] + " 00:00 to " + post_list[-1] + " 23:00)"

    return rest


def getnew_remark(v,f,criteria):
    value = float(v)
    if f=="POS":
        # print(f) 
        if value >= -criteria and value <= criteria:
            return "No changes"
        
        elif value < -criteria:
            return "Degarded"
        else:
            return "Improved" 
    elif f=="NEG":
        if value >= -criteria and value <= criteria:
            return "No changes"
            
        elif value < -criteria:
            return "Improved"
        else:
            return "Degarded" 
    else:
        if value >= -5 and value <= 5:
            return "No changes"
            
        elif value < -5:
            return "Improved"
        else:
            return "Degarded"

def getKeys(hour): 
    fixTime = ['15', '30', '45', '00']
    l = []
    for i in range(len(fixTime)):
        if i == len(fixTime) - 1:
            val = str(int(hour) + 1) + ":" + fixTime[i] + ":" + fixTime[-1]
            l.append(val)
        else:
            val = str(hour) + ":" + fixTime[i] + ":" + fixTime[-1]
            l.append(val)
    return l

class Summary:
    def __init__(self,workbook,_pre_list, _post_list,_valuelist,_bandvaluelist,heading,_bands):
        self.worksheet = workbook.add_worksheet("summary")
        self.bands = _bands
        self.format1=workbook.add_format({'bg_color':'yellow'})
        self.format2=workbook.add_format({'bg_color':'green'})
        self.format3=workbook.add_format({'bg_color':'#D61C4E'})
        self.color_format=workbook.add_format({'border':1,
                                  'align':'center',
                                   'valign':'vcenter',
                                   'fg_color':'#C6DCE4','text_wrap':'true'})
        self.color_forma=workbook.add_format({'border':1,
                                   'align':'center',
                                   'valign':'vcenter',
                                   'fg_color':'#C6DCE4',
                                   'bold':True,'text_wrap':'true'})

        self.color_form=workbook.add_format({'bg_color':'black'})
        self.color_for=workbook.add_format({'border':1,'align':'center',
                                   'valign':'vcenter'})
        self.color_bol=workbook.add_format({'bold':True,'fg_color':'#C6DCE4','align':'center',
                                   'valign':'vcenter'})
        self.pre_list = _pre_list
        self.post_list = _post_list
        self.value_list=_valuelist
        self.bandvalue=_bandvaluelist
        self.formulaKpi = formula_kpi()
        self.kpitoDisplay=final_kpi()
        self.row=3
        self.col=4
        self.finalResult = {}
        row = 4
        #writining kpi in sheet
        for kpi in self.formulaKpi:
            if kpi in self.kpitoDisplay:
                self.worksheet.merge_range(make_range(row, len(self.bands)), kpi,self.color_format)
                row += len(self.bands) + 1
        row = 3
        tcol = 4
        self.worksheet.merge_range(row-3,tcol + 1,row-3,tcol+4,heading,self.color_bol)
        self.worksheet.merge_range(row-2,tcol-4,row-1,tcol-1,"KPI",self.color_forma)
        self.worksheet.merge_range(row-2, tcol, row-1, tcol, "Band",self.color_forma)
        self.worksheet.merge_range(row-2, tcol + 3, row-1, tcol + 3,"Delta %",self.color_forma)
        self.worksheet.merge_range(row-2, tcol + 4, row-1, tcol + 4,"Remark",self.color_forma)
        for ip  in range(len(self.pre_list)):
            for jp in range(len(self.post_list)):
                if len(self.pre_list[ip]) == 0 or len(self.post_list[jp]) == 0:
                    continue
                self.worksheet.merge_range(row-2, tcol + 1,row-1, tcol + 1, get_pre(self.pre_list[ip], ip),self.color_forma)
                self.worksheet.merge_range(row-2, tcol + 2,row-1, tcol + 2, get_post(self.post_list[jp],jp),self.color_forma)
        
        self.worksheet.set_column(tcol,tcol,12)
        self.worksheet.set_column(tcol+1,tcol+1,12)
        self.worksheet.set_column(tcol+2,tcol+2,12)
        self.worksheet.set_column(tcol+3,tcol+3,12)
        self.worksheet.set_column(tcol+4,tcol+4,12)


        

    def comparison(self,_dateToRemark):
        self.dateToRemark = _dateToRemark
        m = {}
        path=os.getcwd()
        self.folder=path+"\\"+"USM KPI Preparation\\input"
        self.files = os.listdir(self.folder)
        for filename in self.files:
            if filename=="raw_input.csv":
                continue
            files = open(self.folder + "\\" + filename,'r')
            data = files.read().split('\n')
            kpilist = getKPIs(data[3].split(','))
            bands = self.bands
            files = open(self.folder + "\\" + filename) 
            if filename=="raw_input.csv":
                continue
            datas = files.read().split('\n')
            datas.pop()
            bands = self.bands
            kpilist = getKPIs(datas[3].split(','))
            if datas[0] !="#family:Active E-RAB Number":
                for data in datas[4:]:
                    data_list = data.split(',')
                
                    for i in range(len(data_list[7:])):
                        if kpilist[i] not in m:
                            m[kpilist[i]] = {}
                        
                        currentDate = ""
                        currentTime = ""
                        if len(data_list[3])!=0:
                            currentDate = data_list[3].split()[0]
                            currentTime = data_list[3].split()[1]

                        currentDateInStr = getDate(currentDate)
                        
                        for band in self.bands:
                            if band not in m[kpilist[i]]:
                                m[kpilist[i]][band] = {}
                        
                        if currentDateInStr not in m[kpilist[i]][band]:
                            m[kpilist[i]][band][currentDateInStr] = {}

                        
                        if  currentTime not in m[kpilist[i]][band][currentDateInStr]:
                            m[kpilist[i]][band][currentDateInStr][currentTime] = [0, 0]

                        if currentDateInStr in self.dateToRemark.keys(): # for pre
                            if self.dateToRemark[currentDateInStr][:3] == 'pre': # only check first 3 char
                                m[kpilist[i]][band][currentDateInStr][currentTime][0] += getValue(data_list[i+7])
                            else:
                                m[kpilist[i]][band][currentDateInStr][currentTime][1] += getValue(data_list[i+7])
            else:
                for data in datas[4:]:
                    data_list = data.split(',')
                    if len(data_list[6])!=0:
                        cellnum=data_list[6].split("/")[1]
                        if cellnum=="QCI1":
                            for i in range(len(data_list[7:])):
                                if kpilist[i] not in m:
                                    m[kpilist[i]] = {}
                                
                                currentDate = ""
                                currentTime = ""
                                if len(data_list[3])!=0:
                                    currentDate = data_list[3].split()[0]
                                    currentTime = data_list[3].split()[1]

                                currentDateInStr = getDate(currentDate)
                                
                                for band in self.bands:
                                    if band not in m[kpilist[i]]:
                                        m[kpilist[i]][band] = {}
                                
                                if currentDateInStr not in m[kpilist[i]][band]:
                                    m[kpilist[i]][band][currentDateInStr] = {}

                                
                                if  currentTime not in m[kpilist[i]][band][currentDateInStr]:
                                    m[kpilist[i]][band][currentDateInStr][currentTime] = [0, 0]

                                if currentDateInStr in self.dateToRemark.keys(): # for pre
                                    if self.dateToRemark[currentDateInStr][:3] == 'pre': # only check first 3 char
                                        m[kpilist[i]][band][currentDateInStr][currentTime][0] += getValue(data_list[i+7])
                                    else:
                                        m[kpilist[i]][band][currentDateInStr][currentTime][1] += getValue(data_list[i+7])

        self.myData=m
        return m

    def calVariablesValue(self,kpi, band, date,hour,isPost):
        data = {}
        try:
            data = self.myData[kpi][band][date]
        except:
            return 0
        val = 0.0
        for hour in data:
            if isPost:
                val += float(data[hour][1])
            else:
                val += float(data[hour][0])
        return val

     
    def formulaEvalwrite(self,band, currentDate, hour, isPost):
        #intilaize row, col
        self.row = 3
        self.col = 4
        if isPost:
            for items in self.formulaKpi: # kpi which suppose to be calcualte using formula ( map )
                if items in self.kpitoDisplay: # kpi to be displayed ( checking )
                    overall=[0,0,0,0]
                    l = [] 
                    res= [0,0]
                    resOverall = [0, 0]
                    kpiFormula = self.formulaKpi[items]  # getting formula for given kpi
                    varList = getVariables(kpiFormula)
                    var = list(set(varList)) # remove duplicate variables
                    
                    posAns = []
                    overPos = []

                    postkpiFormula = kpiFormula
                    overallpostkpiFormula=kpiFormula
                    

                    for idx in range(len(var)):
                        if isInt(var[idx]):
                            posAns.append(float(var[idx]))
                            overPos.append(float(var[idx]))
                            continue

                        postTmpText = 'posAns[' + str(idx) + ']'
                        overallposTmpText='overPos['+ str(idx) +']'

                        postkpiFormula=postkpiFormula.replace(var[idx],postTmpText)
                        overallpostkpiFormula=overallpostkpiFormula.replace(var[idx],overallposTmpText)

                        postTmpResult=self.calVariablesValue(var[idx],band, currentDate, hour,True)
                        overposTmpResult=self.calVariablesValue(var[idx],band,currentDate, hour,True)

                        posAns.append(postTmpResult)
                        overPos.append(overposTmpResult)

                    try:
                        res[1] = eval(postkpiFormula[1:])
                    except:
                        pass
        
                    if items not in self.finalResult:
                        self.finalResult[items] = [0, 0]
                    self.finalResult[items][1] = res[1]
                                
        else:
            for items in self.formulaKpi: # kpi which suppose to be calcualte using formula ( map )
                if items in self.kpitoDisplay: # kpi to be displayed ( checking )
                    overall=[0,0,0,0]
                    l = [] 
                    res= [0,0]
                    resOverall = [0, 0]
                    kpiFormula = self.formulaKpi[items]  # getting formula for given kpi
                    varList = getVariables(kpiFormula)
                    var = list(set(varList)) # remove duplicate variables
                    
                    preAns = []
                    overPre = []

                    prekpiFormula = kpiFormula
                    overallprekpiFormula=kpiFormula
                
                    for idx in range(len(var)):
                        if isInt(var[idx]):
                            preAns.append(float(var[idx]))
                            overPre.append(float(var[idx]))
                            continue

                        preTmpText = 'preAns[' + str(idx) + ']'
                        overallpreTmpText='overPre['+ str(idx) +']'
                        
                        prekpiFormula = prekpiFormula.replace(var[idx], preTmpText)
                        overallprekpiFormula=overallprekpiFormula.replace(var[idx],overallpreTmpText)
                    
                        preTmpResult=self.calVariablesValue(var[idx],band, currentDate, hour,False)
                        overpreTmpResult=self.calVariablesValue(var[idx],band, currentDate,hour,False)

                        preAns.append(preTmpResult)
                        overPre.append(overpreTmpResult)

                    try:
                        res[0] = eval(prekpiFormula[1:])
                    except:
                        pass
                    
                    if items not in self.finalResult:
                        self.finalResult[items] = [0, 0]
                    self.finalResult[items][0] = res[0]

        


    def call_dates(self,datetoRemark):
        self.comparison(datetoRemark)

        key = ""
        for kpi in self.myData:
            key = kpi
            break
        for band in self.myData[key]:
            for currentDate in self.myData[key][band]:
                if currentDate in datetoRemark.keys():
                    remark = datetoRemark[currentDate]
                    if remark[:3] == 'pre':
                        self.formulaEvalwrite(band, currentDate, "", 0)
                    elif remark[:3] == 'pos':
                        self.formulaEvalwrite(band, currentDate, "", 1)

        
        
    
        overall=[0,0,0,0]
        prepostCall=self.finalResult
        for kpi in prepostCall:
            l=[]
            l.append(prepostCall[kpi][0])
            l.append(prepostCall[kpi][1])
            delta=round(get_delta(l),2)
            type2 = self.kpitoDisplay[kpi][0] if kpi in self.kpitoDisplay else "nothing"
            self.worksheet.write(self.row, self.col, band,self.color_for)
            self.worksheet.write(self.row, self.col + 1,prepostCall[kpi][0],self.color_for)
            self.worksheet.write(self.row, self.col + 2, prepostCall[kpi][1],self.color_for)
            self.worksheet.write(self.row, self.col + 3, delta,self.color_for)
            self.worksheet.write(self.row, self.col + 4, getnew_remark(delta,type2,1),self.color_for)
            self.worksheet.conditional_format(self.row, self.col + 4, self.row, self.col + 4,{'type':'cell','criteria':'equal to','value':'"No changes"','format':self.format1})
            self.worksheet.conditional_format(self.row, self.col + 4, self.row, self.col + 4,{'type':'cell','criteria':'equal to','value':'"Improved"','format':self.format2})
            self.worksheet.conditional_format(self.row, self.col + 4, self.row, self.col + 4,{'type':'cell','criteria':'equal to','value':'"Degarded"','format':self.format3})
            if kpi in self.value_list:
                overall[0] += prepostCall[kpi][0]/(len(self.bands))
                overall[1] += prepostCall[kpi][1]/(len(self.bands))
                overall[2] += delta
            else:
                overall[0] = prepostCall[kpi][0]
                overall[1] = prepostCall[kpi][1]
                overall[2] += delta        
                self.row += 1

        
            self.worksheet.write(self.row, self.col, "overall",self.color_for)
            self.worksheet.write(self.row, self.col + 1, overall[0],self.color_for)
            self.worksheet.write(self.row, self.col + 2, overall[1],self.color_for)
            self.worksheet.write(self.row, self.col + 3,round(get_delta([overall[0], overall[1]]), 2),self.color_for )
            self.worksheet.write(self.row, self.col + 4,getnew_remark(round(get_delta([overall[0], overall[1]]), 2),type2,1),self.color_for)
            self.worksheet.conditional_format(self.row, self.col + 4, self.row, self.col + 4,{'type':'cell','criteria':'equal to','value':'"No changes"','format':self.format1})
            self.worksheet.conditional_format(self.row, self.col + 4, self.row, self.col + 4,{'type':'cell','criteria':'equal to','value':'"Improved"','format':self.format2})
            self.worksheet.conditional_format(self.row, self.col + 4, self.row, self.col + 4,{'type':'cell','criteria':'equal to','value':'"Degarded"','format':self.format3})
            self.row += 1
 
    
    def call_category(self,datatoRemark):
        self.call_dates(datatoRemark)

# workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Documents\\5G KPI Peparation\\output\\5Goutput.xlsx',{'strings_to_numbers':True})           
# pre, post,dateToRemark,remarkNameList,valuelist,bandvaluelist=write_map()
# summary=Summary(workbook,pre,post,valuelist,bandvaluelist,"data")
# summary.call_category(dateToRemark)

# workbook.close()

if __name__=="__main__":
    p1=Process(target=Summary)
    p1.start()
    p1.join()



                   