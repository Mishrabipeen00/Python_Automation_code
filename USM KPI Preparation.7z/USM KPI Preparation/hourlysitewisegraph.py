import xlsxwriter
import os
from datetime import datetime
from functools import cmp_to_key
from hourDate import getDates
from formulaMap import formula_kpi
from finalKpi import final_kpi
from hourlysiterawinput import non_kpis_formula
from timeFun import getTimes
from formulaCleanvariable import getVariables
from getTime import getTimeMinute
from hourlysiterawinput import write_map,writecsv

# function to remove remove quotes
def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s

def remove_single_quoute(s):
    if len(s) == 0:
        return s
    if s[0] == "'":
        return s[1:-1]
    else:
        return s

def getValue(n):
    if n == '':
        return float(0)
    return float(n)

def replacePercent(d):
    d=d.replace('%',"")
    return d

def getKPIs(data):
    for i in range(7):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data


def to_date(s):
    s_list = s.split('-')
    if len(s_list) > 1:
        date = datetime.strptime(to_string(s), '%Y-%m-%d')
        return date
    else:
        date = datetime.strptime(to_string(s), '%Y %m %d')
        return date

def getDate(d):
    d_list=d.split('-')
    if len(d_list)>1:
        dd = datetime.strptime(to_string(d),"%Y-%m-%d")
        sdate=dd.strftime("%d %b %y")
        return sdate
    else:
        dd = datetime.strptime(to_string(d),"%Y %m %d")
        sdate = dd.strftime("%d %b %y")

        return sdate

def isInt(x):
    try:
        float(x)
        return True
    except ValueError:
        return False


def compare(x1, y1):
    x = x1.split('-')
    y = y1.split('-')

    if len(x) == 1:
        x = x1.split()
        y = y1.split()
    
    if int(x[0]) == int(y[0]): 
        if isInt(x[1][1]) and isInt(y[1][1]):
            if int(x[1][1]) < int(y[1][1]):
                return -1
            else:
                return 1
        else:
            if isInt(x[1][1]):
                return 1
            else: 
                return -1

    if int(x[0]) > int(y[0]):
        return 1
    return -1

    
def getBands():
    temp = ['1800 C1 Band']
    return temp

def getTime(i):
    m = {
        0:'00:00',
        1:'01:00', 
        2:'02:00', 
        3:'03:00', 
        4:'04:00', 
        5:'05:00', 
        6:'06:00', 
        7:'07:00', 
        8:'08:00', 
        9:'09:00', 
        10:'10:00',
        11:'11:00',
        12:'12:00',
        13:'13:00',
        14:'14:00',
        15:'15:00',
        16:'16:00',
        17:'17:00',
        18:'18:00',
        19:'19:00',
        20:'20:00',
        21:'21:00',
        22:'22:00',
        23:'23:00'
    }

    return m[i]


def getPos(dates):
    pos = {}
    for i in range(len(dates)):
        pos[dates[i]] = i
    return pos

def compare_var(s1, s2):
    if len(s1) > len(s2):
        return -1
    else:
        return 1
    
def myFunc(e):
      return e[2]

# class Logger:
#     l = []
#     Integer = 100
    
#     def __init__(self, mode):
#         if mode == 1:
#             self.f = open("logger.txt", 'a')
#         else:
#             self.f = open("logger.txt", 'w')


    # def namestr(self, obj, namespace):
    #     return [name for name in namespace if namespace[name] is obj]
    
    # def log(self, data, lineBreak):
    #     if type(data) == list:
    #         for item in data:
    #             self.f.write(str(item))
    #             self.f.write('\n')
    #     elif lineBreak == 1:
    #         self.f.write('######################################################')
    #         self.f.write('\n')
    #     else:
    #         self.f.write(str(data))
    #         self.f.write('\n')
    # def closeLog(self):
    #     self.f.close()

def getKeys(hour): 
    fixTime = ['15', '30', '45', '00']
    l = []
    if hour <= 9:
        hour = '0' + str(hour)
    for i in range(len(fixTime)):
        if i == len(fixTime) - 1:
            val = str(int(hour) + 1) + ":" + fixTime[i] + ":" + fixTime[-1]
            l.append(val)
        else:
            val = str(hour) + ":" + fixTime[i] + ":" + fixTime[-1]
            l.append(val)
    
    return l

def getHour():
    l=[]
    for hour in range(0,24):
        if hour <= 9:
            hour = '0' + str(hour)
        l.append(str(hour))
    return l



class Graph:
    
    def __init__(self,_dateToRemark,_remarkNameList,_bands, _PreCount, _PostCount,DateRemarkHour,mapping):
        self.dates = getDates()
        self.pos = getPos(self.dates)
        path=os.getcwd()
        self.folder=path+"\\"+"USM KPI Preparation\\input"
        self.files = os.listdir(self.folder)
        self.bands = _bands
        self.mapping=mapping
        self.dateToRemark = _dateToRemark
        self.remarkNameList = _remarkNameList
        #position for graph
        self.GraphRow=2
        self.pcol = 1
        self.GraphCol=3
        self.f = 0
        self.wrow = 2
        self.formulaKpi = formula_kpi()
        self.kpitoDisplay=final_kpi()
        self.PreCount = _PreCount
        self.PostCount = _PostCount
        self.PreCol = 3
        self.PostCol = 3 + _PreCount
        self.DateRemarkHour = DateRemarkHour
        self.dateRow=2
        self.MainRow = 2
    


    def AddDataToMap(self,_sitelist,category):
        my_data = {}
        for filename in self.files:
            if filename == 'raw_input.csv':
                continue
            file = open(self.folder + "\\" + filename) 
            raw_data = file.read().split('\n')
            raw_data.pop()
            kpilist = getKPIs(raw_data[3].split(','))
            if raw_data[0] !="#family:Active E-RAB Number":
                for data in raw_data[4:]:
                    data_list = data.split(',')

                    if len(data_list[2])!=0:
                        site_value=data_list[2]
                        

                    if category not in my_data:
                        my_data[category] = {}
                    
                    for i in range(len(data_list[7:])):
                        if kpilist[i] not in my_data[category]:
                            my_data[category][kpilist[i]] = {}

                        currentDate = ""
                        currentTime = ""
                        if len(data_list[3])!=0:
                            currentDate = data_list[3].split()[0]
                            currentTime = data_list[3].split()[1]
                            
                        currentDateInStr = currentDate
                        
                        if currentDateInStr not in my_data[category][kpilist[i]]:
                            my_data[category][kpilist[i]][currentDateInStr] = {}
                        

                        if  currentTime[:2] not in my_data[category][kpilist[i]][currentDateInStr]:
                                my_data[category][kpilist[i]][currentDateInStr][currentTime[:2]] = [0, 0]

                        if site_value in self.mapping[category]:
                            if currentDateInStr in self.dateToRemark.keys(): # for pre
                                if currentTime[:2] in self.dateToRemark[currentDateInStr]:
                                    if self.dateToRemark[currentDateInStr][currentTime[:2]][:3] == 'pre': # only check first 3 char
                                        my_data[category][kpilist[i]][currentDateInStr][currentTime[:2]][0] += getValue(data_list[i+7])
                                    else:
                                        my_data[category][kpilist[i]][currentDateInStr][currentTime[:2]][1] += getValue(data_list[i+7])

            else:
                for data in raw_data[4:]:
                    data_list = data.split(',')

                    if len(data_list[2])!=0:
                        site_value=data_list[2]
                        

                    if category not in my_data:
                        my_data[category] = {}

                    if len(data_list[6])!=0:
                        cellnum=data_list[6].split("/")[1]
                        if cellnum=="QCI1":
                            for i in range(len(data_list[7:])):
                                if kpilist[i] not in my_data[category]:
                                    my_data[category][kpilist[i]] = {}

                                currentDate = ""
                                currentTime = ""
                                if len(data_list[3])!=0:
                                    currentDate = data_list[3].split()[0]
                                    currentTime = data_list[3].split()[1]
                                    
                                currentDateInStr = currentDate
                                
                                if currentDateInStr not in my_data[category][kpilist[i]]:
                                    my_data[category][kpilist[i]][currentDateInStr] = {}
                                

                                if  currentTime[:2] not in my_data[category][kpilist[i]][currentDateInStr]:
                                        my_data[category][kpilist[i]][currentDateInStr][currentTime[:2]] = [0, 0]

                                if site_value in self.mapping[category]:
                                    if currentDateInStr in self.dateToRemark.keys(): # for pre
                                        if currentTime[:2] in self.dateToRemark[currentDateInStr]:
                                            if self.dateToRemark[currentDateInStr][currentTime[:2]][:3] == 'pre': # only check first 3 char
                                                my_data[category][kpilist[i]][currentDateInStr][currentTime[:2]][0] += getValue(data_list[i+7])
                                            else:
                                                my_data[category][kpilist[i]][currentDateInStr][currentTime[:2]][1] += getValue(data_list[i+7])



        #print(my_data)
        self.myData = my_data
        
    
    

    def calVariablesValue(self,category, kpi, date, hour,isPost):
        data = {}
        try:
            data = self.myData[category][kpi][date]
            #print(data)
        except:
            return 0  
        val=0.0
        try:
            if isPost:
                val += float(data[hour][1])
            else:
                val += float(data[hour][0])
        except:
            val += 0
        return val
        

    def formulaEvaluation(self,category,currentDate, hour,worksheet):
        self.WPreCol = self.PreCol
        self.WPostCol = self.PostCol
        for items in self.formulaKpi: # kpi which suppose to be calcualte using formula ( map )
            if items in self.kpitoDisplay: # kpi to be displayed ( checking )
                preKpiFormula = self.formulaKpi[items]  # getting formula for given kpi
                varList = getVariables(preKpiFormula)
                var = list(set(varList)) # remove duplicate variables
                preAns = []
                IsPreRemark = 0

                for idx in range(len(var)):
                    if isInt(var[idx]):
                        preAns.append(float(var[idx]))
                        continue
                    preTmpText = 'preAns['+ str(idx) +']'
                    preKpiFormula = preKpiFormula.replace(var[idx], preTmpText)
                    preTmpResult=self.calVariablesValue(category, var[idx], currentDate, hour, False)
                    preAns.append(preTmpResult)
            

                preResult = 0
                try:
                    preResult = eval(preKpiFormula[1:])
                except:
                    pass
            
                for Remark in self.DateRemarkHour[currentDate]:
                    if Remark[:3] == 'pre':
                        IsPreRemark = 1

                if IsPreRemark:
                    worksheet.write(self.wrow, self.WPreCol, preResult)

                postKpiFormula = self.formulaKpi[items]
                varList = getVariables(postKpiFormula)
                var = list(set(varList)) # remove duplicate variables
                postAns = []
                IsPostRemark = 0

                for idx in range(len(var)):
                    if isInt(var[idx]):
                        postAns.append(float(var[idx]))
                        continue
                    postTmpText = 'postAns['+ str(idx) +']'
                    postKpiFormula = postKpiFormula.replace(var[idx], postTmpText)
                    postTmpResult=self.calVariablesValue(category, var[idx], currentDate, hour,True)
                    postAns.append(postTmpResult)

                
                # we formual and answer list
                # calculate value
                postResult = 0
                try:
                    postResult = eval(postKpiFormula[1:])
                    #logger.log(postResult,0)
                except:
                    pass

                for Remark in self.DateRemarkHour[currentDate]:
                    if Remark[:3] == 'pos':
                        IsPostRemark = 1
                
                if IsPostRemark:
                    worksheet.write(self.wrow, self.WPostCol, postResult)
                
                self.WPreCol += (self.PreCount + self.PostCount)
                self.WPostCol += (self.PreCount + self.PostCount)


    def WriteToExcelSheet(self,workbook,worksheet,worksheet1,heading,category,PreCount):
        date_format= workbook.add_format({'num_format': 'dd/mm/yy'})
        color=workbook.add_format({'fg_color':'#C6DCE4'})
        color_format=workbook.add_format({'bold':True,'fg_color':'#C6DCE4','align':'center',
                                   'valign':'vcenter'})
        dailyRow=0
        dailyCol=3

        #Writing Header in th sheeet
        if self.f==0:
            worksheet.write(dailyRow+1, dailyCol-1, "Date")
            worksheet.write(dailyRow+1, dailyCol-2, "Empty")
            worksheet.write(dailyRow+1, dailyCol-3, "Remarks2")  

        #Writing kpi and band in the sheet
        if self.f==0:
            for kpiWrite in self.formulaKpi:
                if kpiWrite in self.kpitoDisplay:
                    if len(self.remarkNameList) > 1:
                        worksheet.merge_range(dailyRow, dailyCol, dailyRow, dailyCol+len(self.remarkNameList) - 1, kpiWrite,color)
                    else:
                        worksheet.write(dailyRow,dailyCol,kpiWrite, color)
                    for remark in self.remarkNameList:
                        worksheet.write(1, dailyCol, remark)
                        dailyCol += 1

            
        #calculation of HourlyWise
        dateCol=3
        for i in range(24):
            worksheet.write(self.dateRow, dateCol - 1, to_string(getTime(i))) 
            worksheet.write(self.dateRow,dateCol-2,"(blank)")
            worksheet.write(self.dateRow,dateCol-3,category)
            self.dateRow+=1
            

        self.PreCol = 3
        self.PostCol = 3 + PreCount
        for CurrentDate in self.DateRemarkHour:
            self.wrow = self.MainRow
            hours=getHour()
            for hour in hours:
                self.formulaEvaluation(category,CurrentDate, hour,worksheet) 
                self.wrow+=1
            for Remark in self.DateRemarkHour[CurrentDate]:
                if Remark[:3] == 'pos':
                    self.PostCol += 1 
                else:
                    self.PreCol += 1

        
        self.MainRow = self.wrow
        

        
        self.GraphCol=3
        prow = 3
        worksheet1.merge_range(0, self.pcol, 0, self.pcol+7, heading + "(" + category+ ")- " ,color_format)
        #code for graph 
        for kpis in self.formulaKpi:
            if kpis in self.kpitoDisplay:
                if self.f==0:
                    worksheet1.write(prow, 0, kpis)
                chart = workbook.add_chart({'type': 'line'})       
                worksheet1.insert_chart(prow, self.pcol, chart)
                
                chart.set_title({'name': to_string(kpis)})
                chart.set_legend({'position': 'bottom'})
                chart.set_x_axis({'date_axis':True})
                chart.set_x_axis({'minor_unit': 1, 'major_unit':1})
                #self.GraphRow=2
                for remark in self.remarkNameList:
                    chart.add_series({'name' : remark,'categories':'=KPI_Day!$C$3:$C$26','values' : ['KPI_Day',self.GraphRow, self.GraphCol, self.GraphRow + 24-1, self.GraphCol]})
                    self.GraphCol += 1
                prow += 17
        self.pcol += 8
        self.GraphRow +=24 
        self.f=1
         
        
    def generate(self,workbook,heading,_sitelist,precount):
        #workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\outputfile.xlsx',{'strings_to_numbers':True})
        worksheet = workbook.add_worksheet('KPI_Day')   
        worksheet1 = workbook.add_worksheet('Graph_Day')
        keylist=[]
        for key in self.mapping:
            keylist.append(key)
        keylist.sort(key=myFunc,reverse=True)
        for keys in keylist:
            self.AddDataToMap(_sitelist,keys)
            self.WriteToExcelSheet(workbook,worksheet, worksheet1,heading,keys,precount)

       

        #workbook.close()
        #logger.closeLog()

        
                    
                        
     
# pre, post,dateToRemark,remarkNameList,valuelist,bandvaluelist,band, PreCount, PostCount, DateRemarkHour,sitelist,mapcategory=write_map()
# graph = Graph(dateToRemark,remarkNameList,band, PreCount, PostCount,DateRemarkHour,mapcategory)
# #myData = graph.AddDataToMap()
# graph.generate("Data",sitelist,PreCount)




















        






