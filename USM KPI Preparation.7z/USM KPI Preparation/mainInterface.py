import os
from tkinter import *
import tkinter as tk
from tkinter import ttk
import tkinter.messagebox
from tkinter import Tk, filedialog, Button, StringVar, OptionMenu
from tkcalendar import Calendar, DateEntry
from rawInput import write_to_files
from quaterrawinput import writetoFile
from dailysiterawinput import writetofiles
from hourrawInput import write_to_file
from dailywiseInterfacee import dailywiseInterface
from quaterwiseInterfacee import quaterwiseInterface
from hourlywiseInterfacee import hourlywiseInterface
from dailysitewiseinterfacee import dailysitewise
from hourlysiterawinput import writecsv
from hourlysitewiseinterfacee import hourlysitewise
from quatersiterawinput import writetocsv
from quatersitewiseinterfacee import quatersitewiseinterface
from tkinter import Tk, simpledialog

# import tarfile
# import os
# path=os.getcwd()
# folder=path+"\\"+"USM KPI Preparation\\Tarfile"
# outfolder=path+"\\"+"USM KPI Preparation\\input"
# tar_files = [f for f in os.listdir(folder) if f.endswith(".tar")]

# # Loop over all TAR files
# for tar_file in tar_files:
#     tar = tarfile.open(os.path.join(folder, tar_file))
#     for file in tar:
#         tar.extract(file, outfolder)
#         extracted_file = os.path.join(outfolder, file.name)
#         if os.path.exists(extracted_file):
#             i = 1
#             new_file_name = str(i)+file.name 
#             while os.path.exists(os.path.join(outfolder, new_file_name)):
#                 i += 1
#                 new_file_name = str(i)+file.name
#             os.rename(extracted_file, os.path.join(outfolder, new_file_name))
    
    
# tar.close()

root = Tk()
root.title("Version 6")
root.geometry("800x500")
root.configure(bg='black')



def on_dailywise_button_click():
    write_to_files()
    dailywiseInterface()
    
    

def on_hourlywise_button_click():
    write_to_file()
    hourlywiseInterface()
   
    
    

def on_quaterwise_button_click():
    writetoFile()
    quaterwiseInterface()
    

def on_dailysitewise_button_click():
    writetofiles()
    dailysitewise()

def on_hourlysitewise_button_click():
    writecsv()
    hourlysitewise()

def on_quatersitewise_button_click():
    writetocsv()
    quatersitewiseinterface()


    
#Title for tool
title = Label(root, text = " 4G & 5G KPI Tool Dashboard",font=('Calisto MT',15),background='black',foreground='Red').place(x = 300, y = 6) 

#Input Button

#output Button
output_folder = Button(root, command=on_dailywise_button_click, text="Dailywise_Graph_Summary")
output_folder.pack(ipadx=5, ipady=5,pady=5)
output_folder.place(x=180, y=60)

output = Button(root, command=on_hourlywise_button_click, text="Hourly_Graph_Summary")
output.pack(ipadx=5, ipady=5,pady=5)
output.place(x=350, y=60)

input = Button(root, command=on_quaterwise_button_click, text="Quater_Graph_Summary")
input.pack(ipadx=5, ipady=5,pady=5)
input.place(x=510, y=60)

input = Button(root, command=on_dailysitewise_button_click, text="Dailysitewise_Graph_Summary")
input.pack(ipadx=5, ipady=5,pady=5)
input.place(x=200, y=110)

input = Button(root, command=on_hourlysitewise_button_click, text="Hourlysitewise_Graph_Summary")
input.pack(ipadx=5, ipady=5,pady=5)
input.place(x=400, y=110)

input = Button(root, command=on_quatersitewise_button_click, text="Quatersitewise_Graph_Summary")
input.pack(ipadx=5, ipady=5,pady=5)
input.place(x=300, y=160)



root.mainloop()




