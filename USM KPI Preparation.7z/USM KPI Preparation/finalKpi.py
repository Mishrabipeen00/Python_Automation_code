from openpyxl import Workbook, load_workbook
import os
path=os.getcwd()
folder=path+"\\"+"USM KPI Preparation"+"\\" +"kpi_formula.xlsx"

wb = load_workbook(folder)
ws1= wb["final"]


def final_kpi():
    final_kpi_remark={}
    for row in range(2, ws1.max_row + 1):
        key = ws1.cell(row, 1).value
        value = ws1.cell(row, 2).value
        value2=ws1.cell(row,3).value
        final_kpi_remark[key] = []
        final_kpi_remark[key].append(value)
        final_kpi_remark[key].append(value2)
    return final_kpi_remark

