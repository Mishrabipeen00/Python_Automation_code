import xlsxwriter
import os
from datetime import datetime
from functools import cmp_to_key
from dateFun import getDates
from formulaMap import formula_kpi
from finalKpi import final_kpi
from rawInput import non_kpis_formula,write_map
from timeFun import getTimes
from formulaCleanvariable import getVariables
import multiprocessing
from multiprocessing import Process, current_process

# function to remove remove quotes
def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s

def remove_single_quoute(s):
    if len(s) == 0:
        return s
    if s[0] == "'":
        return s[1:-1]
    else:
        return s

def getValue(n):
    if n == '':
        return float(0)
    return float(n)

def replacePercent(d):
    d=d.replace('%',"")
    return d

def getKPIs(data):
    for i in range(7):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data


def to_date(s):
    s_list = s.split('-')
    if len(s_list) > 1:
        date = datetime.strptime(to_string(s), '%Y-%m-%d')
        return date
    else:
        date = datetime.strptime(to_string(s), '%Y %m %d')
        return date

def getDate(d):
    d_list=d.split('-')
    if len(d_list)>1:
        dd = datetime.strptime(to_string(d),"%Y-%m-%d")
        sdate=dd.strftime("%d %b %y")
        return sdate
    else:
        dd = datetime.strptime(to_string(d),"%Y %m %d")
        sdate = dd.strftime("%d %b %y")

        return sdate

def isInt(x):
    try:
        float(x)
        return True
    except ValueError:
        return False


def compare(x1, y1):
    x = x1.split('-')
    y = y1.split('-')

    if len(x) == 1:
        x = x1.split()
        y = y1.split()
    
    if int(x[0]) == int(y[0]): 
        if isInt(x[1][1]) and isInt(y[1][1]):
            if int(x[1][1]) < int(y[1][1]):
                return -1
            else:
                return 1
        else:
            if isInt(x[1][1]):
                return 1
            else: 
                return -1

    if int(x[0]) > int(y[0]):
        return 1
    return -1

    
def getBands():
    temp = ['1800 C1 Band']
    return temp

def getPos(dates):
    pos = {}
    for i in range(len(dates)):
        pos[dates[i]] = i
    return pos

def compare_var(s1, s2):
    if len(s1) > len(s2):
        return -1
    else:
        return 1


def getKeys(hour): 
    fixTime = ['15', '30', '45', '00']
    l = []
    for i in range(len(fixTime)):
        if i == len(fixTime) - 1:
            val = str(int(hour) + 1) + ":" + fixTime[i] + ":" + fixTime[-1]
            l.append(val)
        else:
            val = str(hour) + ":" + fixTime[i] + ":" + fixTime[-1]
            l.append(val)
    return l



class Graph:
    
    def __init__(self,_band):
        self.dates = getDates()
        self.pos = getPos(self.dates)
        path=os.getcwd()
        self.folder=path+"\\"+"USM KPI Preparation\\input"
        self.files = os.listdir(self.folder)
        self.bands = _band
        self.expected_length = 0
        self.end_col = 0
        self.end_row = 0
        #position for graph
        self.pcol = 1
        self.row = 2
        self.f = 0
        self.wrow = 2
        self.formulaKpi = formula_kpi()
        self.kpitoDisplay=final_kpi()


    def AddDataToMap(self):
        my_data = {}
        for filename in self.files:
            if filename == 'raw_input.csv':
                continue
            file = open(self.folder + "\\" + filename) 
            raw_data = file.read().split('\n')
            raw_data.pop()
            kpilist = getKPIs(raw_data[3].split(','))
            if raw_data[0] !="#family:Active E-RAB Number":
                for data in raw_data[4:]:
                    data_list = data.split(',')
                    
                    for i in range(len(data_list[7:])):

                        if kpilist[i] not in my_data:
                            my_data[kpilist[i]] = {}

                        currentDate = ""
                        currentTime = ""
                        if len(data_list[3])!=0:
                            currentDate = data_list[3].split()[0]
                            currentTime = data_list[3].split()[1]

                        for band in self.bands:
                            if band not in my_data[kpilist[i]]:
                                my_data[kpilist[i]][band] = {}

                            if currentDate not in my_data[kpilist[i]][band]:
                                my_data[kpilist[i]][band][currentDate] = {}

                            if  currentTime not in my_data[kpilist[i]][band][currentDate]:
                                my_data[kpilist[i]][band][currentDate][currentTime] = 0

                            my_data[kpilist[i]][band][currentDate][currentTime] += getValue(data_list[i+7])
            else:
                for data in raw_data[4:]:
                    data_list = data.split(',')
                    if len(data_list[6])!=0:
                        cellnum=data_list[6].split("/")[1]
                        if cellnum=="QCI1":
                            for i in range(len(data_list[7:])):
                                if kpilist[i] not in my_data:
                                    my_data[kpilist[i]] = {}

                                currentDate = ""
                                currentTime = ""
                                if len(data_list[3])!=0:
                                    currentDate = data_list[3].split()[0]
                                    currentTime = data_list[3].split()[1]

                                for band in self.bands:
                                    if band not in my_data[kpilist[i]]:
                                        my_data[kpilist[i]][band] = {}

                                    if currentDate not in my_data[kpilist[i]][band]:
                                        my_data[kpilist[i]][band][currentDate] = {}

                                    if  currentTime not in my_data[kpilist[i]][band][currentDate]:
                                        my_data[kpilist[i]][band][currentDate][currentTime] = 0

                                    my_data[kpilist[i]][band][currentDate][currentTime] += getValue(data_list[i+7])

                    
        

            
        self.myData=my_data
        return my_data

    
    

    def calVariablesValue(self,kpi, band, date, hour, isHourly, isQuaterly):
        data = {}
        try:
            data = self.myData[kpi][band][date]
        except:
            return 0
        if isQuaterly:
            val=0.0
            for hour in data:
                val=float(data[hour])
            return val   
        elif isHourly:
            val=0.0
            keys = getKeys(hour)
            for key in keys:
                try:
                    val += float(data[key])
                except:
                    val += 0
            return val
           
        else:
            val = 0.0
            for hour in data:
                val += float(data[hour])    
            return val 

    def formulaEvaluation(self, band, currentDate, hour, isHourly, isQuaterly, worksheet):
        for items in self.formulaKpi: # kpi which suppose to be calcualte using formula ( map )
            if items in self.kpitoDisplay: # kpi to be displayed ( checking )
                res = 0
                kpi_formula = self.formulaKpi[items]  # getting formula for given kpi
                varList = getVariables(kpi_formula)
                var = list(set(varList)) # remove duplicate variables
                ans = []
                for idx in range(len(var)):
                    if isInt(var[idx]):
                        ans.append(float(var[idx]))
                        continue
                    new_string = 'ans[' + str(idx) + ']'
                    kpi_formula = kpi_formula.replace(var[idx], new_string)
                    tmpRes = self.calVariablesValue(var[idx], band, currentDate, 0, False, False)
                    ans.append(tmpRes)
                    
                # we formual and answer list
                # calculate values
                res = 0
                try:
                    res = eval(kpi_formula[1:])
                except:
                    pass
                worksheet.write(self.wrow, self.col, res)
                self.col += 1


    def WriteToExcelSheet(self,workbook, worksheet, worksheet1,heading):
        # workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\outputfile.xlsx',{'strings_to_numbers':True})
        # worksheet = workbook.add_worksheet('KPI_Day')
        # worksheet1 = workbook.add_worksheet('Graph_Day') 
        date_format= workbook.add_format({'num_format': 'dd/mm/yy'})
        color=workbook.add_format({'fg_color':'#C6DCE4'})
        color_format=workbook.add_format({'bold':True,'fg_color':'#C6DCE4','align':'center',
                                   'valign':'vcenter'})
        dailyRow=0
        dailyCol=3

        #Writing Header in th sheeet
        worksheet.write(dailyRow+1, dailyCol-1, "Date")
        worksheet.write(dailyRow+1, dailyCol-2, "Empty")
        worksheet.write(dailyRow+1, dailyCol-3, "Remarks2")    
        
        #Writing kpi and band in the sheet

        for kpiWrite in self.formulaKpi:
            if kpiWrite in self.kpitoDisplay:
                worksheet.write(dailyRow, dailyCol, kpiWrite,color)
                for band in self.bands:
                    worksheet.write(dailyRow+1,dailyCol,band) 
                    dailyCol+=1

        
        
        #calculation of DailyWise,HourlyWise,QuartelyWise
        self.wrow = 2
        self.col=3
        dateRow=2
        dateCol=3
        key = ""
        for kpi in self.myData:
            key = kpi
            break
        for band in self.myData[key]:
            for currentDate in self.myData[key][band]:
                worksheet.write(self.wrow, self.col - 1, to_date(currentDate),date_format)
                worksheet.write(dateRow,dateCol-2,"(blank)")
                worksheet.write(dateRow,dateCol-3,"Overall")
                dateRow+=1
                self.formulaEvaluation(band, currentDate, 5, False, False, worksheet)   
                self.wrow += 1
                self.col = 3
                
        prow = 3
        self.pcol = 1
        self.row = 2
        self.f = 0
        self.wrow = 2
        worksheet1.merge_range(0, self.pcol, 0, self.pcol + 7, heading ,color_format)
        col = 3
        
        #code for graph 
    
        for kpis in self.formulaKpi:
            if kpis in self.kpitoDisplay:
                worksheet1.write(prow, 0, kpis)
                chart = workbook.add_chart({'type': 'line'})       
                worksheet1.insert_chart(prow, self.pcol, chart)
                
                chart.set_title({'name': to_string(kpis)})
                chart.set_legend({'position': 'bottom'})
                chart.set_x_axis({'date_axis': True})
                chart.set_x_axis({'minor_unit': 1, 'major_unit':1})


                last = 2 + len(currentDate) - 1
                for band in self.bands:
                    chart.add_series({'name' : band,'categories': '=KPI_Day!$C$3:$C$' + str(last) ,'values' : ['KPI_Day',self.row, col, self.row + len(currentDate) - 1, col]})
                    col += 1
                prow += 17

        self.pcol += 8
        self.row += len(currentDate)
        self.f = 1

    def generate(self,workbook,heading):
        #workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\outputfile.csv',{'strings_to_numbers':True})
        worksheet = workbook.add_worksheet('KPI_Day')   
        worksheet1 = workbook.add_worksheet('Graph_Day')
        self.AddDataToMap()
        self.WriteToExcelSheet(workbook,worksheet, worksheet1,heading)


       

        #workbook.close()
        # logger.closeLog()

        
                    
                        
if __name__=="__main__":
    p1=Process(target=Graph)
    p1.start()
    p1.join()
   
# pre, post,dateToRemark,remarkNameList,valuelist,bandvaluelist,band=write_map()
# graph = Graph(band)
# graph.generate("Data")
#myData = graph.AddDataToMap()
#graph.WriteToExcelSheet(myData,"Data")



















        






