import xlsxwriter
import os
from dateFun import getDates
import pandas as pd
from overCal import raw_kpi
from formulaMap import formula_kpi
from finalKpi import final_kpi
from bandCalculation import band_calculation
from datetime import datetime


def to_string(s):
    if len(s) == 0:
        return
    if s[0] == '"':
        return s[1:-1]
    else:
        return s

def toLowerCase(s):
    return s.strip().lower()

def getKPIs(data):
    for i in range(7):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data


def getPos(s):
    prePos = {
        'pre' : 0,
        'pre1': 1,
        'pre2': 2,
        'pre3': 3,
        'pre4': 4,
        'pre5': 5
    }

    postPos = {
        'post' : 0,
        'post1' : 1,
        'post2' : 2,
        'post3':  3,
        'post4':  4,
        'post5':  5
    }

    if s[1] == 'r':
        return prePos[s]
    else: 
        return postPos[s]

def getPrePosName(i):
    m = {
        0 : 'pre',
        1 : 'pre1',
        2 : 'pre2',
        3 : 'pre3',
        4 : 'pre4',
        5 : 'pre5'
    }

    return m[i]

def getPostPosName(i):
    m = {
        0 : 'post',
        1 : 'post1',
        2 : 'post2',
        3 : 'post3',
        4 : 'post4',
        5 : 'post5'
    }

    return m[i]
    

def all_kpi():
    all_kpis = getkpis()
    non_kpi = non_kpis_formula()
    for kpi in non_kpi:
        all_kpis.append(kpi)

    return all_kpis

def non_kpis_formula():
    kpi_list=[]
    non_kpis_formula=formula_kpi()
    for kpis in non_kpis_formula:
        kpi_list.append(kpis)
    return kpi_list

def finalkpi():
    finall_kpi=[]
    kpilist=final_kpi()
    for kpi in kpilist:
        finall_kpi.append(kpi)
    return finall_kpi

def getDate(d):
    d_list=d.split('-')
    if len(d_list)>1:
        dd = datetime.strptime(to_string(d),"%d-%b-%y")
        sdate=dd.strftime("%d %b %y")
        return sdate
    else:
        dd = datetime.strptime(to_string(d),"%d %b %y")
        sdate = dd.strftime("%d %b %y")
        return sdate
    

def getkpis():
    path=os.getcwd()
    kpisset=set()
    folder=path+"\\"+"USM KPI Preparation\\input"
    files=os.listdir(folder)
    for file in files:
        if file=="raw_input.csv":
            continue
        f = open(folder + "\\" + file,'r')
        data = f.read().split('\n')
        kpis = getKPIs(data[3].split(','))
        for item in kpis:
            kpisset.add(item)
    kpiList=list(kpisset)
    return kpiList

def writetofiles():
    t=getDates()
    all_k=finalkpi()
    remark_kpi=raw_kpi()
    band_cal=band_calculation()
    path=os.getcwd()
    folder=path+"\\"+"USM KPI Preparation\\input"
    f = open(folder + "\\" +'raw_input.csv', 'w')
    heading=['Date','Remarks',"KPI","Value","BandCalculation","Band","SiteList","Category"]
    
    f.write('sep=,')
    f.write('\n')
    for item in heading:
        f.write(item +',')
    f.write('\n')

    for i in range(max(len(all_k),len(t),len(remark_kpi),len(band_cal))):
        if i < len(t):
            f.write(t[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')
        
        f.write('')
        f.write(',')

        if i < len(all_k):
            f.write(all_k[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        if i < len(remark_kpi):
            f.write(remark_kpi[all_k[i]])
            f.write(',')
        else:
            f.write('')
            f.write(',')


        if i < len(band_cal):
            f.write(band_cal[all_k[i]])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        f.write('')
        f.write(',')

        f.write('')
        f.write(',')

        f.write('')
        f.write(',')
        
        f.write('\n')


def write_map():
    path=os.getcwd()
    folder=path+"\\"+"USM KPI Preparation\\input"
    file=open(folder + "\\" + 'raw_input.csv',"r")
    raw_data=file.read().split('\n')
    # making pre, post list
    dateToRemark = {}
    pre = [[],[],[],[],[],[]]
    post = [[],[],[],[],[],[]]

    valuelist=[]
    bandvaluelist=[]
    band=[]
    sitelist=[]
    
    mapcategory={}

    

    PreIndexMap = {}
    PostIndexMap = {}

    LastPreIndex = 0
    LastPostIndex = 0
    
    
    for d in raw_data[1:]:
        data_list = d.split(',')
        if len(data_list[0])!=0:
            date=to_string(getDate(data_list[0]))
            
    
        if len(data_list) > 1 and len(data_list[1])!=0:
            remark = to_string(data_list[1])
            #print(remark)
            dateToRemark[date] = toLowerCase(remark)
            # if remark[1] == 'r':
            #     pre[getPos(toLowerCase(remark))].append(to_string(date))
            # else:
            #     post[getPos(toLowerCase(remark))].append(to_string(date))


            if remark[1] == 'r':
                if remark not in PreIndexMap:
                    PreIndexMap[remark] = LastPreIndex
                    LastPreIndex += 1
                pre[PreIndexMap[remark]].append(to_string(date))
            else:
                if remark not in PostIndexMap:
                    PostIndexMap[remark] = LastPostIndex
                    LastPostIndex += 1
                post[PostIndexMap[remark]].append(to_string(date))

        if len(data_list) <1:
            break

        if len(data_list) > 3 and len(data_list[3])!=0:
            value=to_string(data_list[3])
            if value[1]=='v':
                valuelist.append(to_string(data_list[2]))

        if len(data_list) > 4 and len(data_list[4])!=0:
            bandvalue=to_string(data_list[4])
            if bandvalue[1]=='v':
                bandvaluelist.append(to_string(data_list[2]))
        
        
        if len(data_list) > 5 and len(data_list[5])!=0:
            bands=to_string(data_list[5])
            band.append(bands)

        if len(data_list) > 6 and len(data_list[6])!=0:
            site=to_string(data_list[6])
            sitelist.append(site)

        if len(data_list) > 7 and len(data_list[7])!=0:
            category=to_string(data_list[7])
        
            if category not in mapcategory:
                mapcategory[category] = []
            mapcategory[category].append(to_string(data_list[6]))


            


        

        
        


    remarkNameList = []
    # for i in range(len(pre)):
    #     if len(pre[i]) != 0:
    #         remarkNameList.append(getPrePosName(i))
    

    # for i in range(len(post)):
    #     if len(post[i]) != 0:
    #         remarkNameList.append(getPostPosName(i))

    for _remark in PreIndexMap:
        remarkNameList.append(_remark)

    for _remark in PostIndexMap:
        remarkNameList.append(_remark)

    #print(currentdate)

    
    return [pre, post,dateToRemark,remarkNameList,valuelist,bandvaluelist,band,sitelist,mapcategory]


#writetofiles()
# result = write_map()
# for item in result:
#     print(item)







