import os
def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s

def remark_map():
    map={}
    path=os.getcwd()
    folder=path+"\\"+"4G JIO_KPI_tool\\remark"
    files=os.listdir(folder)
    file=open(folder + "\\" +'remark_check.csv',"r")
    raw_data=file.read().split('\n')
    for data in raw_data[1:]:
        data_list = data.split(',') 
        if len(data_list)<2:
            continue   #check wheter sheet dat is greater than 2 or not
        if len(data_list[0]) != 0:
            kpis = to_string(data_list[0])
        if kpis not in map:
            map[kpis]=data_list[1]
    # print(map)

    return map

   
# remark_map()

