import xlsxwriter
from numpy import NaN
import os
from checking import getDates
import pandas as pd
from raw_kpi import raw_kpi
from formulakpi import formula_kpi
from final_kpi import final_kpi
from band_calculation import band_calculation

# kpis, bands, toband
def to_string(s):
    if len(s) == 0:
        return
    if s[0] == '"':
        return s[1:-1]
    else:
        return s

def toLowerCase(s):
    return s.strip().lower()

def getKPIs(data):
    for i in range(2):
        data.pop(0)
    for i in range(len(data)):
        tmp = to_string(data[i])
        data[i] = tmp
    return data

#return non_kpis 


def getPos(s):
    prePos = {
        'pre' : 0,
        'pre1': 1,
        'pre2': 2,
        'pre3': 3,
        'pre4': 4,
        'pre5': 5
    }

    postPos = {
        'post' : 0,
        'post1' : 1,
        'post2' : 2,
        'post3':  3,
        'post4':  4,
        'post5':  5
    }

    if s[1] == 'r':
        return prePos[s]
    else: 
        return postPos[s]
    


def make_raw():
    l=[]
    
    t=set()
    last_short_name = None
    date=None
    path=os.getcwd()
    folder=path+"\\"+"4G JIO_KPI_tool\\input"
    files=os.listdir(folder)
    file = open(folder + "\\" + files[0],'r')
    data = file.read().split('\n')
    data.pop()
    for d in data:
        data_list = d.split(',') 
        if len(data_list[0]) != 0:
            last_short_name = to_string(data_list[0])
            l.append(last_short_name)

    l.pop(0)             
    return l

def all_kpi():
    all_kpis = getkpis()
    non_kpi = non_kpis_formula()
    for kpi in non_kpi:
        all_kpis.append(kpi)

    return all_kpis

def non_kpis_formula():
    kpi_list=[]
    non_kpis_formula=formula_kpi()
    for kpis in non_kpis_formula:
        kpi_list.append(kpis)
    return kpi_list

def finalkpi():
    finall_kpi=[]
    kpilist=final_kpi()
    for kpi in kpilist:
        finall_kpi.append(kpi)
    return finall_kpi
    

def getkpis():
    path=os.getcwd()
    folder=path+"\\"+"4G JIO_KPI_tool\\input"
    files=os.listdir(folder)
    file = open(folder + "\\" + files[0],'r')
    data = file.read().split('\n')
    kpis = getKPIs(data[0].split(','))
    return kpis



    

def write_to_file():
    l = make_raw()
    t=getDates()
    all_k=finalkpi()
    remark_kpi=raw_kpi()
    band_cal=band_calculation()
    path=os.getcwd()
    folder=path+"\\"+"4G JIO_KPI_tool\\input"
    f = open(folder + "\\" +'raw_input.csv', 'w')
    heading=['Short name','Category','Band','Date','Remarks',"KPI","Value","BandCalculation"]
    
    f.write('sep=,')
    f.write('\n')
    for item in heading:
        f.write(item +',')
    f.write('\n')

    for i in range(max(len(all_k),len(t), len(l),len(remark_kpi),len(band_cal))):
        if i<len(l):
            f.write(l[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        f.write('')
        f.write(',')
        f.write('')
        f.write(',')

        if i < len(t):
            f.write(t[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')
        
        f.write('')
        f.write(',')

        if i < len(all_k):
            f.write(all_k[i])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        
        if i < len(remark_kpi):
            f.write(remark_kpi[all_k[i]])
            f.write(',')
        else:
            f.write('')
            f.write(',')


        if i < len(band_cal):
            f.write(band_cal[all_k[i]])
            f.write(',')
        else:
            f.write('')
            f.write(',')

        f.write('\n')







# short name to band
def write_map():
    m={}
    short_to_band = {}
    formulamap={}
    path=os.getcwd()
    folder=path+"\\"+"4G JIO_KPI_tool\\input"
    file=open(folder + "\\" + 'raw_input.csv',"r")
    raw_data=file.read().split('\n')
    for d in raw_data[1:]:
        data_list = d.split(',') 
        if len(data_list[0]) == 0:
            break
        if len(data_list[1]) != 0:
            category = to_string(data_list[1])
            short_to_band[to_string(data_list[0])] = to_string(data_list[2])
            
            
            
            if category not in m:
                m[category] = []
            m[category].append(to_string(data_list[0]))
            
        
        
    


    # making pre, post list
    pre = [[],[],[],[],[],[]]
    post = [[],[],[],[],[],[]]

    
    valuelist=[]
    bandvaluelist=[]
    

    for d in raw_data[1:]:
        data_list = d.split(',')
        if len(data_list) < 3:
            break

        if len(data_list[4]) != 0:
            remark = to_string(data_list[4])
            #print(remark)
            if remark[1] == 'r':
                pre[getPos(toLowerCase(remark))].append(to_string(data_list[3]))
            else:
                post[getPos(toLowerCase(remark))].append(to_string(data_list[3]))
        if len(data_list) <5:
            break

        if len(data_list[6])!=0:
            value=to_string(data_list[6])
            if value[1]=='v':
                valuelist.append(to_string(data_list[5]))

        if len(data_list[7])!=0:
            bandvalue=to_string(data_list[7])
            if bandvalue[1]=='v':
                bandvaluelist.append(to_string(data_list[5]))


        

        
    return [m, pre, post, short_to_band,valuelist,bandvaluelist]
            
        
#write_to_file()
# result = write_map()
# for item in result:
#    print(item)

#Function for replacing comma
def replaceComma():
    path=os.getcwd()
    folder=path+"\\"+"4G JIO_KPI_tool\\input"
    files = os.listdir(folder)
    for filename in files:
        if filename == 'raw_input.csv':
                continue
        df = pd.read_csv(folder + '\\' + filename,dtype={col: str for col in pd.read_csv(folder + '\\' + filename, nrows=1).columns})
        l = df.iloc[:,0].replace(NaN, '').tolist()
        new_list= []
        for item in l:
            length = item.split(',')
            if len(length) <= 1:
                new_list.append(item)
            else:
                new_item = item.replace(',', ';')
                new_list.append(new_item)
        for i in range(len(df)):
            df.loc[i,'Short name'] = new_list[i]
        #print("pandas start...")
        df.to_csv(folder + '\\' + filename, index=False)







