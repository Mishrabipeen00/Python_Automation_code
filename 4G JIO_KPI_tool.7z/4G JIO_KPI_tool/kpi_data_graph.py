import xlsxwriter
import os
from datetime import datetime
from functools import cmp_to_key
from checking import getDates
from kpifiles import non_kpis_formula
from kpiformulamaking import getVariables, replace_percent
from formulakpi import formula_kpi
from final_kpi import final_kpi
from Graphaveragecalculation import Graph_cal




# kpis, bands, toband
def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s

def remove_single_quoute(s):
    if len(s) == 0:
        return s
    if s[0] == "'":
        return s[1:-1]
    else:
        return s

def getValue(n):
    if n == '':
        return float(0)
    return float(n)

# Function for getting band name
def getBandName(string):
    s = string.split('_')
    if s[0][0] == '"':
        return s[0][1:] + " " + "Band"
    return s[0] + " " + "Band"


def to_band(band):
    band_name = band.split('_')[0] + " Band"
    return band_name

# Function for getting kpi
def getKPIs(data):
    d = data.split(',')
    d.pop(0)
    d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d


def to_date(s):
    s_list = s.split('-')
    if len(s_list) > 1:
        date = datetime.strptime(to_string(s), '%d-%b-%y')
        return date
    else:
        date = datetime.strptime(to_string(s), '%d %b %y')
        return date

def getDate(d):
    d_list=d.split('-')
    if len(d_list)>1:
        dd = datetime.strptime(to_string(d),"%d-%b-%y")
        sdate=dd.strftime("%d %b %y")
        return sdate
    else:
        dd = datetime.strptime(to_string(d),"%d %b %y")
        sdate = dd.strftime("%d %b %y")
        return sdate


def isInt(x):
    try:
        int(x)
        return True
    except ValueError:
        return False
    
def isfloat(x):
    try:
        float(x)
        return True
    except ValueError:
        return False

def compare(x1, y1):
    x = x1.split()
    y = y1.split()
    

    if int(x[0]) == int(y[0]): 
        if isInt(x[1][1]) and isInt(y[1][1]):
            if int(x[1][1]) < int(y[1][1]):
                return -1
            else:
                return 1
        else:
            if isInt(x[1][1]):
                return 1
            else: 
                return -1

    if int(x[0]) > int(y[0]):
        return -1
    return 1

def myFunc(e):
      return e[2]

    
def getBands(data):
    temp = ['2300 C1 Band', '2300 C2 Band', '1800 Band', '850 C1 Band','850 C2 Band']
    l = set()
    for line in data:
        line_list = line.split(',')
        if len(line_list[0]) != 0:
            l.add(getBandName(line_list[0]))
        
    _list = list(l)
    _list.sort(key=cmp_to_key(compare)) # 4 temp[3:]
    return _list


def remove_zero_division(s, ans): # avoiding zero div error by replacing experssion value with 0
    idx = len(ans)
    ans.append(1)
    express = ""
    for i in range(len(s)):
        if i >= len(s):
            continue

        if s[i] == '/':
            end = i
            if i < len(s) and isInt(s[i + 1]): # if formula contain integer value 
                continue
            if s[i + 1] == '(': # if formuala contain expression with parenthesis ( )
                tmp_ans = 0
                f = -1
                while(i < len(s) and i != ')'):
                    if isInt(s[i]) and s[i - 1] == '[':
                        tmp_ans += ans[int(s[i])]
                        if f == -1:
                            f = i
                    i += 1
                if tmp_ans == 0:
                    express = s[0:f] + str(idx) + s[f + 1:]
                    s= express         
            else:
                if ans[int(s[i+5])]!=0: # handling ans[index] case
                    continue 
                express += s[:end + 1]
                while(s[i] != ']'): # finding last pos of ans[idx]
                    i += 1
                express += 'ans[' + str(idx) + s[i:]
                s = express
                                 
                
    return [s, ans]




def getCategory(s):
    s_list = s.split('_')
    return s_list[4]

def getname(s):
    sname=s.split('_')
    d= "_".join(sname[1:])
    return d

def getPos(dates):
    pos = {}
    #print(dates)
    for i in range(len(dates)):
        pos[dates[i]] = i
    return pos

def compare_var(s1, s2):
    if len(s1) > len(s2):
        return -1
    else:
        return 1

class catGraph:

    def __init__(self, mapping, _short_to_band):
        #self.folder = _folder
        self.dates = getDates()
        self.pos = getPos(self.dates)
        #print(self.pos)
        path=os.getcwd()
        self.folder=path+"\\"+"4G JIO_KPI_tool\\input"
        self.files = os.listdir(self.folder)
        file = open(self.folder + "\\" + self.files[0],'r')
        data = file.read().split('\n')
        s = set()
        _bands = None
        for key in _short_to_band:
            s.add(_short_to_band[key])
        _bands = list(s)
        _bands.sort(key=cmp_to_key(compare)) # 4 temp[3:]
        self.bands = _bands
        self.mapping = mapping
        self.expected_length = 0
        self.short_to_band = _short_to_band
        self.end_col = 0
        self.end_row = 0
        self.Graphcal=Graph_cal()
        #self.bands = getBands(self.folder + "\\" + self.files[0])

        
        self.pcol = 1
        self.row = 2
        self.f = 0
        self.wrow = 2


    def write_to_temp_map(self, my_data, category):
        count={}
        for filename in self.files:
            if filename == 'raw_input.csv':
                continue
            file = open(self.folder + "\\" + filename) 
            raw_data = file.read().split('\n')
            raw_data.pop()
            self.kpis = getKPIs(raw_data[0])
            _len = len(self.dates)
            last_band = ""
            last_short_name = None
            self.remark=""
            


            for data in raw_data[1:]:
                data_list = data.split(',')
                if len(data_list[0]) != 0:
                    last_short_name = to_string(data_list[0])
                    #print(last_short_name)
                    last_band = self.short_to_band[last_short_name]
                    self.remark=getname(to_string(data_list[0]))
                    for kpi in self.kpis:
                        if kpi not in my_data:
                            my_data[kpi] = {}

                        if kpi not in count:
                            count[kpi]={}
                        else:
                            break

                       
                    
                    
                """
                my_data = {}
                my_data[category] = {}
                my_data[category][kpi] = {}
                my_data[category][kpi][band] = []
                """
                
                for i in range(len(data_list[2:])):
                    if last_band not in my_data[self.kpis[i]]:
                        #print(my_data[self.kpis[i]])
                        my_data[self.kpis[i]][last_band] = [0 for i in range(_len)]

                    if last_band not in count[self.kpis[i]]:
                        count[self.kpis[i]][last_band]=[0 for i in range(_len)]
                    
                    
                     
                        #dont forgot to fill list 
                    if last_short_name in self.mapping[category]:
                       # print(data_list[i+2])
                        count[self.kpis[i]][last_band][self.pos[getDate(to_string(data_list[1]))]] +=1
                        my_data[self.kpis[i]][last_band][self.pos[getDate(to_string(data_list[1]))]] += getValue(data_list[i+2])
        

        for kpi in my_data:
            if kpi in self.Graphcal:
                for band in my_data[kpi]:
                    for i in range(len(my_data[kpi][band])):
                        if count[kpi][band][i] != 0:
                            my_data[kpi][band][i]=round(my_data[kpi][band][i] / count[kpi][band][i], 2)
        
            
                        

    def write_to_file(self, my_data, category,workbook, worksheet, worksheet1,heading):
        non_kpi_map = formula_kpi()
        final=final_kpi()
        date_format= workbook.add_format({'num_format': 'dd/mm/yy'})
        color=workbook.add_format({'fg_color':'#C6DCE4'})
        color_format=workbook.add_format({'bold':True,'fg_color':'#C6DCE4','align':'center',
                                   'valign':'vcenter'})

        row = 2
        tcol = 4
        if self.f == 0:
            worksheet.write(row-1, 3, "Date")
            worksheet.write(row-1, 2, "Empty")
            worksheet.write(row-1, 1, "Remarks2")
            worksheet.write(row-1, 0, "Remarks3")
        
        if self.f == 0:
            for kpi in self.kpis:
                if kpi in final:
                    if len(self.bands) > 1:
                        worksheet.merge_range(0, tcol, 0, tcol+len(self.bands) - 1, kpi,color)
                    else:
                        worksheet.write(0,tcol,kpi, color)
                    for band in self.bands:
                        worksheet.write(1, tcol, band)
                        tcol += 1
                    
            for kpi in non_kpi_map:
                if kpi in final:
                    if len(self.bands) > 1:
                        worksheet.merge_range(0, tcol, 0, tcol+len(self.bands) - 1, kpi,color)
                    else:
                        worksheet.write(0,tcol,kpi, color)
                    for band in self.bands:
                        worksheet.write(1, tcol, band)
                        tcol += 1


        non_kpi_map = formula_kpi()
        for i in range(len(self.dates)):
            worksheet.write(self.wrow, 1, category)
            worksheet.write(self.wrow,0,self.remark)
            worksheet.write(self.wrow,2,"(blank)")
            worksheet.write(self.wrow,3,to_date(self.dates[i]), date_format)
               
            col = 4
            for kpi in self.kpis:
                if kpi in final:
                    for band in self.bands:                    
                        worksheet.write(self.wrow, col, my_data[kpi][band][i]) #4
                        col += 1
                        self.end_col = col
           
            #formula calculation
            for kpi in non_kpi_map:
                if kpi in final:
                    #worksheet.merge_range(0, col,0, col+len(self.bands)- 1, kpi, color) #merging is wrong here
                    for band in self.bands:
                        #worksheet.write(1,col,band)                  

                        res = 0
                        kpi_formula = non_kpi_map[kpi]
                        var_list = getVariables(kpi_formula)
                        var = list(set(var_list)) # remove duplicate variables
                        var.sort(key=cmp_to_key(compare_var))
                        ans = []
                        for idx in range(len(var)):
                            new_string = 'ans[' + str(idx) + ']'
                            kpi_formula = kpi_formula.replace(var[idx], new_string)
                            ans.append(my_data[remove_single_quoute(var[idx])][band][i])# data of kpi of band and ith date
                            
                        
                        
                        if kpi_formula[0]=="=":
                            kpi_formula = kpi_formula[1:]
                        kpi_formula = replace_percent(kpi_formula)
                        #kpi_formula, ans = remove_zero_division(kpi_formula,ans)
                        try:
                            res = eval(kpi_formula)
                        except ZeroDivisionError:
                            res = 0
                    
                        #res = eval(kpi_formula)
                        worksheet.write(self.wrow, col, res) #4
                        col += 1
                        
            
            self.wrow += 1
        
       
        prow = 3
        worksheet1.merge_range(0, self.pcol, 0, self.pcol + 7, heading + "(" + category + ")- ",color_format)
        col = 4
        for kpi in self.kpis:
            if kpi in final:
                if self.f == 0:
                    worksheet1.write(prow, 0, kpi)
                chart = workbook.add_chart({'type': 'line'})       
                worksheet1.insert_chart(prow, self.pcol, chart)
                    
                chart.set_title({'name': to_string(kpi)})
                chart.set_legend({'position': 'bottom'})
                chart.set_x_axis({'date_axis': True})
                chart.set_x_axis({'minor_unit': 1, 'major_unit':1})


                last = 3 + len(self.dates) - 1
                for band in self.bands:
                        chart.add_series({'name' : band,'categories': '=KPI_Day!$D$3:$D$' + str(last) ,'values' : ['KPI_Day',self.row, col, self.row + len(self.dates) - 1, col]})
                        col += 1
                prow += 17
        #graph for formula kpi
        for kpi in non_kpi_map:
            if kpi in final:
                worksheet1.write(prow, 0, kpi)
                chart = workbook.add_chart({'type': 'line'})       
                worksheet1.insert_chart(prow, self.pcol, chart)
                        
                chart.set_title({'name': to_string(kpi)})
                chart.set_legend({'position': 'bottom'})
                chart.set_x_axis({'date_axis': True})
                chart.set_x_axis({'minor_unit': 1, 'major_unit':1})

                last = 3+ len(self.dates) - 1
                for band in self.bands:
                    chart.add_series({'name' : band,'categories': '=KPI_Day!$D$3:$D$' + str(last) ,'values' : ['KPI_Day',self.row, col, self.row + len(self.dates) - 1, col]})
                    col += 1
                prow += 17
            
            
        self.pcol += 8
        self.row += len(self.dates)
        self.f = 1

    def generate(self,workbook,heading):
        #workbook = xlsxwriter.Workbook('C:\\Users\\DELL\\Downloads\\outputfile.csv',{'strings_to_numbers':True})
        worksheet = workbook.add_worksheet('KPI_Day')   
        worksheet1 = workbook.add_worksheet('Graph_Day')
        color=workbook.add_format({'fg_color':'#C6DCE4'})
        kpislist=[]
        for key in self.mapping:
            kpislist.append(key)
        kpislist.sort(key=myFunc,reverse=True)
        for key in self.mapping:
            my_data = {}
        for keys in kpislist:
            my_data={}
            self.write_to_temp_map(my_data, keys)
            self.write_to_file(my_data, keys, workbook, worksheet, worksheet1,heading)

        
           
    
# mapping = {'mumbai' : ['1800_OR_OR_Circle_CDU_PKG900P2a_gb', '2300 C1_OR_OR_Circle_RDU_PKG900P2a_gb'],
#             'nagpur' : ['850_OR_OR_Circle_RDU_PKG900P2a_gb', '2300 C1_OR_OR_Circle_CDU_PKG900P2a_gb', '850_OR_OR_Circle_Overall_PKG900P2a_gb']
#     }
#graph = catGraph(mapping)
#graph.generate()