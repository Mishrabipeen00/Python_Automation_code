import re
import os

def formula():
    expression="PdcpSduLossULNum.QCI1/PdcpSduTotalULNum.QCI1%" 
    cleanstring=re.sub('[^A-Za-z0-9.%]+', ' ', expression)
    variables = cleanstring.split(" ")
    for i in range(len(variables)):
        var = 'l[' + str(i) + ']'
        expression = expression.replace(variables[i], var)
    return [expression, variables]


def isInt(x):
    try:
        float(x)
        return True
    except ValueError:
        return False
    
def replace_percent(d):
    d=d.replace('%',"")
    return d


def remove_bracket(s):
    if len(s) == 0:
        return s

    # if s[0] == "'":
    #     s = s[1:]

    # if len(s) == 0:
    #     return s
    
    # if s[-1] == "%":
    #     s = s[0:len(s) - 2]
 

    if len(s) == 0:
        return s
    
    # if s[-1] == "'":
    #     s = s[0:len(s) - 1]
       

    if len(s) == 0:
        return s
    
    if s[0] == '=':
        s = s[1:]
    
    
    if len(s) == 0:
        return s

    if s[0] == '(':
        s = s[1:]
    
    if s[-1] == ')':
        s = s[0:len(s) - 1]

    if len(s) == 0:
        return s
    
    # if s[0] == "'":
    #         s = s[1:]

    # if len(s) == 0:
    #     return s
    
    # if s[-1] == "'":
    #     s = s[0:len(s) - 1]

    return s

def getVariables(data_list):
    first_list = []
    l3 = data_list.split('/')
    for item in l3:
        tmp = item.split('*')
        for ele in tmp:
            first_list.append(ele)

    second_list = []
    for item in first_list:
        tmp = item.split('/')
        for ele in tmp:
            second_list.append(ele)

    third_list = []
    for item in second_list:
        tmp = item.split("+")
        for ele in tmp:
            third_list.append(ele)

    fourth_list=[]
    for item in third_list:
        if re.findall(r'[0-9]+', item):
            tmp=item.split("/")
            for ele in tmp:
                fourth_list.append(ele)
        else:
            tmp=item.split("-")
            for ele in tmp:
                fourth_list.append(ele)
    
    res = []
    for item in fourth_list:
        conn=replace_percent(item)
        var = remove_bracket(conn)
        if isInt(var) or len(var) == 0:
            continue
        res.append(var)

    #print(res)
    return res
#getVariables("151908-5G_ERCS_DL MAC Latency (ms)- Non DRX_QOS9-data)")