import os
from datetime import datetime
import xlsxwriter


def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s
    
def getValue(n):
    if n == '' :
        return float(0)
    else:
        return float(n)

    
def getKPIs(data):
    d = data.split(',')
    d.pop(0)
    d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d




def MakedataFile():
    mapdata = {}
    current_dir = os.getcwd()
    input_folder = os.path.join(current_dir, "HOAlramfailCorrelationTool", "input3")
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file_path = os.path.join(input_folder, file_name)
        with open(file_path, 'r') as file:
            raw_file_data = file.read().split('\n')  
        raw_file_data.pop()
        for data in raw_file_data[15:]:
            data_list = data.split(',')
            if len(data_list[5]) != 0:
                neid = data_list[5]
            if neid not in mapdata:
                mapdata[neid] = {}
            if len(data_list[7]) != 0:
                alaram = data_list[7]
            mapdata[neid][alaram] = mapdata[neid].get(alaram, 0) + 1
        
    
    return mapdata


      









