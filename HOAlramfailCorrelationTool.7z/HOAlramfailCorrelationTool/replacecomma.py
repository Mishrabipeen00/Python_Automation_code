import pandas as pd
import os
from numpy import NaN
def replaceComma():
    path=os.getcwd()
    folder=path+"\\"+"HOAlramfailCorrelationTool\input1"
    files = os.listdir(folder)
    for filename in files:
        if filename == 'raw_input.csv':
                continue
        df = pd.read_csv(folder + '\\' + filename)
        l = df.iloc[:,0].replace(NaN, '').tolist()
        new_list= []
        for item in l:
            length = item.split(',')
            if len(length) <= 1:
                new_list.append(item)
            else:
                new_item = item.replace(',', ';')
                new_list.append(new_item)
        #print(new_list)
        
        
        #print(new_list)
        #print("pandas start...")
        #i = df.iloc[:,0].tolist()
        #print("pandas start...")
        # df2 = df.replace(i,  new_list)
        for i in range(len(df)):
            df.loc[i,'Short name'] = new_list[i]
        #print("pandas start...")
        df.to_csv(folder + '\\' + filename, index=False)
        #print("Pandas end.....")

def replaceCommas1():
    path=os.getcwd()
    folder=path+"\\"+"HOAlramfailCorrelationTool\input2"
    files = os.listdir(folder)
    for filename in files:
        if filename == 'raw_input.csv':
                continue
        df = pd.read_csv(folder + '\\' + filename)
        l = df.iloc[:,0].replace(NaN, '').tolist()
        new_list= []
        for item in l:
            length = item.split(',')
            if len(length) <= 1:
                new_list.append(item)
            else:
                new_item = item.replace(',', ';')
                new_list.append(new_item)
        for i in range(len(df)):
            df.loc[i,'Short name'] = new_list[i]
        #print("pandas start...")
        df.to_csv(folder + '\\' + filename, index=False)
        #print("Pandas end.....")


def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s
    
def getCounter(data):
    d = data.split(',')
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d


def headerfunction():
    my_data=[]
    current_dir = os.getcwd()
    input_folder = current_dir + "\\" + "HOAlramfailCorrelationTool\\input1"
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file= open(input_folder + "\\" + file_name, 'r')
        raw_file_data = file.read().split('\n')  
        raw_file_data.pop()
        counters = getCounter(raw_file_data[0])
        for counter in counters:
            my_data.append(counter)

    my_data.insert(1,"SourceENB")
    my_data.insert(2,"SourceCell")
    my_data.insert(3,"TargetENB")
    my_data.insert(4,"TargetCell")
    my_data.pop(5)
    my_data.insert(5,"Date")
    my_data.insert(8,"X2Fail")

    return my_data


def headerfunctions1():
    my_data2=[]
    current_dir = os.getcwd()
    input_folder = current_dir + "\\" + "HOAlramfailCorrelationTool\\input2"
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file= open(input_folder + "\\" + file_name, 'r')
        raw_file_data = file.read().split('\n')  
        raw_file_data.pop()
        counters = getCounter(raw_file_data[0])
        for counter in counters:
            my_data2.append(counter)

    my_data2.insert(1,"SourceENB")
    my_data2.insert(2,"SourceCell")
    my_data2.insert(3,"TargetENB")
    my_data2.insert(4,"TargetCell")
    my_data2.pop(5)
    my_data2.insert(5,"Date")
    my_data2.insert(8,"S1Fail")

    return my_data2


 