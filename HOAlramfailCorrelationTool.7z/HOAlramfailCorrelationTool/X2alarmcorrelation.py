import os
import xlsxwriter
from datetime import datetime
from Alramfailcorrelation import MakedataFile
from replacecomma import headerfunction,headerfunctions1

def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s
    
def getValue(n):
    if n == '' :
        return float(0)
    else:
        return float(n)
    
def getCounter(data):
    d = data.split(',')
    d.pop(0)
    d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d

    
def getKPIs(data):
    d = data.split(',')
    d.pop(0)
    d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d


def MakeInputfileX2():
    my_data=[]
    current_dir = os.getcwd()
    input_folder = current_dir + "\\" + "HOAlramfailCorrelationTool\\input1"
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file= open(input_folder + "\\" + file_name, 'r')
        raw_file_data = file.read().split('\n')  
        raw_file_data.pop()
        counters = getCounter(raw_file_data[0])
        SourceENB=""
        SourceCell=""
        TargetENB=""
        TargetCell=""
        X2Fail=""
        for data in raw_file_data[1:]:
            data_list = data.split(',')
            if len(data_list[0]) != 0:
                SourceENB= to_string(data_list[0]).split(';')[1].split('_')[1]

            if len(data_list[0]) != 0:
                SourceCell= to_string(data_list[0]).split(';')[2].split('=>')[0]

            if len(data_list[0]) != 0:
                TargetENB= to_string(data_list[0]).split(';')[2].split('=>')[1].split(';')[0]

            if len(data_list[0]) != 0:
                TargetCell= to_string(data_list[0]).split(';')[3]

            if len(data_list[1]) != 0:
                date_string = to_string(data_list[1])
                
                if '-' in date_string:
                    date_obj = datetime.strptime(date_string, '%d-%b-%y')
                else:
                    date_obj = datetime.strptime(date_string.replace(' ', '-'), '%d-%b-%y')
                
            
            if len(data_list[2]) != 0:
                X2Fail = float(data_list[2]) - float(data_list[3])
            else:
                X2Fail=''

            if len(data_list[0]) != 0:
                shortname= to_string(data_list[0]).replace(';',',')

            if len(data_list[0]) == 0:
                data_list[0] = SourceENB
            data_list.insert(1,SourceENB)
            if len(data_list[0]) == 0:
                data_list[0] = SourceCell
            data_list.insert(2,SourceCell)
            if len(data_list[0]) == 0:
                data_list[0] = TargetENB
            data_list.insert(3,TargetENB)
            if len(data_list[0]) == 0:
                data_list[0] = TargetCell
            data_list.insert(4,TargetCell)
            data_list.insert(8,X2Fail)
            data_list[5]=date_obj
            data_list[0]=shortname
            my_data.append(data_list)
    
    
    return my_data

def MakeInputfileS1():
    my_data2=[]
    current_dir = os.getcwd()
    input_folder = current_dir + "\\" + "HOAlramfailCorrelationTool\\input2"
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file= open(input_folder + "\\" + file_name, 'r')
        raw_file_data = file.read().split('\n')  
        raw_file_data.pop()
        counters = getCounter(raw_file_data[0])
        SourceENB=""
        SourceCell=""
        TargetENB=""
        TargetCell=""
        S1Fail=""
        for data in raw_file_data[1:]:
            data_list = data.split(',')
            if len(data_list[0]) != 0:
                SourceENB= to_string(data_list[0]).split(';')[1].split('_')[1]

            if len(data_list[0]) != 0:
                SourceCell= to_string(data_list[0]).split(';')[2].split('=>')[0]

            if len(data_list[0]) != 0:
                TargetENB= to_string(data_list[0]).split(';')[2].split('=>')[1].split(';')[0]

            if len(data_list[0]) != 0:
                TargetCell= to_string(data_list[0]).split(';')[3]

            if len(data_list[1]) != 0:
                date_string = to_string(data_list[1])
                
                if '-' in date_string:
                    date_obj = datetime.strptime(date_string, '%d-%b-%y')
                else:
                    date_obj = datetime.strptime(date_string.replace(' ', '-'), '%d-%b-%y')
                
            
            if len(data_list[2]) != 0:
                S1Fail = float(data_list[2]) - float(data_list[3])
            else:
                S1Fail=''

            if len(data_list[0]) != 0:
                shortname= to_string(data_list[0]).replace(';',',')

            if len(data_list[0]) == 0:
                data_list[0] = SourceENB
            data_list.insert(1,SourceENB)
            if len(data_list[0]) == 0:
                data_list[0] = SourceCell
            data_list.insert(2,SourceCell)
            if len(data_list[0]) == 0:
                data_list[0] = TargetENB
            data_list.insert(3,TargetENB)
            if len(data_list[0]) == 0:
                data_list[0] = TargetCell
            data_list.insert(4,TargetCell)
            data_list.insert(8,S1Fail)
            data_list[5]=date_obj
            data_list[0]=shortname
            my_data2.append(data_list)
    
    
    return my_data2


def create_counter_dict():
    counterdict={}
    current_dir = os.getcwd()
    input_folder = current_dir + "\\" + "HOAlramfailCorrelationTool\\input1"
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file= open(input_folder + "\\" + file_name, 'r')
        raw_file_data = file.read().split('\n')  
        raw_file_data.pop()
        counters = getCounter(raw_file_data[0])
        sitename=""
        for data in raw_file_data[1:]:
            data_list = data.split(',')
            if len(data_list[0]) != 0:
                sitename = to_string(data_list[0]).split('=>')[1].split(';')[0]
            if sitename not in counterdict:
                counterdict[sitename] = {}

            for i in range(len(counters)):
                if counters[i] not in counterdict[sitename]:
                    counterdict[sitename][counters[i]] = 0
                counterdict[sitename][counters[i]] += getValue(data_list[i+2])
    
    return counterdict

def create_counter_dict_S1():
    counterdicts1={}
    current_dir = os.getcwd()
    input_folder = current_dir + "\\" + "HOAlramfailCorrelationTool\\input2"
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file= open(input_folder + "\\" + file_name, 'r')
        raw_file_data = file.read().split('\n')  
        raw_file_data.pop()
        counters = getCounter(raw_file_data[0])
        sitename=""
        for data in raw_file_data[1:]:
            data_list = data.split(',')
            if len(data_list[0]) != 0:
                sitename = to_string(data_list[0]).split('=>')[1].split(';')[0]
            if sitename not in counterdicts1:
                counterdicts1[sitename] = {}

            for i in range(len(counters)):
                if counters[i] not in counterdicts1[sitename]:
                    counterdicts1[sitename][counters[i]] = 0
                counterdicts1[sitename][counters[i]] += getValue(data_list[i+2])
    

    return counterdicts1


def final_pivot_dict():
    raw_dict = create_counter_dict()
    raw_alram_dict =MakedataFile()
    final_dict = {}
    for neid, counters in raw_dict.items():
        if neid in raw_alram_dict:
            counter_dict = {}
            for alramname, alramvalue in raw_alram_dict[neid].items():
                counter_dict[alramname] = alramvalue
            final_dict[neid] = counter_dict

    return final_dict

def final_pivot_dict_s1():
    raw_dict = create_counter_dict_S1()
    raw_alram_dict =MakedataFile()
    final_dict2 = {}
    for neid, counters in raw_dict.items():
        if neid in raw_alram_dict:
            counter_dict = {}
            for alramname, alramvalue in raw_alram_dict[neid].items():
                counter_dict[alramname] = alramvalue
            final_dict2[neid] = counter_dict

    return final_dict2


def writetoexcel():
    headerfilename=headerfunction()
    headerfilenames1=headerfunctions1()
    makerawdata=MakeInputfileX2()
    makerawdatas1=MakeInputfileS1()
    finalmap=final_pivot_dict()
    finalmaps1=final_pivot_dict_s1()
    current_dir = os.getcwd()
    outfolder_folder = os.path.join(current_dir, "HOAlramfailCorrelationTool", "output")
    new_output = outfolder_folder + '\\'+'output.xlsx'
    workbook = xlsxwriter.Workbook(new_output,{'strings_to_numbers':True})
    worksheet = workbook.add_worksheet("X2FailCorrelation")
    worksheet1 = workbook.add_worksheet("S1FailCorrelation")  
    date_format = workbook.add_format({'num_format': 'dd-mmm-yy'})
    row1=0
    col1=0

    row=0
    col=0

    for i in range(len(headerfilename)):
        worksheet.write(0, i, headerfilename[i])

    for i in range(len(headerfilenames1)):
        worksheet1.write(0, i, headerfilenames1[i])


    for row1 in range(len(makerawdata)):
        for col1 in range(len(makerawdata[row1])):
            if col1 == 5:
                worksheet.write(row1+1, col1, makerawdata[row1][col1], date_format)
            else:
                worksheet.write(row1+1, col1, makerawdata[row1][col1])
    max_col = worksheet.dim_colmax + 1

    for row in range(len(makerawdatas1)):
        for col in range(len(makerawdatas1[row])):
            if col == 5:
                worksheet1.write(row+1, col, makerawdatas1[row][col], date_format)
            else:
                worksheet1.write(row+1, col, makerawdatas1[row][col])
    max_col2 = worksheet1.dim_colmax + 1

    # Get all alarm names
    alarm_names = set()
    for sitename in finalmap:
        for alram_name in finalmap[sitename]:
            alarm_names.add(alram_name)
    
    for alarm_idx, alarm_name in enumerate(alarm_names):
        worksheet.write(0, max_col + alarm_idx, alarm_name)
        worksheet1.write(0, max_col2 + alarm_idx, alarm_name)

    for row_idx, data_row in enumerate(makerawdata):
        sitename = data_row[3]
        alarm_data = finalmap.get(sitename, {})
        for alarm_idx, alarm_name in enumerate(alarm_names):
            alarm_col = max_col + alarm_idx
            alarm_value = alarm_data.get(alarm_name, "")
            worksheet.write(row_idx+1, alarm_col, alarm_value)

    for row_idx, data_row in enumerate(makerawdatas1):
        sitename = data_row[3]
        alarm_data = finalmaps1.get(sitename, {})
        for alarm_idx, alarm_name in enumerate(alarm_names):
            alarm_col = max_col2 + alarm_idx
            alarm_value = alarm_data.get(alarm_name, "")
            worksheet1.write(row_idx+1, alarm_col, alarm_value)
        
    
    workbook.close()













       
    




        