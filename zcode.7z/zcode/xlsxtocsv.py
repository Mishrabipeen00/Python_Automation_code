import os
import csv

def convert_xlsx_to_csv(xlsx_file, csv_file):
    with open(xlsx_file, 'rb') as xlsx_file:
        with open(csv_file, 'w', newline='') as csv_file:
            reader = csv.reader(xlsx_file, delimiter=',', quotechar='"')
            writer = csv.writer(csv_file, delimiter=',')
            for row in reader:
                writer.writerow(row)

if __name__ == '__main__':
    input_folder = 'input'
    output_folder = 'output'
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        if file_name.endswith('.xlsx'):
            xlsx_file = os.path.join(input_folder, file_name)
            csv_file = os.path.join(output_folder, file_name[:-5] + '.csv')
            convert_xlsx_to_csv(xlsx_file, csv_file)