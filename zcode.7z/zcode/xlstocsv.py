
# import os
# import csv

# def convert_xls_to_csv(xls_file, csv_file):
#     with open(xls_file, 'r', newline='') as xls_file:
#         with open(csv_file, 'w', newline='') as csv_file:
#             reader = csv.reader(xls_file, delimiter=',')
#             writer = csv.writer(csv_file, delimiter=',')
#             for row in reader:
#                 writer.writerow(row)


# if __name__ == '__main__':
#     input_folder = 'C:\\Users\\DELL\\Documents\\file'
#     output_folder = 'C:\\Users\\DELL\\Documents\\csvoutput'
#     file_list = os.listdir(input_folder)
#     for file_name in file_list:
#         if file_name.endswith('.xls'):
#             xls_file = os.path.join(input_folder, file_name)
#             csv_file = os.path.join(output_folder, file_name[:-3] + '.csv')
#             convert_xls_to_csv(xls_file, csv_file)


# import os
# import csv

# def convert_xls_to_csv(xls_file, csv_file):
#     with open(xls_file, 'r', newline='') as xls_file:
#         with open(csv_file, 'w', newline='') as csv_file:
#             reader = csv.reader(xls_file, delimiter=',')
#             writer = csv.writer(csv_file, delimiter=',')
#             for row in reader:
#                 writer.writerow(row)

# def merge_csv_files(input_folder, output_folder):
#     file_list = os.listdir(input_folder)
#     csv_files = []
#     for file_name in file_list:
#         if file_name.endswith('.csv'):
#             csv_file = os.path.join(input_folder, file_name)
#             csv_files.append(csv_file)

#     with open(os.path.join(output_folder, 'merged.csv'), 'w', newline='') as output_file:
#         writer = csv.writer(output_file, delimiter=',')
#         for csv_file in csv_files:
#             with open(csv_file, 'r', newline='') as input_file:
#                 reader = csv.reader(input_file, delimiter=',')
#                 for row in reader:
#                     writer.writerow(row)


# if __name__ == '__main__':
#     input_folder = 'C:\\Users\\DELL\\Documents\\fileinput'
#     output_folder = 'C:\\Users\\DELL\\Documents\\fileoutput'
#     merge_csv_files(input_folder, output_folder)

# def merge_csv_files(input_folder, output_folder, chunk_size):
#     file_list = os.listdir(input_folder)
#     csv_files = []
#     for file_name in file_list:
#         if file_name.endswith('.csv'):
#             csv_file = os.path.join(input_folder, file_name)
#             csv_files.append(csv_file)

#     num_files = len(csv_files) // chunk_size + 1
#     for i in range(num_files):
#         with open(os.path.join(output_folder, f'merged{i}.csv'), 'w', newline='') as output_file:
#             writer = csv.writer(output_file, delimiter=',')
#             for csv_file in csv_files[i * chunk_size:(i + 1) * chunk_size]:
#                 with open(csv_file, 'r', newline='') as input_file:
#                     reader = csv.reader(input_file, delimiter=',')
#                     for row in reader:
#                         writer.writerow(row)

# if __name__ == '__main__':
#     input_folder = 'C:\\Users\\DELL\\Documents\\fileinput'
#     output_folder = 'C:\\Users\\DELL\\Documents\\fileoutput'
#     chunk_size = 1000
#     merge_csv_files(input_folder, output_folder, chunk_size)

# def merge_csv_files(input_folder, output_folder, chunk_size):
#     file_list = os.listdir(input_folder)
#     csv_files = []
#     for file_name in file_list:
#         if file_name.endswith('.csv'):
#             csv_file = os.path.join(input_folder, file_name)
#             csv_files.append(csv_file)

#     num_files = len(csv_files) // chunk_size + 1
#     for i in range(num_files):
#         with open(os.path.join(output_folder, f'merged{i:02d}.csv'), 'w', newline='') as output_file:
#             writer = csv.writer(output_file, delimiter=',')
#             for csv_file in csv_files[i * chunk_size:(i + 1) * chunk_size]:
#                 with open(csv_file, 'r', newline='') as input_file:
#                     reader = csv.reader(input_file, delimiter=',')
#                     for row in reader:
#                         writer.writerow(row)

import os
import csv

def merge_csv_files(input_folder, output_folder):
    merged_data = []
    file_counter = 1
    
    # Iterate over all files in the input folder
    for filename in os.listdir(input_folder):
        if filename.endswith(".csv"):
            file_path = os.path.join(input_folder, filename)
            
            # Read the CSV file
            with open(file_path, 'r') as file:
                reader = csv.reader(file)
                next(reader)  # Skip the header row
                for row in reader:
                    merged_data.append(row)
                    
                    # Split merged_data into separate files
                    if len(merged_data) >= 1000000:  # Adjust the threshold as per your requirements
                        # Write the merged data to a new CSV file
                        merged_file_path = os.path.join(output_folder, f"merged_data_{file_counter}.csv")
                        with open(merged_file_path, 'w', newline='') as file:
                            writer = csv.writer(file)
                            writer.writerows(merged_data)
                        
                        merged_data = []  # Clear the merged_data list
                        file_counter += 1
    
    # Write the remaining merged data to a new CSV file
    merged_file_path = os.path.join(output_folder, f"merged_data_{file_counter}.csv")
    with open(merged_file_path, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(merged_data)
    
    # Create a summary file with the number of rows from each file
    summary_file_path = os.path.join(output_folder, "summary.txt")
    with open(summary_file_path, 'w') as file:
        file.write("File Summary:\n")
        file.write("--------------\n\n")
        for filename in os.listdir(input_folder):
            if filename.endswith(".csv"):
                file_path = os.path.join(input_folder, filename)
                with open(file_path, 'r') as file:
                    reader = csv.reader(file)
                    row_count = sum(1 for _ in reader) - 1  # Subtract 1 for the header row
                    file.write(f"{filename}: {row_count} rows\n")
    
    print("Merging and summary generation complete!")

# Example usage
input_folder = 'C:\\Users\\DELL\\Documents\\fileinput'
output_folder = 'C:\\Users\\DELL\\Documents\\fileoutput'

merge_csv_files(input_folder, output_folder)



# if __name__ == '__main__':
#     input_folder = 'C:\\Users\\DELL\\Documents\\fileinput'
#     output_folder = 'C:\\Users\\DELL\\Documents\\fileoutput'
#     chunk_size = 1000
#     merge_csv_files(input_folder, output_folder, chunk_size)