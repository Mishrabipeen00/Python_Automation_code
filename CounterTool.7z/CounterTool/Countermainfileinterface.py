import os
from tkinter import *
import tkinter as tk
from tkinter import ttk
import tkinter.messagebox
from tkinter import Tk, filedialog, Button, StringVar, OptionMenu
import xlsxwriter
from mainfile import WriteToExcel

 

# Get output name from file
def getOutputName(s):
    s_list = s.split('.')
    return s_list[0]+"Output"

#Create folder name
def getFolderName(ll):
    print(ll)
    items = ll.split('\\')
    s = ''
    for item in items:
        s += item + '\\'
    print(s)
    return s[:-2]




root = Tk()   
root.geometry("800x500")
root.configure(bg='black')
open_output_file = ''
open_input_file = ''
date_list = None
short_name=None

#Creating input filedialog askdirectory

def selectInputFolder():
    global open_input_file
    global date_list
    global short_name
    file_name = filedialog.askdirectory()
    ll = file_name.split('/')
    s = ''
    for l in ll:
        s += l + "\\\\"
    open_input_file = s[:-2]
    
    


    
#Creating output filedialog askdirectory
    
def selectOutputFolder():
    global open_output_file
    file_name = filedialog.askdirectory()
    ll = file_name.split('/')
    s = ''
    for l in ll:
        s += l + "\\\\"
    open_output_file = s
    

    

#Function for Display message 
def onclick():
    tkinter.messagebox.showinfo("output location","Don't forget to Select output location")
    
#Title for tool
title = Label(root, text = "Counter Tool Dashboard",font=('Calisto MT',15),background='black',foreground='Red').place(x = 230, y = 6) 

#output Button
output_folder = Button(root, command=selectOutputFolder, text="Output File location")
output_folder.pack(ipadx=5, ipady=5,pady=5)
output_folder.place(x=282, y=50)

def _submit(open_output_file):
    t=WriteToExcel(open_output_file)
    print("output has been generated!!!")
    return t


    
b = Button(root,command=lambda: _submit(open_output_file),text = "Generate Report",bg='red',  fg = 'blue')    
b.pack(ipadx=5, ipady=5,pady=5)
b.place(x=300, y=100)


root.mainloop()