from openpyxl import Workbook, load_workbook
import os
path=os.getcwd()
folder=path+"\\"+"CounterTool"+"\\" +"Counter.xlsx"
folder = os.path.join(path,folder)

wb = load_workbook(folder)
ws1= wb["Counter"]


def CounterNormalAbnormalMapping():
    counter={}
    for row in range(2, ws1.max_row + 1):
        key = ws1.cell(row, 1).value
        value = ws1.cell(row, 2).value
        counter[key] = value
    
    return counter




