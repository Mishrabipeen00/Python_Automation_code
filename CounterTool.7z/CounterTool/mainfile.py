import xlsxwriter
import os
from counter import CounterNormalAbnormalMapping
from countercalcultaion import Checkcounter,GenerateCounterData


def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s
    
def calculate_formula(x, y):
    if y == 0:
        return 100
    else:
        return x / (x + y) * 100
    
def getValue(n):
    if n == '':
        return float(0)
    return float(n)
    
def getCounter(data):   
    d = data.split(',')
    d.pop(0)
    d.pop(0)
    d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d


def GenerateData():
    mapdata={}
    current_dir = os.getcwd()
    #current_dir = os.path.dirname(os.path.realpath(__file__))
    input_folder = current_dir + "\\" + "CounterTool\\input"
    #input_folder = os.path.join(current_dir,'input')
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file= open(input_folder + "\\" + file_name, 'r')
        raw_file_data = file.read().split('\n')  
        raw_file_data.pop()
        counters= getCounter(raw_file_data[10])

        for data in raw_file_data[11:]:
            data_list = data.split(',')
            if len(data_list[1]) != 0:
                enb= to_string(data_list[1])
                if enb not in mapdata:
                    mapdata[enb]={}
                
            if len(data_list[2])!=0:
                cellnum=to_string(data_list[2])
                if cellnum not in mapdata[enb]:
                    mapdata[enb][cellnum]={}

            for i in range(len(data_list[3:])):
                if counters[i] not in mapdata[enb][cellnum]:
                    mapdata[enb][cellnum][counters[i]]=0
                mapdata[enb][cellnum][counters[i]] += getValue(data_list[i+3])

    return mapdata


def WriteToExcel(_output):
    mapData = GenerateData()
    HighestcounterMap=GenerateCounterData()
    countermapData=Checkcounter()
    counterNormalAbnormalMapping = CounterNormalAbnormalMapping()
    # print(counterNormalAbnormalMapping)
    new_output = _output + '\\'+'raw_output.xlsx'
    workbook = xlsxwriter.Workbook(new_output,{'strings_to_numbers':True})
    worksheet = workbook.add_worksheet("Output")
    worksheet2 = workbook.add_worksheet("Report3")
    color_format=workbook.add_format({'bold':True})
    headrow=0
    headcol=0
    num_records=1
    
    valuerow=0
    valuecol=0

    abnormalrow=0
    abnormalcol=2

    enbrow=2
    enbcol=0

    indexrow=2
    indexcol=1
    
    nerow=0
    necol=0

    cellrow=0
    cellcol=0

    worksheet.write(indexrow-1,indexcol,"Index")
    worksheet.write(indexrow-1,indexcol-1,"NE")  
    
    row2 = 0
    col2 = 0
    worksheet2.write(row2,col2,"Counter")
    worksheet2.write(row2,col2+1,"NE")
    worksheet2.write(row2,col2+2,"Index")
    worksheet2.write(row2,col2+3,"Count")
    
    for countress in HighestcounterMap:
        for i in range(20):
            worksheet2.write(row2+1,col2,countress)
            row2+=1

    for counter in HighestcounterMap:
        sorted_records = sorted(((enb, cellnum, value)
                                 for enb, enb_dict in countermapData.items()
                                 for cellnum, cellnum_dict in enb_dict.items()
                                 for counter_name, value in cellnum_dict.items()
                                 if counter_name == counter),
                                key=lambda x: x[2],
                                reverse=True)
        
        for enb, cellnum, value in sorted_records[:20]:
            worksheet2.write(nerow+1,necol+1,enb)
            nerow+=1
            worksheet2.write(cellrow+1,cellcol+2,cellnum)
            cellrow+=1
            worksheet2.write(valuerow+1,valuecol+3,value)
            valuerow+=1
           


    row=2
    col=2

    CellNumSumMap = {}
    CounterConstAbnormal = 'Abnormal';
    CounterConstNormal = 'Normal';

    maxColPos = 0
    total =0
    for NE in mapData:
        CellNumSumMap[NE] = {}
        for CellNum in mapData[NE]:
            CellNumSumMap[NE][CellNum] = {}
            CellNumSumMap[NE][CellNum][CounterConstAbnormal] = 0
            CellNumSumMap[NE][CellNum][CounterConstNormal] = 0

            for Counter in mapData[NE][CellNum]:
                value = mapData[NE][CellNum][Counter]
                try:
                    CellNumSumMap[NE][CellNum][counterNormalAbnormalMapping[Counter]] += getValue(value)
                    worksheet.write(row, col, value)
                
                    if col > maxColPos:
                        maxColPos = col
                    col += 1
                except:
                    pass    
            row += 1
            col = 2
    

    
    row = 2 
    col = maxColPos + 1
    newmaxrow=2
    newmaxcol=maxColPos + 4
    worksheet.write(row-1,col,"Abnormal",color_format)
    worksheet.write(row-1,col+1,"Normal",color_format)
    worksheet.write(row-1,col+2,"Abnormal%",color_format)
    worksheet.write(row-1,col+3,"Abnormal_1",color_format)
    worksheet.write(row-1,col+4,"Abnormal1_count",color_format)
    worksheet.write(row-1,col+5,"Abnormal_2",color_format)
    worksheet.write(row-1,col+6,"Abnormal2_count",color_format)

    # for enb in countermapData:
    #     for cellNum in countermapData[enb].keys():
    #         tmp_max_value = -1
    #         tmp_variable_name = ""
    #         for counter in countermapData[enb][cellNum]:
    #             current_value = countermapData[enb][cellNum][counter]
    #             if tmp_max_value == -1:
    #                 tmp_max_value = current_value
    #                 tmp_variable_name = counter

    #             if tmp_max_value < current_value:
    #                 tmp_max_value = current_value
    #                 tmp_variable_name = counter
            
    #         worksheet.write(newmaxrow, newmaxcol, tmp_variable_name)
    #         worksheet.write(newmaxrow, newmaxcol+1, tmp_max_value)
    #         newmaxrow+=1


    for enb in countermapData:
        for cellNum in countermapData[enb].keys():
            tmp_max_value = -1
            tmp_variable_name = ""
            tmp_second_max_value = -1
            tmp_second_variable_name = ""
        
            for counter in countermapData[enb][cellNum]:
                current_value = countermapData[enb][cellNum][counter]
                
                if tmp_max_value == -1:
                    tmp_max_value = current_value
                    tmp_variable_name = counter
                elif tmp_second_max_value == -1:
                    if current_value < tmp_max_value:
                        tmp_second_max_value = current_value
                        tmp_second_variable_name = counter
                    else:
                        tmp_second_max_value = tmp_max_value
                        tmp_second_variable_name = tmp_variable_name
                        tmp_max_value = current_value
                        tmp_variable_name = counter
                        
                elif current_value > tmp_max_value:
                    tmp_second_max_value = tmp_max_value
                    tmp_second_variable_name = tmp_variable_name
                    tmp_max_value = current_value
                    tmp_variable_name = counter
                elif current_value > tmp_second_max_value and current_value != tmp_max_value:
                    tmp_second_max_value = current_value
                    tmp_second_variable_name = counter

            worksheet.write(newmaxrow, newmaxcol, tmp_variable_name)
            worksheet.write(newmaxrow, newmaxcol+1, tmp_max_value)
            worksheet.write(newmaxrow, newmaxcol+2, tmp_second_variable_name)
            worksheet.write(newmaxrow, newmaxcol+3, tmp_second_max_value)

            newmaxrow+=1

        
                
    for NE in CellNumSumMap:
        for CellNum in CellNumSumMap[NE]:
            valueMap = CellNumSumMap[NE][CellNum]
            value1=valueMap[CounterConstAbnormal]
            value2=valueMap[CounterConstNormal] 
            abnoramperent=calculate_formula(value1,value2) 
            worksheet.write(row, col, valueMap[CounterConstAbnormal])
            worksheet.write(row, col + 1, valueMap[CounterConstNormal])
            worksheet.write(row, col + 2, round(abnoramperent,2))
            row += 1


    for NE in mapData:
        for cellnum in mapData[NE]:
            worksheet.write(enbrow,enbcol,NE)
            enbrow+=1

    for NE in mapData:
        for indexcall in mapData[NE]:
            worksheet.write(indexrow,indexcol,indexcall)
            indexrow+=1
                      
    for Counter in mapData[NE][CellNum]:
        worksheet.write(headrow+1,headcol+2,Counter)
        headcol+=1

    for const in counterNormalAbnormalMapping:
        worksheet.write(abnormalrow,abnormalcol,counterNormalAbnormalMapping[const])
        abnormalcol+=1

    

    workbook.close()





    