import os
from counter import CounterNormalAbnormalMapping

def to_string(s):
    if len(s) == 0:
        return s
    if s[0] == '"':
        return s[1:-1]
    else:
        return s
    
def getValue(n):
    if n == '':
        return float(0)
    return float(n)
    
def getCounter(data):
    d = data.split(',')
    d.pop(0)
    d.pop(0)
    d.pop(0)
    for i in range(len(d)):
        tmp = to_string(d[i])
        d[i] = tmp
    return d


def GenerateCounterData():
    CounterdataMap={}
    counterNormalAbnormalMapping = CounterNormalAbnormalMapping()
    current_dir = os.getcwd()
    input_folder = current_dir + "\\" + "CounterTool\\input"
    # current_dir = os.path.dirname(os.path.realpath(__file__))
    # input_folder = os.path.join(current_dir,'input')
    file_list = os.listdir(input_folder)
    for file_name in file_list:
        file= open(input_folder + "\\" + file_name, 'r')
        raw_file_data = file.read().split('\n')
        raw_file_data.pop()
        counters= getCounter(raw_file_data[10])
        
        for data in raw_file_data[11:]:
            data_list = data.split(',')
            for i in range(len(data_list[3:])):
                if counters[i]=='':
                    continue
                if counterNormalAbnormalMapping[counters[i]]!="Abnormal":
                    continue
                if counters[i] not in CounterdataMap:
                    CounterdataMap[counters[i]]=0
                CounterdataMap[counters[i]] += getValue(data_list[i+3])
  
    sorted_dict = sorted(CounterdataMap.items(), key=lambda x: x[1], reverse=True)
    max_20 = dict(sorted_dict[:20])

    return max_20



def Checkcounter():
    CheckcounterMap = {}
    HighestcounterMap = GenerateCounterData()
    current_dir = os.getcwd()
    input_folder = current_dir + "\\" + "CounterTool\\input"
    #current_dir = os.path.dirname(os.path.realpath(__file__))
    file_list = os.listdir(input_folder)

    
    for file_name in file_list:
        file = open(os.path.join(input_folder, file_name), 'r')
        raw_file_data = file.read().split('\n')
        raw_file_data.pop()
        counters = getCounter(raw_file_data[10])

        
        for data in raw_file_data[11:]:
            data_list = data.split(',')

            
            if len(data_list[1]) != 0 and len(data_list[2]) != 0:
                enb = to_string(data_list[1])
                cellnum = to_string(data_list[2])

                
                if enb not in CheckcounterMap:
                    CheckcounterMap[enb] = {}
                if cellnum not in CheckcounterMap[enb]:
                    CheckcounterMap[enb][cellnum] = {}

                
                for i in range(len(data_list[3:])):
                    if counters[i] in HighestcounterMap.keys():
                        if counters[i] not in CheckcounterMap[enb][cellnum]:
                            CheckcounterMap[enb][cellnum][counters[i]] = 0
                        CheckcounterMap[enb][cellnum][counters[i]] += getValue(data_list[i+3])
                        
   
   
    return CheckcounterMap






    



    

    





